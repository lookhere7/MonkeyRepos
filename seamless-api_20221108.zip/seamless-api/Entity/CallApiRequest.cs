﻿using System.Collections.Generic;

namespace Seamless.Core.API.Entity.CallApiRequest
{
    public class CreateTokenRequest
    {
        public string gameId { get; set; }
    }
}
