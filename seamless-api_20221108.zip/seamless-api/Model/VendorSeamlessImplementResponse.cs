﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Seamless.Core.API.Model
{
    public class VendorSeamlessImplementResponse
    {
        public int Id { get; set; }

        public int Id_Operator { get; set; }

        public string MerchantID { get; set; }

        public string Password { get; set; }

        public string SecretKey { get; set; }

        public DateTime CreateDate { get; set; } 

        public DateTime ExpireDate { get; set; }

        public string VendorHashKey { get; set; }

        public string ImplementSecretKey { get; set; }

        public string IV { get; set; }

        public string KEY { get; set; }

        public string URL_Login { get; set; }

        public string URL_Register { get; set; }

        public string URL_Deposit { get; set; }

        public string URL_Withdraw { get; set; }

        public string URL_BetLog { get; set; }

        public string URL_AddVendor { get; set; }

        public string URL_Online { get; set; }

        public string URL_Logout { get; set; }

        public string URL_Block { get; set; }

        public string URL_ModifyPlayer { get; set; }

        public string URL_Balance { get; set; }

        public string URL_GetPlayer { get; set; }

        public string URL_GameList { get; set; }

        public string URL_AuthenticateUser { get; set; }

        public string URL_Bet { get; set; }

        public string URL_BetCancel { get; set; }

        public string URL_KeepAlive { get; set; }

        public string URL_Play { get; set; }

        public string URL_CreateToken { get; set; }
        
        public string URL_RoundSettle { get; set; }        
             
    }
}
