﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Seamless.Core.API.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace Seamless.Core.API.Services
{
    public class OperatorService : IOperatorService
    {
        /// <summary>
        /// 
        /// </summary>
        private readonly Models.ManufacturerCMSContext _context = new Models.ManufacturerCMSContext();
        private readonly ICacheService _cacheService;
        private readonly int _rediscachetime;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="context"></param>
        public OperatorService(IConfiguration config, ICacheService cacheService)
        {
            _rediscachetime = int.Parse(config["RedisCacheTime"]);
            _cacheService = cacheService;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="username"></param>
        public async Task<Models.Operator> GetOperator(string _username)
        {
            #region 取得Redis快取
            //取得Redis快取
            var _response = await _cacheService.GetFromCache<Models.Operator>($"Operator_{_username}");
            if (_response == null)
            {
                //若無快取，則重新撈取資料
                _response = await _context.Operators.Where(x => x.Username == _username).FirstOrDefaultAsync();

                //新增Redis快取
                await _cacheService.SetCache<Models.Operator>($"Operator_{_username}", _response, _rediscachetime);
            }
            #endregion

            return _response;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="_id"></param>
        /// <returns></returns>
        public async Task<Models.Operator> GetOperator(int _id)
        {
            #region 取得Redis快取
            //取得Redis快取
            var _response = await _cacheService.GetFromCache<Models.Operator>($"Operator_{_id.ToString()}");
            if (_response == null)
            {
                //若無快取，則重新撈取資料
                _response = await _context.Operators.Where(x => x.Id == _id).FirstOrDefaultAsync();

                //新增Redis快取
                await _cacheService.SetCache<Models.Operator>($"Operator_{_id.ToString()}", _response, _rediscachetime);
            }
            #endregion

            return _response;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="_operatorid"></param>
        /// <returns></returns>
        public async Task<Models.OperatorImplementInfo> GetOperatorImplementInfo(int _operatorid)
        {
            #region 取得Redis快取
            //取得Redis快取
            var _response = await _cacheService.GetFromCache<Models.OperatorImplementInfo>($"OperatorImplementInfo_{_operatorid.ToString()}");
            if (_response == null)
            {
                //若無快取，則重新撈取資料
                _response = await _context.OperatorImplementInfos.Where(x => x.IdOperator == _operatorid).FirstOrDefaultAsync();

                //新增Redis快取
                await _cacheService.SetCache<Models.OperatorImplementInfo>($"OperatorImplementInfo_{_operatorid.ToString()}", _response, _rediscachetime);
            }
            #endregion

            return _response;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="_merchantid"></param>
        /// <returns></returns>
        public async Task<Models.OperatorImplementInfo> GetOperatorImplementInfo(string _merchantid)
        {
            #region 取得Redis快取
            //取得Redis快取
            var _response = await _cacheService.GetFromCache<Models.OperatorImplementInfo>($"OperatorImplementInfo_{_merchantid}");
            if (_response == null)
            {
                //若無快取，則重新撈取資料
                _response = await _context.OperatorImplementInfos.Where(x => x.MerchantId == _merchantid).FirstOrDefaultAsync();

                //新增Redis快取
                await _cacheService.SetCache<Models.OperatorImplementInfo>($"OperatorImplementInfo_{_merchantid}", _response, _rediscachetime);
            }
            #endregion

            return _response;
        }
    }
}
