﻿using System;
using System.Collections.Generic;

namespace Seamless.Core.API.Models
{
    public partial class VendorBundleMapping
    {
        public int Id { get; set; }
        public int? IdOperator { get; set; }
        public int? IdVendor { get; set; }
        public int? IdGame { get; set; }
        public string BundleName { get; set; }
        public string PackageName { get; set; }
        public sbyte? Status { get; set; }
    }
}
