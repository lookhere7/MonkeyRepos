﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.Extensions.Configuration;
using System.IO;
using System.Linq;

namespace Seamless.Core.API.Models
{
    /// <summary>
    /// 提供呼叫SP使用
    /// </summary>
    public partial class SP_ManufacturerCMSContext : DbContext
    {
        public SP_ManufacturerCMSContext()
        {
        }

        public SP_ManufacturerCMSContext(DbContextOptions<SP_ManufacturerCMSContext> options)
            : base(options)
        {
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                var builder = new ConfigurationBuilder()
                  .SetBasePath(Directory.GetCurrentDirectory())
                  .AddJsonFile("appsettings.json");
                var config = builder.Build();

                optionsBuilder.UseMySql(config.GetConnectionString("DefaultConnection"), Microsoft.EntityFrameworkCore.ServerVersion.Parse("5.7.36-mysql"));
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.UseCollation("utf8_general_ci")
                .HasCharSet("utf8");

            modelBuilder.Entity<Model.SP_VendorImplementInfoResponse>(entity =>
            {
                entity.HasNoKey();

                entity.Property(e => e.Id)
                    .HasColumnType("int(11)")
                    .HasComment("系統編號");
                
                entity.Property(e => e.BetRecordInterval)
                    .HasColumnType("int(11)")
                    .HasColumnName("BetRecord_Interval")
                    .HasDefaultValueSql("'15'")
                    .HasComment("1. 排程撈取遊戲商投注紀錄區間\n2. 每隔x分鐘");

                entity.Property(e => e.IdVendor)
                    .HasColumnType("int(11)")
                    .HasColumnName("Id_Vendor")
                    .HasDefaultValueSql("'0'")
                    .HasComment("遊戲商系統編號");

                entity.Property(e => e.ImplementCode)
                    .HasMaxLength(50)
                    .HasColumnName("Implement_Code")
                    .HasComment("1. 串接代碼\n2. 遊戲商呼叫中間層 API 時使用\n");

                entity.Property(e => e.ImplementIv)
                    .HasMaxLength(50)
                    .HasColumnName("Implement_IV")
                    .HasComment("1. 串接IV\n2. 遊戲商呼叫中間層 API 時使用\n");

                entity.Property(e => e.ImplementKey)
                    .HasMaxLength(50)
                    .HasColumnName("Implement_Key")
                    .HasComment("1. 串接Key\n2. 遊戲商呼叫中間層 API 時使用\n");

                entity.Property(e => e.Password)
                    .HasMaxLength(50)
                    .HasComment("1. 密碼\n2. 遊戲商呼叫中間層 API 時使用之 Password\n");

                entity.Property(e => e.Status)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'0'")
                    .HasComment("啟用狀態");

                entity.Property(e => e.SummaryRecordInterval)
                    .HasColumnType("int(11)")
                    .HasColumnName("SummaryRecord_Interval")
                    .HasDefaultValueSql("'0'")
                    .HasComment("1. 排程將投注紀錄轉換每小時輸贏紀錄\n2. 每隔x分鐘");

                entity.Property(e => e.UrlBetLog)
                    .HasMaxLength(100)
                    .HasColumnName("URL_BetLog")
                    .HasComment("1. 遊戲商投注紀錄 API URL\n2. 遊戲商呼叫中間層 API 時使用\n");

                entity.Property(e => e.UrlKick)
                    .HasMaxLength(300)
                    .HasColumnName("URL_Kick");

                entity.Property(e => e.UrlLogout)
                    .HasMaxLength(100)
                    .HasColumnName("URL_Logout")
                    .HasComment("1. 登出玩家 API URL\n2. 遊戲商呼叫中間層 API 時使用\n");

                entity.Property(e => e.UrlOnline)
                    .HasMaxLength(100)
                    .HasColumnName("URL_Online")
                    .HasComment("1. 取得玩家是否在線 API URL\n2. 遊戲商呼叫中間層 API 時使用\n");

                entity.Property(e => e.UrlPlay)
                    .HasMaxLength(300)
                    .HasColumnName("URL_Play")
                    .HasComment("1. 進入遊戲 URL\n2. 遊戲商呼叫中間層 API 時使用\n");

                entity.Property(e => e.VendorId)
                    .HasMaxLength(50)
                    .HasColumnName("VendorID")
                    .HasComment("1. 遊戲商-商戶號代碼  \\n2. 遊戲商呼叫中間層 API 時使用之 MerchantID");

                entity.Property(e => e.Id2)
                    .HasColumnType("int(11)")
                    .HasComment("遊戲商系統編號");

                entity.Property(e => e.Active)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'0'")
                    .HasComment("啟用狀態");

                entity.Property(e => e.Code)
                    .HasMaxLength(30)
                    .HasComment("遊戲商代碼");

                entity.Property(e => e.CreateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("CURRENT_TIMESTAMP")
                    .HasComment("創建日期");

                entity.Property(e => e.HashKey)
                    .HasMaxLength(45)
                    .HasComment("金鑰");

                entity.Property(e => e.Name)
                    .HasMaxLength(50)
                    .HasComment("遊戲商名稱")
                    .UseCollation("utf8_general_ci")
                    .HasCharSet("utf8");

                entity.Property(e => e.TimeZone)
                    .HasMaxLength(5)
                    .HasDefaultValueSql("'+0'")
                    .HasComment("時區");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
