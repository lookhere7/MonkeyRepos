﻿using System;
using System.Collections.Generic;

namespace Seamless.Core.API.Models
{
    public partial class VendorSubAccount
    {
        /// <summary>
        /// 遊戲商子帳號系統編號
        /// </summary>
        public int Id { get; set; }
        /// <summary>
        /// 遊戲商系統編號
        /// </summary>
        public int? IdVendor { get; set; }
        /// <summary>
        /// 角色系統編號
        /// </summary>
        public int? IdRole { get; set; }
        /// <summary>
        /// 子帳號
        /// </summary>
        public string Account { get; set; }
        /// <summary>
        /// 子帳號密碼
        /// </summary>
        public string Password { get; set; }
        /// <summary>
        /// 子帳號名稱
        /// </summary>
        public string Username { get; set; }
        /// <summary>
        /// 加密金鑰
        /// </summary>
        public string SecretKey { get; set; }
        /// <summary>
        /// 啟用狀態
        /// </summary>
        public sbyte? Active { get; set; }
        /// <summary>
        /// 創建日期
        /// </summary>
        public DateTime? CreateDate { get; set; }
    }
}
