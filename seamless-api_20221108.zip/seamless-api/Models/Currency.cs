﻿using System;
using System.Collections.Generic;

namespace Seamless.Core.API.Models
{
    public partial class Currency
    {
        /// <summary>
        /// 貨幣系統編號
        /// </summary>
        public int Id { get; set; }
        /// <summary>
        /// 貨幣代碼
        /// </summary>
        public string Code { get; set; }
        /// <summary>
        /// 貨幣名稱
        /// </summary>
        public string CurrencyName { get; set; }
        /// <summary>
        /// 啟用狀態
        /// </summary>
        public sbyte? Active { get; set; }
    }
}
