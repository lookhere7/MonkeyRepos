﻿using System;
using System.Collections.Generic;

namespace Seamless.Core.API.Models
{
    public partial class OperatorCondition
    {
        /// <summary>
        /// 系統編號
        /// </summary>
        public int Id { get; set; }
        /// <summary>
        /// 營運商系統編號
        /// </summary>
        public int? IdOperator { get; set; }
        /// <summary>
        /// 遊戲系統編號
        /// </summary>
        public int? IdGame { get; set; }
        /// <summary>
        /// 拆帳比%
        /// </summary>
        public decimal? Ratio { get; set; }
    }
}
