﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MySqlConnector;
using System.Data;

/// <summary>
/// 
/// </summary>
namespace Seamless.Core.API.Data
{
    /// <summary>
    /// 
    /// </summary>
    public class MySQL
    {
        private readonly Models.ManufacturerCMSContext _context = new Models.ManufacturerCMSContext();

        public Model.VendorSeamlessImplementResponse Get_VendorSeamless_Implement(string vendorid, string vcode)
        {
            Model.VendorSeamlessImplementResponse _response = new Model.VendorSeamlessImplementResponse();

            //    try
            //    {
            //        using (var conn = new MySqlConnection(Constants.ConnectionString))
            //        {
            //            conn.Open();
            //            using (var cmd = new MySqlCommand())
            //            {
            //                cmd.Connection = conn;
            //                cmd.CommandType = CommandType.StoredProcedure;
            //                cmd.CommandText = "SP_SEAMLESS_IMPLEMENT_GET";
            //                cmd.Parameters.AddWithValue("@theVendorID", vendorid);
            //                cmd.Parameters.AddWithValue("@theVCode", vcode);
            //                using(MySqlDataAdapter adapter=new MySqlDataAdapter(cmd))
            //                {
            //                    DataSet ds = new DataSet();
            //                    adapter.Fill(ds, "VendorImplementInfo");
            //                    if(ds.Tables.Count>0)
            //                    {
            //                        _response = ds.Tables[0].AsEnumerable().Select(x => new Model.VendorSeamlessImplementResponse()
            //                        {
            //                            CreateDate = x.Field<DateTime>("CreateDate"),
            //                            ExpireDate = x.Field<DateTime>("ExpireDate"),
            //                            MerchantID = x.Field<string>("MerchantID"),
            //                            Id = x.Field<int>("Id"),
            //                            IV = x.Field<string>("IV"),
            //                            KEY = x.Field<string>("KEY"),
            //                            Password = x.Field<string>("Password"),
            //                            SecretKey = x.Field<string>("SecretKey"),
            //                            Id_Operator = x.Field<int>("Id_Operator"),
            //                            VendorHashKey = x.Field<string>("VendorHashKey"),
            //                            ImplementSecretKey = x.Field<string>("ImplementSecretKey"),
            //                            URL_Deposit = x.Field<string>("URL_Deposit"),
            //                            URL_AddVendor = x.Field<string>("URL_AddVendor"),
            //                            URL_AuthenticateUser = x.Field<string>("URL_AuthenticateUser"),
            //                            URL_Balance = x.Field<string>("URL_Balance"),
            //                            URL_Bet = x.Field<string>("URL_Bet"),
            //                            URL_BetLog = x.Field<string>("URL_BetLog"),
            //                            URL_Block = x.Field<string>("URL_Block"),
            //                            URL_BetCancel = x.Field<string>("URL_BetCancel"),
            //                            URL_CreateToken = x.Field<string>("URL_CreateToken"),
            //                            URL_GameList = x.Field<string>("URL_GameList"),
            //                            URL_GetPlayer = x.Field<string>("URL_GetPlayer"),
            //                            URL_KeepAlive = x.Field<string>("URL_KeepAlive"),
            //                            URL_Login = x.Field<string>("URL_Login"),
            //                            URL_Logout = x.Field<string>("URL_Logout"),
            //                            URL_ModifyPlayer = x.Field<string>("URL_ModifyPlayer"),
            //                            URL_Online = x.Field<string>("URL_Online"),
            //                            URL_Play = x.Field<string>("URL_Play"),
            //                            URL_Register = x.Field<string>("URL_Register"),
            //                            URL_RoundSettle = x.Field<string>("URL_RoundSettle"),
            //                            URL_Withdraw = x.Field<string>("URL_Withdraw")                                    
            //                        }).ToList().FirstOrDefault();
            //                    }
            //                }                        
            //            }
            //            conn.Close();
            //            conn.Dispose();
            //        }
            //    }
            //    catch (Exception ex)
            //    {
            //        //Console.WriteLine($"ExecuteErrorLogs Exception: {ex.Message}");                
            //    }
            return _response;
        }

        public List<Models.VendorImplementInfo> Get_VendorSeamless_Implement2(string vendorid, string vcode)
        {
            Model.VendorSeamlessImplementResponse _response = new Model.VendorSeamlessImplementResponse();

            //查詢
            //var id = 1;
            //var post = _context.VendorImplementInfos.Find(vendorid);
            var posts = _context.VendorImplementInfos.Where(p => p.VendorId.Equals(vendorid)).OrderBy(p => p.Id).ToList();
            return posts;
            //新增
            // var post = new Post
            // {
            //     Url = "",
            //     Title = "EF Core",
            //     Read = 0
            // };

            // _context.Post.Add(post);
            // _context.SaveChanges();
        }
    }
}