using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
//using Microsoft.EntityFrameworkCore;
//using Casino.Core.API.Models;
using Microsoft.VisualBasic;
using Microsoft.OpenApi.Models;
using Microsoft.AspNetCore.Http;
using Seamless.Core.API.Utility;
using Seamless.Core.API.Interfaces;
using Seamless.Core.API.Services;
using Prometheus;

namespace Casino.Core.API
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        readonly string MyAllowSpecificOrigins = "_myAllowSpecificOrigins";

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddCors(options =>
            {
                options.AddPolicy(name: MyAllowSpecificOrigins,
                                  builder =>
                                  {
                                      builder.WithOrigins("https://localhost:44314", "*")
                                      .AllowAnyHeader()
                                      .AllowAnyMethod();
                                  });
            });

            services.AddSingleton<IGameService, GameService>();
            services.AddSingleton<IOperatorService, OperatorService>();
            services.AddSingleton<IVendorService, VendorService>();
            services.AddSingleton<ICacheService, CacheService>();
            services.AddSingleton<IPubSubService, PubSubService>();
            services.AddTransient<TimingHandler>();
            services.AddSingleton<Seamless.Core.API.Data.MySQL>();
            services.AddHttpClient("Partner").AddHttpMessageHandler<TimingHandler>();

            services.AddControllers();
            services.AddHealthChecks();

            //services.AddDbContext<CasinoContext>(opt =>
            //   opt.UseSqlServer(Configuration.GetConnectionString("DefaultConnection"), sqlServerOptionsAction: sqlOptions =>
            //   {
            //       sqlOptions.EnableRetryOnFailure(
            //           maxRetryCount: 10,
            //           maxRetryDelay: System.TimeSpan.FromSeconds(30),
            //           errorNumbersToAdd: null
            //           );
            //   }));

            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc(
                    name: "v1",
                    new OpenApiInfo { Title = "Casino API", Version = "v1" }
                    );
            });

            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
            services.AddHttpContextAccessor();
            services.AddStackExchangeRedisCache(options => { options.Configuration = Configuration["RedisCacheUrl"];});
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseHttpsRedirection();

            app.UseRouting();

            app.UseCors(MyAllowSpecificOrigins);

            app.UseAuthorization();

            app.UseMetricServer();

            app.UseHttpMetrics();

            app.UseHealthChecks("/sys/healthz");

            app.UseSwagger();

            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "Casino API V1");
                c.RoutePrefix = string.Empty;
            });

            HttpHelper.Configure(app.ApplicationServices.GetRequiredService<IHttpContextAccessor>());

            app.UseEndpoints(endpoints =>
            {
                //endpoints.MapControllers();
                endpoints.MapMetrics();

                endpoints.MapControllerRoute(
                    name: "Default",
                    pattern: "{controller=default}/{action=Index}/{id?}"
                    );
            });
        }
    }
}
