﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Seamless.Core.API.Data
{
    public class Constants
    {
        //public const string ConnectionString = "server=35.229.167.187;userid=admin;pwd=SWCjTRrF39wrNQ;port=3306;database=ManufacturerCMS;sslmode=none;AllowLoadLocalInfile=True";
        public const string ConnectionString = "server=34.81.242.156;userid=admin;pwd=SWCjTRrF39wrNQ;port=3306;database=ManufacturerCMS;sslmode=none;AllowLoadLocalInfile=True";
    }
}
