﻿using System.Linq;
using System;
using System.Threading.Tasks;
using System.Collections.Generic;
using Microsoft.Extensions.Caching.Distributed;

namespace Seamless.Core.API.Interfaces
{
    public interface IPubSubService
    {
        public Task<string> SeamlessRequestLog<T>(T _model) where T : class;
        public Task<int> PublishMessagesAsync(Model.PubSubRequest model);
        public Task<int> PublishMessagesAsync(string projectId, string topicId, IEnumerable<string> messageTexts);
        public Task<int> PullMessagesAsync(bool acknowledge);
    }
}
