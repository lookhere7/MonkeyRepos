﻿using System;
using System.Collections.Generic;

namespace Seamless.Core.API.Models
{
    public partial class LogApi
    {
        /// <summary>
        /// 系統編號
        /// </summary>
        public int Id { get; set; }
        /// <summary>
        /// Request URL
        /// </summary>
        public string Url { get; set; }
        /// <summary>
        /// Request Data
        /// </summary>
        public string Request { get; set; }
        /// <summary>
        /// 呼叫 API 回應內容
        /// </summary>
        public string Response { get; set; }
        public DateTime? CreateDate { get; set; }
    }
}
