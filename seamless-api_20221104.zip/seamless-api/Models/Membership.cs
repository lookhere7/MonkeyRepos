﻿using System;
using System.Collections.Generic;

namespace Seamless.Core.API.Models
{
    public partial class Membership
    {
        public int Id { get; set; }
        public int? IdOperator { get; set; }
        public int? IdVendor { get; set; }
        public string Username { get; set; }
        public DateTime? CreateDate { get; set; }
        public DateTime? LastLoginDate { get; set; }
    }
}
