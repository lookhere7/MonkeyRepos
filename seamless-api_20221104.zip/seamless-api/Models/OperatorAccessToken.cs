﻿using System;
using System.Collections.Generic;

namespace Seamless.Core.API.Models
{
    public partial class OperatorAccessToken
    {
        /// <summary>
        /// 系統編號
        /// </summary>
        public int Id { get; set; }
        /// <summary>
        /// 營運商系統編號
        /// </summary>
        public int? IdOperator { get; set; }
        /// <summary>
        /// 登入後 Token
        /// </summary>
        public string Token { get; set; }
        /// <summary>
        /// 創建日期
        /// </summary>
        public DateTime? CreateDate { get; set; }
        /// <summary>
        /// Token 過期日期
        /// </summary>
        public DateTime? ExpireDate { get; set; }
    }
}
