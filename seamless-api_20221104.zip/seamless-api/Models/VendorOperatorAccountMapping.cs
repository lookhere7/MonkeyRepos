﻿using System;
using System.Collections.Generic;

namespace Seamless.Core.API.Models
{
    public partial class VendorOperatorAccountMapping
    {
        /// <summary>
        /// 系統編號
        /// </summary>
        public int Id { get; set; }
        /// <summary>
        /// 營運商系統編號
        /// </summary>
        public int? IdOperator { get; set; }
        /// <summary>
        /// 遊戲商系統編號
        /// </summary>
        public int? IdVendor { get; set; }
        /// <summary>
        /// 1. 指向
        /// 2. 1為：營運商連至遊戲商
        /// 3. 2為：遊戲商連至營運商
        /// </summary>
        public int? Route { get; set; }
        /// <summary>
        /// 營運商提供之Id
        /// </summary>
        public string OperatorId { get; set; }
        /// <summary>
        /// 營運商提供之Key
        /// </summary>
        public string OperatorKey { get; set; }
        /// <summary>
        /// 1. 營運商提供之GameId
        /// 2. 由遊戲商呼叫營運商時, 將遊戲商端 GameId 轉換成 營運商 GameId 送出
        /// 
        /// </summary>
        public string OperatorGameId { get; set; }
        /// <summary>
        /// 營運商串接 ID
        /// </summary>
        public string OperatorImplementId { get; set; }
        /// <summary>
        /// 遊戲商串接 ID
        /// </summary>
        public string ImplementId { get; set; }
        /// <summary>
        /// 遊戲商指定呼叫營運商代碼
        /// </summary>
        public string ImplementVcode { get; set; }
        /// <summary>
        /// 帳務代碼 (用於建立及對應注單table名稱)
        /// </summary>
        public string ImplementBillingCode { get; set; }
        /// <summary>
        /// 遊戲代碼 (用於注單對應)
        /// </summary>
        public string ImplementBillingGameCode { get; set; }
        public string UrlPlay { get; set; }
        public string UrlRound { get; set; }
        /// <summary>
        /// 踢人
        /// </summary>
        public string UrlKick { get; set; }
        /// <summary>
        /// 1. 遊戲商投注紀錄 API URL\n2. 遊戲商呼叫中間層 API 時使用\n
        /// </summary>
        public string UrlBetLog { get; set; }
        /// <summary>
        /// 1. 取得玩家是否在線 API URL\n2. 遊戲商呼叫中間層 API 時使用\n
        /// </summary>
        public string UrlOnline { get; set; }
        /// <summary>
        /// 1. 登出玩家 API URL\n2. 遊戲商呼叫中間層 API 時使用\n
        /// </summary>
        public string UrlLogout { get; set; }
        public string UrlApilog { get; set; }
        public string UrlApilogImplementKey { get; set; }
        public string UrlStock { get; set; }
        /// <summary>
        /// 房卡/開桌遊戲 - 回放 API 網址
        /// </summary>
        public string UrlRoomReplay { get; set; }
        /// <summary>
        /// 房卡/開桌遊戲 - 回放 API 網址呼叫金鑰
        /// </summary>
        public string UrlRoomReplayImplementKey { get; set; }
        /// <summary>
        /// 房卡/開桌遊戲 - 拉取游戏记录的对局详情 API 網址
        /// </summary>
        public string UrlRoomRecord { get; set; }
        /// <summary>
        /// 房卡/開桌遊戲 - 拉取游戏记录的对局详情 API 金鑰
        /// </summary>
        public string UrlRoomRecordImplementKey { get; set; }
        /// <summary>
        /// 房卡/開桌遊戲 - 拉取玩家游戏局记录 API 網址
        /// </summary>
        public string UrlRoomUserRecord { get; set; }
        /// <summary>
        /// 房卡/開桌遊戲 - 拉取玩家游戏局记录 API 金鑰
        /// </summary>
        public string UrlRoomUserRecordImplementKey { get; set; }
        /// <summary>
        /// 統計報表對應代碼
        /// </summary>
        public string SummaryCode { get; set; }
        public sbyte? TestMode { get; set; }
        /// <summary>
        /// 創建日期
        /// </summary>
        public DateTime? CreateDate { get; set; }
        /// <summary>
        /// 遊戲系統代碼
        /// </summary>
        public int? GameId { get; set; }
        /// <summary>
        /// 是否啟用
        /// </summary>
        public sbyte? Active { get; set; }
    }
}
