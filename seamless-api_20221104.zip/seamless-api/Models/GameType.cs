﻿using System;
using System.Collections.Generic;

namespace Seamless.Core.API.Models
{
    public partial class GameType
    {
        /// <summary>
        /// 遊戲類型系統編號
        /// </summary>
        public int Id { get; set; }
        /// <summary>
        /// 遊戲類型代碼
        /// </summary>
        public string Code { get; set; }
        /// <summary>
        /// 遊戲類型名稱
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// 啟用狀態
        /// </summary>
        public sbyte? Active { get; set; }
    }
}
