﻿using System;
using System.Collections.Generic;

namespace Seamless.Core.API.Models
{
    public partial class VendorMenu
    {
        /// <summary>
        /// 系統編號
        /// </summary>
        public int Id { get; set; }
        /// <summary>
        /// 選單代碼
        /// </summary>
        public string Code { get; set; }
        /// <summary>
        /// 選單名稱
        /// </summary>
        public string MenuName { get; set; }
        /// <summary>
        /// 選單層級
        /// </summary>
        public int? Depth { get; set; }
        /// <summary>
        /// 上層選單編號
        /// </summary>
        public string Parent { get; set; }
        /// <summary>
        /// 超連結
        /// </summary>
        public string HyperLink { get; set; }
        /// <summary>
        /// 選單圖示
        /// </summary>
        public string Icon { get; set; }
        /// <summary>
        /// 啟用狀態
        /// </summary>
        public sbyte? Active { get; set; }
    }
}
