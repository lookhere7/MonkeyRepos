﻿using System;
using System.Collections.Generic;

namespace Seamless.Core.API.Models
{
    public partial class VendorSubAccountPermission
    {
        /// <summary>
        /// 權限系統編號
        /// </summary>
        public int Id { get; set; }
        /// <summary>
        /// 子帳號系統編號
        /// </summary>
        public int? IdSubAccount { get; set; }
        /// <summary>
        /// 選單系統編號
        /// </summary>
        public int? IdMenu { get; set; }
    }
}
