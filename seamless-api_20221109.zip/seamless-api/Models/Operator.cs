﻿using System;
using System.Collections.Generic;

namespace Seamless.Core.API.Models
{
    public partial class Operator
    {
        /// <summary>
        /// 營運商系統編號
        /// </summary>
        public int Id { get; set; }
        public string ApiCode { get; set; }
        /// <summary>
        /// 營運商名稱
        /// </summary>
        public string OperatorName { get; set; }
        /// <summary>
        /// 營運商餘額
        /// </summary>
        public decimal? Balance { get; set; }
        /// <summary>
        /// 技術窗口聯絡人名稱
        /// </summary>
        public string TechName { get; set; }
        /// <summary>
        /// 技術窗口聯絡人電子郵件
        /// </summary>
        public string TechMail { get; set; }
        /// <summary>
        /// 帳務聯絡人名稱
        /// </summary>
        public string BillName { get; set; }
        /// <summary>
        /// 帳務聯絡人電子郵件
        /// </summary>
        public string BillMail { get; set; }
        /// <summary>
        /// 1: 現金制, 2:信用制
        /// </summary>
        public int? BillType { get; set; }
        /// <summary>
        /// 帳務比例
        /// </summary>
        public int? BillScale { get; set; }
        /// <summary>
        /// 時區
        /// </summary>
        public string TimeZone { get; set; }
        /// <summary>
        /// 1: 啟用, 2:欠費: 3停用
        /// </summary>
        public int? Active { get; set; }
        /// <summary>
        /// 角色系統編號
        /// </summary>
        public int? IdRole { get; set; }
        /// <summary>
        /// 後台登入用帳號
        /// </summary>
        public string Username { get; set; }
        /// <summary>
        /// 後台登入用密碼
        /// </summary>
        public string Password { get; set; }
        /// <summary>
        /// 加密金鑰
        /// </summary>
        public string SecretKey { get; set; }
        /// <summary>
        /// 創建日期
        /// </summary>
        public DateTime? CreateDate { get; set; }
    }
}
