﻿using System;
using System.Collections.Generic;

namespace Seamless.Core.API.Models
{
    public partial class LogOperatorExecute
    {
        /// <summary>
        /// 系統編號
        /// </summary>
        public int Id { get; set; }
        /// <summary>
        /// 營運商系統編號
        /// </summary>
        public int? IdAccount { get; set; }
        /// <summary>
        /// 功能選單系統編號
        /// </summary>
        public int? IdMenu { get; set; }
        /// <summary>
        /// 子功能選單系統編號
        /// </summary>
        public int? IdSubMenu { get; set; }
        public string Action { get; set; }
        /// <summary>
        /// API Route
        /// </summary>
        public string Route { get; set; }
        /// <summary>
        /// 操作要求內容
        /// </summary>
        public string Request { get; set; }
        /// <summary>
        /// 操作回應內容
        /// </summary>
        public string Response { get; set; }
        /// <summary>
        /// 操作時間
        /// </summary>
        public DateTime? CreateDate { get; set; }
    }
}
