﻿using System;
using System.Collections.Generic;

namespace Seamless.Core.API.Models
{
    public partial class Game
    {
        /// <summary>
        /// 遊戲系統編號
        /// </summary>
        public int Id { get; set; }
        /// <summary>
        /// 遊戲商系統編號
        /// </summary>
        public int? IdVendor { get; set; }
        /// <summary>
        /// 遊戲代碼
        /// </summary>
        public string Code { get; set; }
        /// <summary>
        /// 遊戲類型系統編號
        /// </summary>
        public int? IdGameType { get; set; }
        /// <summary>
        /// 遊戲名稱
        /// </summary>
        public string GameName { get; set; }
        public sbyte? Rtp { get; set; }
        /// <summary>
        /// 遊戲 Logo (小)
        /// </summary>
        public string SLogo { get; set; }
        /// <summary>
        /// 遊戲 Logo (大)
        /// </summary>
        public string LLogo { get; set; }
        /// <summary>
        /// 上市時間
        /// </summary>
        public DateTime? LaunchTime { get; set; }
        /// <summary>
        /// 是否支援H5
        /// </summary>
        public sbyte? IsH5 { get; set; }
        /// <summary>
        /// 啟用狀態
        /// </summary>
        public sbyte? Active { get; set; }
    }
}
