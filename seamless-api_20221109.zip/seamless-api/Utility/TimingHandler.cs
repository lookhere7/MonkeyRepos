﻿using System.Diagnostics;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace Seamless.Core.API.Utility
{
    public class TimingHandler : DelegatingHandler
    {
        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request,
        CancellationToken cancellationToken)
        {
            var sw = Stopwatch.StartNew();
            var response = await base.SendAsync(request, cancellationToken);
            sw.Stop();
            response.Headers.Add("X-Partner-ElapsedTime", sw.Elapsed.TotalSeconds.ToString());
            
            return response;
        }

        //protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        //{
        //    var sw = Stopwatch.StartNew();
        //    var response = await base.SendAsync(request, cancellationToken);
        //    sw.Stop();
        //    response.Headers.Add("X-Partner-ElapsedTime", sw.Elapsed.TotalSeconds.ToString());            

        //    return response;
        //}
    }
}
