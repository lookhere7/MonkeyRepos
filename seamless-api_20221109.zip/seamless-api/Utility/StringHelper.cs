﻿using System;

namespace Seamless.Core.API.Utility
{
    public class StringHelper
    {
        /// <summary>
        /// 隨機產生指定長度編號
        /// </summary>
        /// <param name="length"></param>
        /// <returns></returns>
        public static string makeTransactionId(int length)
        {
            //返回的字串
            string tmpstr = "";
            //密碼中包含的字符數組
            string pwdchars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
            //數組索引隨機亂數
            int iRandNum;
            //隨機亂數生成
            Random rnd = new Random();
            for (int i = 0; i < length; i++)
            {
                //Random類的Next方法生成一個指定範圍的隨機亂數
                iRandNum = rnd.Next(pwdchars.Length);
                //tmpstr隨機添加一個字符
                tmpstr += pwdchars[iRandNum];
            }
            return tmpstr;
        }
    }
}
