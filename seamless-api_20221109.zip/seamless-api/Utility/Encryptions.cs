﻿using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace Seamless.Core.API.Utility
{
    public class Encryptions
    {
        public static string AesKey = "_Hdi2l3cnv&"; //密鑰
        public static string AesIv = "clsh3ppp3828@s_"; //密鑰向量

        /// <summary>
        /// AES 加密字串
        /// </summary>
        /// <param name="original">原始字串</param>
        /// <param name="key">自訂金鑰</param>
        /// <param name="iv">自訂向量</param>
        /// <returns></returns>
        public static string AesEncrypt(string original, string key = null, string iv = null)
        {
            key = string.IsNullOrEmpty(key) ? AesKey : key;
            iv = string.IsNullOrEmpty(iv) ? AesIv : iv;

            string encrypt = "";
            try
            {
                AesCryptoServiceProvider aes = new AesCryptoServiceProvider();
                MD5CryptoServiceProvider md5 = new MD5CryptoServiceProvider();
                SHA256CryptoServiceProvider sha256 = new SHA256CryptoServiceProvider();
                byte[] keyData = sha256.ComputeHash(Encoding.UTF8.GetBytes(key));
                byte[] ivData = md5.ComputeHash(Encoding.UTF8.GetBytes(iv));
                byte[] dataByteArray = Encoding.UTF8.GetBytes(original);

                using (MemoryStream ms = new MemoryStream())
                {
                    using (
                        CryptoStream cs = new CryptoStream(ms, aes.CreateEncryptor(keyData, ivData), CryptoStreamMode.Write)
                    )
                    {
                        cs.Write(dataByteArray, 0, dataByteArray.Length);
                        cs.FlushFinalBlock();
                        encrypt = Convert.ToBase64String(ms.ToArray());
                    }
                }
            }
            catch
            {
            }

            return encrypt;
        }

        /// <summary>
        /// AES 解密字串
        /// </summary>
        /// <param name="hexString">已加密字串</param>
        /// <param name="key">自訂金鑰</param>
        /// <param name="iv">自訂向量</param>
        /// <returns></returns>
        public static string AesDecrypt(string hexString, string key = null, string iv = null)
        {
            key = string.IsNullOrEmpty(key) ? AesKey : key;
            iv = string.IsNullOrEmpty(iv) ? AesIv : iv;

            string decrypt = hexString;
            try
            {
                SymmetricAlgorithm aes = new AesCryptoServiceProvider();
                MD5CryptoServiceProvider md5 = new MD5CryptoServiceProvider();
                SHA256CryptoServiceProvider sha256 = new SHA256CryptoServiceProvider();
                byte[] keyData = sha256.ComputeHash(Encoding.UTF8.GetBytes(key));
                byte[] ivData = md5.ComputeHash(Encoding.UTF8.GetBytes(iv));
                byte[] dataByteArray = Convert.FromBase64String(hexString);

                using (MemoryStream ms = new MemoryStream())
                {
                    using (
                        CryptoStream cs = new CryptoStream(ms, aes.CreateDecryptor(keyData, ivData), CryptoStreamMode.Write)
                    )
                    {
                        cs.Write(dataByteArray, 0, dataByteArray.Length);
                        cs.FlushFinalBlock();
                        decrypt = Encoding.UTF8.GetString(ms.ToArray());
                    }
                }
            }
            catch
            {
                //todo...
            }

            return decrypt;
        }

        public static bool TryAesDecrypt(string hexString, out string original, string key = null, string iv = null)
        {
            return hexString != (original = AesDecrypt(hexString, key, iv));
        }

        /// <summary>
        /// AES 加密檔案
        /// </summary>
        /// <param name="sourceFile">原始檔案路徑</param>
        /// <param name="encryptFile">加密後檔案路徑</param>
        /// <param name="key">自訂金鑰</param>
        /// <param name="iv">自訂向量</param>
        public static bool AesEncryptFile(string sourceFile, string encryptFile, string key = null, string iv = null)
        {
            key = string.IsNullOrEmpty(key) ? AesKey : key;
            iv = string.IsNullOrEmpty(iv) ? AesIv : iv;

            if (string.IsNullOrEmpty(sourceFile) || string.IsNullOrEmpty(encryptFile) || !File.Exists(sourceFile))
            {
                return false;
            }

            try
            {
                AesCryptoServiceProvider aes = new AesCryptoServiceProvider();
                MD5CryptoServiceProvider md5 = new MD5CryptoServiceProvider();
                SHA256CryptoServiceProvider sha256 = new SHA256CryptoServiceProvider();
                byte[] keyData = sha256.ComputeHash(Encoding.UTF8.GetBytes(key));
                byte[] ivData = md5.ComputeHash(Encoding.UTF8.GetBytes(iv));
                aes.Key = keyData;
                aes.IV = ivData;

                using (FileStream sourceStream = new FileStream(sourceFile, FileMode.Open, FileAccess.Read))
                {
                    using (FileStream encryptStream = new FileStream(encryptFile, FileMode.Create, FileAccess.Write))
                    {
                        //檔案加密
                        byte[] dataByteArray = new byte[sourceStream.Length];
                        sourceStream.Read(dataByteArray, 0, dataByteArray.Length);

                        using (CryptoStream cs = new CryptoStream(encryptStream, aes.CreateEncryptor(), CryptoStreamMode.Write))
                        {
                            cs.Write(dataByteArray, 0, dataByteArray.Length);
                            cs.FlushFinalBlock();
                        }
                    }
                }
            }
            catch
            {
                //todo...
                return false;
            }

            return true;
        }

        /// <summary>
        /// AES 解密檔案
        /// </summary>
        /// <param name="encryptFile"></param>
        /// <param name="decryptFile"></param>
        /// <param name="key"></param>
        /// <param name="iv"></param>
        /// <returns></returns>
        public static bool AesDecryptFile(string encryptFile, string decryptFile, string key = null, string iv = null)
        {
            key = string.IsNullOrEmpty(key) ? AesKey : key;
            iv = string.IsNullOrEmpty(iv) ? AesIv : iv;

            if (string.IsNullOrEmpty(encryptFile) || string.IsNullOrEmpty(decryptFile) || !File.Exists(encryptFile))
            {
                return false;
            }

            try
            {
                AesCryptoServiceProvider aes = new AesCryptoServiceProvider();
                MD5CryptoServiceProvider md5 = new MD5CryptoServiceProvider();
                SHA256CryptoServiceProvider sha256 = new SHA256CryptoServiceProvider();
                byte[] keyData = sha256.ComputeHash(Encoding.UTF8.GetBytes(key));
                byte[] ivData = md5.ComputeHash(Encoding.UTF8.GetBytes(iv));
                aes.Key = keyData;
                aes.IV = ivData;

                using (FileStream encryptStream = new FileStream(encryptFile, FileMode.Open, FileAccess.Read))
                {
                    using (FileStream decryptStream = new FileStream(decryptFile, FileMode.Create, FileAccess.Write))
                    {
                        byte[] dataByteArray = new byte[encryptStream.Length];
                        encryptStream.Read(dataByteArray, 0, dataByteArray.Length);
                        using (CryptoStream cs = new CryptoStream(decryptStream, aes.CreateDecryptor(), CryptoStreamMode.Write))
                        {
                            cs.Write(dataByteArray, 0, dataByteArray.Length);
                            cs.FlushFinalBlock();
                        }
                    }
                }
            }
            catch
            {
                //todo...
                return false;
            }

            return true;
        }

        public static String MD5_Generate(String str)
        {
            System.Security.Cryptography.MD5CryptoServiceProvider md5Hasher = new System.Security.Cryptography.MD5CryptoServiceProvider();
            Byte[] data = md5Hasher.ComputeHash((new System.Text.ASCIIEncoding()).GetBytes(str));
            System.Text.StringBuilder sBuilder = new System.Text.StringBuilder();
            for (int i = 0; i < data.Length; i++)
            {
                sBuilder.Append(data[i].ToString("x2"));
            }
            return sBuilder.ToString();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="fileContents"></param>
        /// <returns></returns>
        public static string File_Hash(string fileContents)
        {
            string response = string.Empty;
            using (HashAlgorithm hashAlgorithm = SHA256.Create())
            {
                byte[] plainText = Encoding.UTF8.GetBytes(fileContents);
                byte[] hash = hashAlgorithm.ComputeHash(plainText);

                response = ToHexString(hash);
                Console.WriteLine(ToHexString(hash));
            }

            return response;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="bytes"></param>
        /// <returns></returns>
        private static string ToHexString(byte[] bytes)
        {
            string hexString = string.Empty;
            if (bytes != null)
            {
                StringBuilder str = new StringBuilder();

                for (int i = 0; i < bytes.Length; i++)
                {
                    str.Append(bytes[i].ToString("X2"));
                }
                hexString = str.ToString();
            }
            return hexString;
        }
    }
}
