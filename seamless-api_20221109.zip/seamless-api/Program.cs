using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.OpenApi.Models;
using Prometheus;
using Seamless.Core.API.Interfaces;
using Seamless.Core.API.Services;
using Seamless.Core.API.Utility;
using System.Reflection;
using System;
using System.IO;

var builder = WebApplication.CreateBuilder(args);
var MyAllowSpecificOrigins = "_myAllowSpecificOrigins";
ConfigurationManager configuration = builder.Configuration;
// Add services to the container.
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle

builder.Services.AddCors(options =>
{
    options.AddPolicy(name: MyAllowSpecificOrigins,
                      builder =>
                      {
                          builder.WithOrigins("https://localhost:44314", "*")
                          .AllowAnyHeader()
                          .AllowAnyMethod();
                      });
});

builder.Services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
builder.Services.AddSingleton<IGameService, GameService>();
builder.Services.AddSingleton<IOperatorService, OperatorService>();
builder.Services.AddSingleton<IVendorService, VendorService>();
builder.Services.AddSingleton<ICacheService, CacheService>();
builder.Services.AddSingleton<IPubSubService, PubSubService>();
builder.Services.AddSingleton<Seamless.Core.API.Data.MySQL>();
builder.Services.AddTransient<TimingHandler>();
builder.Services.AddHttpClient("Partner").AddHttpMessageHandler<TimingHandler>();

builder.Services.AddControllers();
builder.Services.AddHealthChecks();

//services.AddDbContext<CasinoContext>(opt =>
//   opt.UseSqlServer(Configuration.GetConnectionString("DefaultConnection"), sqlServerOptionsAction: sqlOptions =>
//   {
//       sqlOptions.EnableRetryOnFailure(
//           maxRetryCount: 10,
//           maxRetryDelay: System.TimeSpan.FromSeconds(30),
//           errorNumbersToAdd: null
//           );
//   }));

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc(
        name: "v1",
        new OpenApiInfo { Title = "Casino API", Version = "v1" }
        );

    // 讀取 XML 檔案產生 API 說明
    var xmlFile = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
    var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
    c.IncludeXmlComments(xmlPath);
});

builder.Services.AddDistributedMemoryCache();
builder.Services.AddHttpContextAccessor();
builder.Services.AddStackExchangeRedisCache(options => { options.Configuration = configuration["RedisCacheUrl"]; });

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseDeveloperExceptionPage();
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseRouting();

app.UseCors(MyAllowSpecificOrigins);

app.UseAuthorization();

app.UseMetricServer();

app.UseHealthChecks("/sys/healthz");

app.UseSwagger();

app.UseSwaggerUI(c =>
{
    c.SwaggerEndpoint("/swagger/v1/swagger.json", "Casino API V1");
    c.RoutePrefix = string.Empty;
});

HttpHelper.Configure(app.Services.GetRequiredService<IHttpContextAccessor>());

app.UseEndpoints(endpoints =>
{
    //endpoints.MapControllers();
    endpoints.MapMetrics();

    endpoints.MapControllerRoute(
        name: "Default",
        pattern: "{controller=default}/{action=Index}/{id?}"
        );
});

// app.UseHttpMetrics(options=>
// {
//     options.RequestCount.Enabled = false;   
// });

app.Run();