﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Routing;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
//using Newtonsoft.Json;
using Prometheus;
using Seamless.Core.API.Interfaces;
using Seamless.Core.API.Utility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;

/// <summary>
/// 
/// </summary>
namespace Seamless.Core.API.Controllers
{
    /// <summary>
    /// 
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class ExternalController : ControllerBase
    {
        /// <summary>
        /// 
        /// </summary>
        private readonly Models.ManufacturerCMSContext _context = new Models.ManufacturerCMSContext();
        #region Interfaces

        /// <summary>
        /// 
        /// </summary>
        private readonly IHttpContextAccessor _httpContextAccessor;

        /// <summary>
        /// 
        /// </summary>
        private readonly IGameService _gameService;

        /// <summary>
        /// 
        /// </summary>
        private readonly IOperatorService _operatorService;

        /// <summary>
        /// 
        /// </summary>
        private readonly IVendorService _vendorService;

        /// <summary>
        /// 
        /// </summary>
        private readonly ILogger<ExternalController> _logger;

        /// <summary>
        /// 
        /// </summary>
        private readonly IHttpClientFactory _httpClientFactory;

        /// <summary>
        /// 
        /// </summary>
        private readonly IConfiguration _configuration;

        /// <summary>
        /// 
        /// </summary>
        private readonly ICacheService _cacheService;

        private readonly IPubSubService _pubsubService;

        private static readonly Histogram HttpPartnerHistogram = Metrics
        .CreateHistogram("http_request_duration_seconds_partner", "request duration in seconds",
            new HistogramConfiguration
            {
                Buckets = Histogram.ExponentialBuckets(0.001, 2, 16),
                LabelNames = new[] { "method", "controller", "action", "partner_code", "partner_host", "partner_uri", "partner_method" }
            });

        #endregion

        private readonly Seamless.Core.API.Data.MySQL _mysql = new();

        /// <summary>
        /// 
        /// </summary>
        /// <param name="httpContextAccessor"></param>
        public ExternalController(IHttpContextAccessor httpContextAccessor, IOperatorService operatorService, IVendorService vendorService, IGameService gameService, ILogger<ExternalController> logger, IHttpClientFactory httpClientFactory, IConfiguration configuration, ICacheService cacheService, Seamless.Core.API.Data.MySQL mysql, IPubSubService pubsubService)
        {
            this._httpContextAccessor = httpContextAccessor;
            this._gameService = gameService;
            this._operatorService = operatorService;
            this._vendorService = vendorService;
            this._logger = logger;
            this._httpClientFactory = httpClientFactory;
            this._configuration = configuration;
            this._cacheService = cacheService;
            this._mysql = mysql;
            this._pubsubService = pubsubService;
        }

        private string[] GetAllLabelValues(HttpRequestMessage request, HttpResponseMessage response)
        {
            var RouteData = HttpContext.GetRouteData()?.Values;
            var Controller = RouteData?.GetValueOrDefault("controller", string.Empty) as string ?? string.Empty;
            var Action = RouteData?.GetValueOrDefault("action", string.Empty) as string ?? string.Empty;
            var Method = HttpContext.Request.Method.ToString();

            var PartnerCode = ((int)response.StatusCode).ToString();
            var PartnerHost = request.RequestUri?.Host ?? string.Empty;
            var PartnerPath = request.RequestUri?.AbsolutePath ?? string.Empty; ;
            var PartnerMethod = request.Method.ToString();

            return new[] { Method, Controller, Action, PartnerCode, PartnerHost, PartnerPath, PartnerMethod };
        }

        private double GetElapsedTimeFromHeader(HttpResponseMessage response, string key = "X-Partner-ElapsedTime")
        {
            //var elapsedTime = response.Headers.GetValues(key).FirstOrDefault();
            var elapsedTime = DateTime.UtcNow.ToString("yyyy-MM-dd HH:mm:ss.fff");
            if (string.IsNullOrEmpty(elapsedTime))
                elapsedTime = "0";
            else
            {
                DateTime current = DateTime.UtcNow;
                DateTime before = DateTime.Parse(elapsedTime);
                elapsedTime = (current - before).TotalSeconds.ToString();
            }

            return Convert.ToDouble(elapsedTime);
        }

        #region Table

        [HttpPost, Route("Deduction")]
        public Model.DefaultResponse Deduction()
        {
            Model.DefaultResponse _response = new Model.DefaultResponse();


            return _response;
        }

        [HttpPost, Route("DeductionRefund")]
        public Model.DefaultResponse DeductionRefund()
        {
            Model.DefaultResponse _response = new Model.DefaultResponse();


            return _response;
        }


        [HttpPost, Route("DeductionSettle")]
        public Model.DefaultResponse DeductionSettle()
        {
            Model.DefaultResponse _response = new Model.DefaultResponse();


            return _response;
        }

        #endregion

        #region Seamless        

        /// <summary>
        /// 建立測試 Token - 僅支援平台商端測試環境
        /// </summary>
        /// <param name="_model">Model.Vendor.CreateTokenRequest</param>
        [HttpPost, Route("CreateToken")]
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public async Task<Model.DefaultResponse> CreateToken(Model.Vendor.CreateTokenRequest _model)
        {
            Model.DefaultResponse _response = new();
            Model.PubSubRequest _model_pubsub = new();
            _response.type = "CreateToken";
            //設定記錄Pub/Sub相關參數
            _model_pubsub.merchantid = _model.data.merchantid;
            _model_pubsub.vcode = _model.data.vcode;
            _model_pubsub.gameid = _model.data.gameid;

            try
            {
                #region 驗證相關欄位並取得相關Table資料
                //設定驗證欄位
                var _verifyfields = "merchantid,vcode,gameid";
                //取得相關Table資料(資料已Redis)
                var _vendordataresponse = await _vendorService.GetVendorData<Model.Vendor.CreateTokenRequest, Model.Vendor.CreateTokenRequestParams>(_model, _model.data, _verifyfields, _response, _model_pubsub);
                _response = _vendordataresponse.DefaultResponse;
                if (_response.code != 0) return _response;
                #endregion

                //取得相關Table資料
                var _vendoroperatoraccountmapping = _vendordataresponse.Redis_VendorOperatorAccountMapping;
                var _operatorimplementinfo = _vendordataresponse.Redis_OperatorImplementInfo;
                var _apicode = _vendordataresponse.ApiCode;
                string _uri = _operatorimplementinfo.UrlCreateToken;
                string _newgameid = _vendordataresponse.NewGameID;
                _model_pubsub.url = _uri;

                switch (_vendoroperatoraccountmapping.TestMode)
                {
                    case 0:
                        Services.External.CallBackService _callback = new Services.External.CallBackService(_httpContextAccessor);

                        if (_apicode == "08online")
                        {
                            _uri = $"{_uri}?gameid={_newgameid}";

                            var _request = new { gameId = _newgameid };

                            #region 使用HttpClient呼叫API
                            var starttime = DateTime.Now;
                            var _data = await _callback.ExecuteAsync(_request, HttpMethod.Get, _uri, null, null);
                            //var _data = _callback.Execute(_request, HttpMethod.Get, _uri, null, null);
                            var endtime = DateTime.Now;
                            var apiresponsetime = (endtime - starttime).TotalMilliseconds / 1000;
                            #endregion

                            if (_data.code != 200)
                            {
                                _response.code = _data.code;
                                _response.status = $"Failure - statusCode not 200({_data.code.ToString()})";

                                //Todo:失敗則記錄普羅米修斯

                                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                                _model_pubsub.type = $"{_response.type} [{_apicode}]CallBackAPI.ExecuteAsync";
                                _model_pubsub.url = _uri;
                                _model_pubsub.responsedata = _response;
                                await _pubsubService.PublishMessagesAsync(_model_pubsub);
                            }
                            if (_response.code != 0) return _response;

                            //Todo:成功則記錄普羅米修斯

                            _response.code = 0;
                            _response.status = "Successful";
                            _response.result = new { token = JsonSerializer.Deserialize<dynamic>(_data.result) };
                            _response.additional = new { token = JsonSerializer.Deserialize<dynamic>(_data.result) };

                            //記錄LOG:API 呼叫記錄寫入 Pub/Sub(End)
                            #region 記錄LOG:API 呼叫記錄寫入 Pub/Sub(End)
                            _model_pubsub.type = $"{_response.type} End";
                            _model_pubsub.url = _uri;
                            _model_pubsub.responsedata = _response;
                            int _messagecount = await _pubsubService.PublishMessagesAsync(_model_pubsub);
                            #endregion
                        }
                        else if (_apicode == "aceonline")
                        {
                            string[] headers = { "x-api-key" };
                            string[] values = { "e495964cb27748859d1060f53a2d3ba2" };

                            var _request = new { gameId = _newgameid };

                            #region 使用HttpClient呼叫API
                            var starttime = DateTime.Now;
                            //var _data = await _callback.ExecuteAsync(_request, HttpMethod.Post, _uri, headers, values);
                            var _data = _callback.Execute(_request, HttpMethod.Post, _uri, headers, values);
                            var endtime = DateTime.Now;
                            var apiresponsetime = (endtime - starttime).TotalMilliseconds / 1000;
                            #endregion

                            //取得API回傳result內各屬性的值
                            var dynamicObject = Newtonsoft.Json.JsonConvert.DeserializeObject<dynamic>(_data.result)!;
                            var _bodystatuscode = dynamicObject.statusCode.Value;
                            var _bodyuserId = dynamicObject.userId.Value;
                            var _bodytoken = dynamicObject.token.Value;

                            if (_data.code != 200)
                            {
                                _response.code = _data.code;
                                _response.status = $"Failure - statusCode not 200({_bodystatuscode.ToString()})";

                                //Todo:失敗則記錄普羅米修斯

                                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                                _model_pubsub.type = $"{_response.type} [{_apicode}]CallBackAPI.ExecuteAsync";
                                _model_pubsub.url = _uri;
                                _model_pubsub.responsedata = _response;
                                await _pubsubService.PublishMessagesAsync(_model_pubsub);
                            }
                            if (_response.code != 0) return _response;

                            if (_bodystatuscode == "RS_ERROR_SYSTEM_IN_MAINTAIN")
                            {
                                _response.code = 9998;
                            }
                            else if (_bodystatuscode == "RS_ERROR_INVALID_USER_TOKEN" || _bodystatuscode == "RS_ERROR_INVALID_ACCOUNT_TOKEN")
                            {
                                _response.code = 9997;
                            }
                            if (_response.code != 0) return _response;

                            //Todo:成功則記錄普羅米修斯

                            _response.code = 0;
                            _response.status = "Successful";
                            _response.result = JsonSerializer.Deserialize<dynamic>(_data.result);
                            _response.additional = new { userId = _bodyuserId, token = _bodytoken };

                            //記錄LOG:API 呼叫記錄寫入 Pub/Sub(End)
                            #region 記錄LOG:API 呼叫記錄寫入 Pub/Sub(End)
                            _model_pubsub.type = _response.type + " End";
                            _model_pubsub.url = _uri;
                            _model_pubsub.responsedata = _response;
                            int _messagecount = await _pubsubService.PublishMessagesAsync(_model_pubsub);
                            #endregion
                        }
                        else
                        {
                            _response.code = 0;
                            _response.status = "Successful - external";
                        }

                        break;
                    case 1:
                        _response.code = 0;
                        _response.status = "Successful - test mode";
                        break;
                }
            }
            catch (Exception ex)
            {
                _response.code = 9999;
                _response.status = ex.Message;

                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                _model_pubsub.type = $"{_response.type} Catch Exception";
                _model_pubsub.responsedata = _response;
                await _pubsubService.PublishMessagesAsync(_model_pubsub);
            }

            return _response;
        }

        /// <summary>
        /// 認證 User Token
        /// </summary>
        /// <param name="_model"></param>
        /// <returns></returns>
        [HttpPost, Route("AuthenticateToken")]
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public async Task<Model.DefaultResponse> Auth(Model.Vendor.AuthRequest _model)
        {
            Model.DefaultResponse _response = new();
            Model.PubSubRequest _model_pubsub = new();
            _response.type = "AuthToken";
            //設定記錄Pub/Sub相關參數
            _model_pubsub.merchantid = _model.data.merchantid;
            _model_pubsub.vcode = _model.data.vcode;
            _model_pubsub.usertoken = _model.data.usertoken;
            _model_pubsub.sessiontoken = _model.data.sessiontoken;

            try
            {
                #region 驗證相關欄位並取得相關Table資料
                //設定驗證欄位
                var _verifyfields = "merchantid,vcode,usertoken";
                //取得相關Table資料(資料已Redis)
                var _vendordataresponse = await _vendorService.GetVendorData<Model.Vendor.AuthRequest, Model.Vendor.AuthRequestParams>(_model, _model.data, _verifyfields, _response, _model_pubsub);
                _response = _vendordataresponse.DefaultResponse;
                if (_response.code != 0) return _response;
                #endregion

                //取得相關Table資料
                var _vendoroperatoraccountmapping = _vendordataresponse.Redis_VendorOperatorAccountMapping;
                var _operatorimplementinfo = _vendordataresponse.Redis_OperatorImplementInfo;
                var _apicode = _vendordataresponse.ApiCode;
                var _operatorimplementinfosecretkey = _operatorimplementinfo.SecretKey;
                var _idoperator = _operatorimplementinfo.IdOperator;
                var _idvendor = _vendoroperatoraccountmapping.IdVendor;
                string _uri = _operatorimplementinfo.UrlAuthenticateUser;
                string _newgameid = _vendordataresponse.NewGameID;
                _model_pubsub.url = _uri;

                switch (_vendoroperatoraccountmapping.TestMode)
                {
                    case 0:
                        Services.External.CallBackService _callback = new Services.External.CallBackService(_httpContextAccessor);

                        if (_apicode == "08online")
                        {
                            var _uid = StringHelper.makeTransactionId(16);
                            var _currenttime = DateTime.Now.ToString("yyyy/MM/dd HH:MM:ss");

                            var _formdata = new
                            {
                                reqid = _uid,
                                token = _model.data.usertoken
                            };
                            var _formhash = Utility.Encryptions.MD5_Generate(JsonSerializer.Serialize(_formdata) + _operatorimplementinfosecretkey);

                            var _request = new { data = _formdata, hash = _formhash };

                            #region 使用HttpClient呼叫API
                            var starttime = DateTime.Now;
                            var _data = await _callback.ExecuteAsync(_request, HttpMethod.Post, _uri, null, null);
                            //var _data = _callback.Execute(_request, HttpMethod.Get, _uri, null, null);
                            var endtime = DateTime.Now;
                            var apiresponsetime = (endtime - starttime).TotalMilliseconds / 1000;
                            #endregion

                            //取得API回傳result內各屬性的值
                            var dynamicObject = Newtonsoft.Json.JsonConvert.DeserializeObject<dynamic>(_data.result)!;
                            var _bodycode = dynamicObject.code.Value;
                            var _bodymessage = dynamicObject.message.Value;
                            var _bodyresultusername = dynamicObject.result.username.Value;
                            var _bodyresult = Newtonsoft.Json.JsonConvert.SerializeObject(dynamicObject.result);

                            if (_data.code != 200)
                            {
                                _response.code = _data.code;
                                _response.status = $"Failure - statusCode not 200({_data.code.ToString()})";

                                //Todo:失敗則記錄普羅米修斯

                                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                                _model_pubsub.type = $"{_response.type} [{_apicode}]CallBackAPI.ExecuteAsync";
                                _model_pubsub.url = _uri;
                                _model_pubsub.responsedata = _response;
                                await _pubsubService.PublishMessagesAsync(_model_pubsub);
                            }
                            if (_response.code != 0) return _response;

                            //Todo:成功則記錄普羅米修斯

                            //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                            dynamic _dynamicrequest = new { idoperator = _idoperator, idvendor = _idvendor, username = _bodyresultusername };
                            await _pubsubService.PublishMessagesAsync(_dynamicrequest);

                            _response.code = 0;
                            _response.status = "Successful";
                            if (_bodycode != 0)
                            {
                                _response.code = (int)_bodycode;
                                _response.status = _bodymessage;
                            }
                            _response.result = JsonSerializer.Deserialize<dynamic>(_bodyresult);

                            //記錄LOG:API 呼叫記錄寫入 Pub/Sub(End)
                            #region 記錄LOG:API 呼叫記錄寫入 Pub/Sub(End)
                            _model_pubsub.type = $"{_response.type} End";
                            _model_pubsub.url = _uri;
                            _model_pubsub.responsedata = _response;
                            int _messagecount = await _pubsubService.PublishMessagesAsync(_model_pubsub);
                            #endregion
                        }
                        else if (_apicode == "aceonline")
                        {
                            string[] headers = { "x-api-key" };
                            string[] values = { "e495964cb27748859d1060f53a2d3ba2" };

                            var _request = new { userToken = _model.data.usertoken };

                            #region 使用HttpClient呼叫API
                            var starttime = DateTime.Now;
                            //var _data = await _callback.ExecuteAsync(_request, HttpMethod.Post, _uri, headers, values);
                            var _data = _callback.Execute(_request, HttpMethod.Post, _uri, headers, values);
                            var endtime = DateTime.Now;
                            var apiresponsetime = (endtime - starttime).TotalMilliseconds / 1000;
                            #endregion

                            //取得API回傳result內各屬性的值
                            var dynamicObject = Newtonsoft.Json.JsonConvert.DeserializeObject<dynamic>(_data.result)!;
                            var _bodystatuscode = dynamicObject.statusCode.Value;
                            var _bodyuserId = dynamicObject.userId.Value;
                            var _bodybalancescurrencycode = dynamicObject.balances[0].currencyCode.Value;
                            var _bodybalancesamount = dynamicObject.balances[0].amount.Value;
                            var _bodycardtype = dynamicObject.vip.Value;

                            if (_data.code != 200)
                            {
                                _response.code = _data.code;
                                _response.status = $"Failure - statusCode not 200({_bodystatuscode.ToString()})";

                                //Todo:失敗則記錄普羅米修斯

                                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                                _model_pubsub.type = $"{_response.type} [{_apicode}]CallBackAPI.ExecuteAsync";
                                _model_pubsub.url = _uri;
                                _model_pubsub.responsedata = _response;
                                await _pubsubService.PublishMessagesAsync(_model_pubsub);
                            }
                            if (_response.code != 0) return _response;

                            if (_bodystatuscode == "RS_ERROR_SYSTEM_IN_MAINTAIN")
                            {
                                _response.code = 9998;
                            }
                            else if (_bodystatuscode == "RS_ERROR_INVALID_USER_TOKEN" || _bodystatuscode == "RS_ERROR_INVALID_ACCOUNT_TOKEN")
                            {
                                _response.code = 9997;
                            }
                            if (_response.code != 0) return _response;

                            //Todo:成功則記錄普羅米修斯

                            //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                            dynamic _dynamicrequest = new { idoperator = _idoperator, idvendor = _idvendor, username = _bodyuserId };
                            await _pubsubService.PublishMessagesAsync(_dynamicrequest);

                            _response.code = 0;
                            _response.status = "Successful";
                            _response.result = JsonSerializer.Deserialize<dynamic>(_data.result);
                            _response.additional = new { userId = _bodyuserId, currency = _bodybalancescurrencycode, balance = _bodybalancesamount, cardType = _bodycardtype };

                            //記錄LOG:API 呼叫記錄寫入 Pub/Sub(End)
                            #region 記錄LOG:API 呼叫記錄寫入 Pub/Sub(End)
                            _model_pubsub.type = _response.type + " End";
                            _model_pubsub.url = _uri;
                            _model_pubsub.responsedata = _response;
                            int _messagecount = await _pubsubService.PublishMessagesAsync(_model_pubsub);
                            #endregion
                        }
                        else if (_apicode == "vm")
                        {
                            _uri = _uri.Replace("{user_token}", _model.data.usertoken);
                            _uri = _uri.Replace("{session_token}", _model.data.sessiontoken);

                            var _request = new { };

                            #region 使用HttpClient呼叫API
                            var starttime = DateTime.Now;
                            var _data = await _callback.ExecuteAsync(_request, HttpMethod.Get, _uri, null, null);
                            //var _data = _callback.Execute(_request, HttpMethod.Post, _uri, null, null);
                            var endtime = DateTime.Now;
                            var apiresponsetime = (endtime - starttime).TotalMilliseconds / 1000;
                            #endregion

                            if (_data.code != 200)
                            {
                                _response.code = _data.code;
                                _response.status = $"Failure - statusCode not 200({_data.code.ToString()})";

                                //Todo:失敗則記錄普羅米修斯

                                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                                _model_pubsub.type = $"{_response.type} [{_apicode}]CallBackAPI.ExecuteAsync";
                                _model_pubsub.url = _uri;
                                _model_pubsub.responsedata = _response;
                                await _pubsubService.PublishMessagesAsync(_model_pubsub);
                            }
                            if (_response.code != 0) return _response;

                            //Todo:成功記錄普羅米修斯

                            _response.code = 0;
                            _response.status = "Successful";
                            _response.result = JsonSerializer.Deserialize<dynamic>(_data.result);

                            //記錄LOG:API 呼叫記錄寫入 Pub/Sub(End)
                            #region 記錄LOG:API 呼叫記錄寫入 Pub/Sub(End)
                            _model_pubsub.type = $"{_response.type} End";
                            _model_pubsub.url = _uri;
                            _model_pubsub.responsedata = _response;
                            int _messagecount = await _pubsubService.PublishMessagesAsync(_model_pubsub);
                            #endregion
                        }
                        else
                        {
                            _response.code = 0;
                            _response.status = "Successful - external";
                        }

                        break;
                    case 1:
                        _response.code = 0;
                        _response.status = "Successful - test mode";
                        break;
                }
            }
            catch (Exception ex)
            {
                _response.code = 9999;
                _response.status = ex.Message;

                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                _model_pubsub.type = $"{_response.type} Catch Exception";
                _model_pubsub.responsedata = _response;
                await _pubsubService.PublishMessagesAsync(_model_pubsub);
            }

            return _response;
        }

        [HttpPost, Route("Login")]
        public Model.DefaultResponse Login()
        {
            Model.DefaultResponse _response = new Model.DefaultResponse();


            return _response;
        }

        /// <summary>
        /// 押注 - 相關參數各自支援之平台商端, 可參考 API 文件說明
        /// </summary>
        /// <param name="_model"></param>
        /// <returns></returns>
        [HttpPost, Route("DeductionPoint")]
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public async Task<Model.DefaultResponse> Bet(Model.Vendor.BetRequest _model)
        {
            Model.DefaultResponse _response = new();
            Model.PubSubRequest _model_pubsub = new();
            _response.type = "Deduction Point";
            //設定記錄Pub/Sub相關參數
            _model_pubsub.merchantid = _model.data.merchantid;
            _model_pubsub.vcode = _model.data.vcode;
            _model_pubsub.gameid = _model.data.gameid;
            _model_pubsub.usertoken = _model.data.usertoken;
            _model_pubsub.sessiontoken = _model.data.sessiontoken;
            _model_pubsub.roundid = _model.data.roundid;
            _model_pubsub.currency = _model.data.currency;
            _model_pubsub.betamount = _model.data.betamount;
            _model_pubsub.winamount = _model.data.winamount;
            _model_pubsub.end = _model.data.end.ToString();
            _model_pubsub.transactionid = _model.data.transactionid;
            _model_pubsub.bettime = _model.data.bettime;
            _model_pubsub.transfer = _model.data.transfer.ToString();
            _model_pubsub.external = _model.data.external;
            _model_pubsub.balance = _model.data.balance;
            _model_pubsub.offlinetagamount = _model.data.offlinetagamount;
            _model_pubsub.detail = _model.data.detail;

            try
            {
                #region 驗證相關欄位並取得相關Table資料
                //設定驗證欄位
                var _verifyfields = "merchantid,vcode,usertoken";
                //取得相關Table資料(資料已Redis)
                var _vendordataresponse = await _vendorService.GetVendorData<Model.Vendor.BetRequest, Model.Vendor.BetRequestParams>(_model, _model.data, _verifyfields, _response, _model_pubsub);
                _response = _vendordataresponse.DefaultResponse;
                if (_response.code != 0) return _response;
                #endregion

                //取得相關Table資料
                var _vendoroperatoraccountmapping = _vendordataresponse.Redis_VendorOperatorAccountMapping;
                var _operatorimplementinfo = _vendordataresponse.Redis_OperatorImplementInfo;
                var _operatorimplementinfosecretkey = _operatorimplementinfo.SecretKey;
                var _apicode = _vendordataresponse.ApiCode;
                string _uri = _operatorimplementinfo.UrlWithdraw;
                string _newgameid = _vendordataresponse.NewGameID;
                _model_pubsub.url = _uri;

                switch (_vendoroperatoraccountmapping.TestMode)
                {
                    case 0:
                        Services.External.CallBackService _callback = new Services.External.CallBackService(_httpContextAccessor);

                        if (_apicode == "08online")
                        {
                            var _uid = StringHelper.makeTransactionId(16);
                            var _currenttime = DateTime.Now.ToString("yyyy/MM/dd HH:MM:ss");
                            var _bettimenow = (string.IsNullOrEmpty(_model.data.bettime)) ? _currenttime : _model.data.bettime;

                            var _formdata = new
                            {
                                reqid = _uid,
                                token = _model.data.usertoken,
                                currency = _model.data.currency,
                                gameid = _newgameid,
                                transactionid = _model.data.transactionid,
                                roundid = _model.data.roundid,
                                bettime = _bettimenow,
                                betamount = _model.data.betamount,
                                winloseamount = _model.data.winamount,
                                isfreeround = false,
                                jackpot = _model.data.jackpot,
                                bonus = 0,
                                detail = _model.data.detail
                            };
                            var _formhash = Utility.Encryptions.MD5_Generate(JsonSerializer.Serialize(_formdata) + _operatorimplementinfosecretkey);

                            var _request = new { data = _formdata, hash = _formhash };

                            #region 使用HttpClient呼叫API
                            var starttime = DateTime.Now;
                            var _data = await _callback.ExecuteAsync(_request, HttpMethod.Post, _uri, null, null);
                            //var _data = _callback.Execute(_request, HttpMethod.Post, _uri, null, null);
                            var endtime = DateTime.Now;
                            var apiresponsetime = (endtime - starttime).TotalMilliseconds / 1000;
                            #endregion

                            //取得API回傳result內各屬性的值
                            var dynamicObject = Newtonsoft.Json.JsonConvert.DeserializeObject<dynamic>(_data.result)!;
                            var _bodycode = dynamicObject.code.Value;
                            var _bodymessage = dynamicObject.message.Value;
                            var _bodyresult = Newtonsoft.Json.JsonConvert.SerializeObject(dynamicObject.result);

                            if (_data.code != 200)
                            {
                                _response.code = _data.code;
                                _response.status = $"Failure - statusCode not 200({_bodycode.ToString()})";

                                //Todo:失敗則記錄普羅米修斯

                                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                                _model_pubsub.type = $"{_response.type} [{_apicode}]CallBackAPI.ExecuteAsync";
                                _model_pubsub.url = _uri;
                                _model_pubsub.responsedata = _response;
                                await _pubsubService.PublishMessagesAsync(_model_pubsub);
                            }
                            if (_response.code != 0) return _response;

                            //Todo:成功記錄普羅米修斯

                            _response.code = 0;
                            _response.status = "Successful";
                            if (_bodycode != 0)
                            {
                                _response.code = (int)_bodycode;
                                _response.status = _bodymessage;
                            }
                            _response.result = JsonSerializer.Deserialize<dynamic>(_bodyresult);

                            //記錄LOG:API 呼叫記錄寫入 Pub/Sub(End)
                            #region 記錄LOG:API 呼叫記錄寫入 Pub/Sub(End)
                            _model_pubsub.type = $"{_response.type} End";
                            _model_pubsub.url = _uri;
                            _model_pubsub.responsedata = _response;
                            int _messagecount = await _pubsubService.PublishMessagesAsync(_model_pubsub);
                            #endregion
                        }
                        else if (_apicode == "aceonline")
                        {
                            string[] headers = { "x-api-key" };
                            string[] values = { "e495964cb27748859d1060f53a2d3ba2" };

                            var _tags_actions_list = new dynamic[] {
                                new { action = "Lose", moneyAmount = _model.data.betamount },
                                new { action = "Gain", moneyAmount = _model.data.winamount }
                                };
                            var _tags_actions = new { actions = _tags_actions_list };
                            var _tags = new { operationType = "WagerTagOperation", tagType = "Money", tags = _tags_actions };

                            var _gametags = new { operationType = "WagerTagOperation", tagType = "Money", tag = new { offlineSpin = _model.data.offlinetagamount, detail = _model.data.detail } };

                            dynamic _operations1 = new { operationType = "WagerLifecycleOperation", action = "create" };
                            dynamic _operations2 = new { operationType = "WagerWithdrawOperation", withdraw = _model.data.betamount, transfer = _model.data.transfer, id = _model.data.roundid };
                            dynamic _operations = new { _operations1, _operations2 };

                            if (_model.data.end && int.Parse(_model.data.winamount) > 0)
                            {
                                _operations1 = new { operationType = "WagerLifecycleOperation", deposit = string.IsNullOrEmpty(_model.data.balance) ? _model.data.winamount : _model.data.balance, transfer = _model.data.transfer };
                                _operations2 = new { operationType = "WagerLifecycleOperation", action = "confirm" };
                                _operations = new { _operations1, tags = _tags, gametags = _gametags, _operations2 };
                            }

                            var _request = new
                            {
                                userId = _model.data.userid,
                                transactionId = $"BET-{_model.data.transactionid}",
                                accountToken = _model.data.usertoken,
                                gameSessionId = _model.data.sessiontoken,
                                gameId = _newgameid,
                                wagerId = _model.data.transactionid,
                                operations = _operations
                            };

                            #region 使用HttpClient呼叫API
                            var starttime = DateTime.Now;
                            var _data = await _callback.ExecuteAsync(_request, HttpMethod.Post, _uri, headers, values);
                            //var _data = _callback.Execute(_request, HttpMethod.Post, _uri, headers, values);
                            var endtime = DateTime.Now;
                            var apiresponsetime = (endtime - starttime).TotalMilliseconds / 1000;
                            #endregion

                            //取得API回傳result內各屬性的值
                            var dynamicObject = Newtonsoft.Json.JsonConvert.DeserializeObject<dynamic>(_data.result)!;
                            var _bodystatuscode = dynamicObject.statusCode.Value;
                            var _bodybalancescurrencycode = dynamicObject.balances[0].currencyCode.Value;
                            var _bodybalancesamount = dynamicObject.balances[0].amount.Value;

                            if (_data.code != 200)
                            {
                                _response.code = _data.code;
                                _response.status = $"Failure - statusCode not 200({_bodystatuscode.ToString()})";

                                //Todo:失敗則記錄普羅米修斯

                                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                                _model_pubsub.type = $"{_response.type} [{_apicode}]CallBackAPI.ExecuteAsync";
                                _model_pubsub.url = _uri;
                                _model_pubsub.responsedata = _response;
                                await _pubsubService.PublishMessagesAsync(_model_pubsub);
                            }
                            if (_response.code != 0) return _response;

                            if (_bodystatuscode == "RS_ERROR_SYSTEM_IN_MAINTAIN")
                            {
                                _response.code = 9998;
                            }
                            else if (_bodystatuscode == "RS_ERROR_INVALID_USER_TOKEN" || _bodystatuscode == "RS_ERROR_INVALID_ACCOUNT_TOKEN")
                            {
                                _response.code = 9997;
                            }
                            if (_response.code != 0) return _response;

                            //Todo:成功記錄普羅米修斯

                            _response.code = 0;
                            _response.status = "Successful";
                            _response.result = JsonSerializer.Deserialize<dynamic>(_data.result);
                            _response.additional = new { currency = _bodybalancescurrencycode, balance = _bodybalancesamount };

                            //記錄LOG:API 呼叫記錄寫入 Pub/Sub(End)
                            #region 記錄LOG:API 呼叫記錄寫入 Pub/Sub(End)
                            _model_pubsub.type = $"{_response.type} End";
                            _model_pubsub.url = _uri;
                            _model_pubsub.responsedata = _response;
                            int _messagecount = await _pubsubService.PublishMessagesAsync(_model_pubsub);
                            #endregion
                        }
                        else if (_apicode == "vm")
                        {
                            _uri = _uri.Replace("{user_token}", _model.data.usertoken);
                            _uri = _uri.Replace("{session_token}", _model.data.sessiontoken);

                            var _request = new
                            {
                                roundID = _model.data.roundid,
                                Currency = _model.data.currency,
                                BetAmount = _model.data.betamount,
                                WinAmount = _model.data.winamount,
                                End = _model.data.end,
                                Jackpot = _model.data.jackpot,
                                External = _model.data.external
                            };

                            #region 使用HttpClient呼叫API
                            var starttime = DateTime.Now;
                            var _data = await _callback.ExecuteAsync(_request, HttpMethod.Post, _uri, null, null);
                            //var _data = _callback.Execute(_request, HttpMethod.Post, _uri, null, null);
                            var endtime = DateTime.Now;
                            var apiresponsetime = (endtime - starttime).TotalMilliseconds / 1000;
                            #endregion

                            if (_data.code != 200)
                            {
                                _response.code = _data.code;
                                _response.status = $"Failure - statusCode not 200({_data.code.ToString()})";

                                //Todo:失敗則記錄普羅米修斯

                                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                                _model_pubsub.type = $"{_response.type} [{_apicode}]CallBackAPI.ExecuteAsync";
                                _model_pubsub.url = _uri;
                                _model_pubsub.responsedata = _response;
                                await _pubsubService.PublishMessagesAsync(_model_pubsub);
                            }
                            if (_response.code != 0) return _response;

                            //Todo:成功記錄普羅米修斯

                            _response.code = 0;
                            _response.status = "Successful";
                            _response.result = JsonSerializer.Deserialize<dynamic>(_data.result);

                            //記錄LOG:API 呼叫記錄寫入 Pub/Sub(End)
                            #region 記錄LOG:API 呼叫記錄寫入 Pub/Sub(End)
                            _model_pubsub.type = $"{_response.type} End";
                            _model_pubsub.url = _uri;
                            _model_pubsub.responsedata = _response;
                            int _messagecount = await _pubsubService.PublishMessagesAsync(_model_pubsub);
                            #endregion
                        }
                        else
                        {
                            _response.code = 0;
                            _response.status = "Successful - external";
                        }

                        break;
                    case 1:
                        _response.code = 0;
                        _response.status = "Successful - test mode";
                        break;
                }
            }
            catch (Exception ex)
            {
                _response.code = 9999;
                _response.status = ex.Message;

                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                _model_pubsub.type = $"{_response.type} Catch Exception";
                _model_pubsub.responsedata = _response;
                await _pubsubService.PublishMessagesAsync(_model_pubsub);
            }

            return _response;
        }

        [HttpPost, Route("Settle")]
        public Model.DefaultResponse Settle()
        {
            Model.DefaultResponse _response = new Model.DefaultResponse();


            return _response;
        }

        [HttpPost, Route("Cancel")]
        public Model.DefaultResponse Cancel()
        {
            Model.DefaultResponse _response = new Model.DefaultResponse();


            return _response;
        }

        [HttpPost, Route("Event")]
        public Model.DefaultResponse Event()
        {
            Model.DefaultResponse _response = new Model.DefaultResponse();


            return _response;
        }

        #endregion

        #region Health Check

        [HttpPost, Route("dbhealthz")]
        public Model.DefaultResponse DBHealthz()
        {
            Model.DefaultResponse _response = new Model.DefaultResponse();


            return _response;
        }

        [HttpPost, Route("healthz")]
        public Model.DefaultResponse Healthz()
        {
            Model.DefaultResponse _response = new Model.DefaultResponse();


            return _response;
        }

        #endregion

    }
}
