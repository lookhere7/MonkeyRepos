﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Data;

namespace Seamless.Core.API.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class SeamlessController : ControllerBase
    {
        /// <summary>
        /// 
        /// </summary>
        private readonly IHttpContextAccessor _httpContextAccessor;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="httpContextAccessor"></param>
        public SeamlessController(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
        }

        [HttpPost, Route("Startup")]
        public Model.DefaultResponse Startup()
        {
            Model.DefaultResponse _response = new Model.DefaultResponse();


            return _response;
        }

        [HttpGet, Route("Login")]
        public Model.DefaultResponse Login()
        {
            Model.DefaultResponse _response = new Model.DefaultResponse();


            return _response;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="vendorid"></param>
        /// <param name="vcode"></param>
        /// <returns></returns>
        //[HttpPost, Route("Test")]
        //public Model.VendorSeamlessImplementResponse Test(string vendorid, string vcode)
        //{
        //    var res = Data.MySQL.Get_VendorSeamless_Implement(vendorid, vcode);
        //    return res;
        //}
    }
}
