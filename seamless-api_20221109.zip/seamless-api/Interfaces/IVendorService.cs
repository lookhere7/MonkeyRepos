﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace Seamless.Core.API.Interfaces
{
    public interface IVendorService
    {
        /// <summary>
        /// EF Add(Sample)
        /// </summary>
        /// <param name="_model"></param>
        /// <returns></returns>
        public Task<int> Add(Models.Vendor _model);

        /// <summary>
        /// EF Call SP(Sample)
        /// </summary>
        /// <param name="_spname"></param>
        /// <param name="_paras"></param>
        /// <returns></returns>
        public Task<List<Model.SP_VendorImplementInfoResponse>> GetImplementInfo_CallSP(string _spname, string[] _paras);

        public Task<Models.Vendor> GetVendor(int _id);

        public Task<Models.VendorImplementInfo> GetVendorImplementInfo(int _vendorid);

        public Task<Models.VendorImplementInfo> GetVendorImplementInfo(string _vendorid);

        public Task<List<Models.VendorOperatorAccountMapping>> GetVendorOperatorAccountMapping(int _vendorid, int _operatorid, int _gameid);

        public Task<Models.VendorOperatorAccountMapping> GetVendorOperatorAccountMapping(int _vendorid, int _operatorid, int _gameid, int _route);

        public Task<List<Models.VendorOperatorAccountMapping>> GetVendorOperatorAccountMapping(int _vendorid, int _operatorid, string _implementid);

        public Task<Models.VendorOperatorAccountMapping> GetVendorOperatorAccountMapping(int _vendorid, int _operatorid, string _implementid, int _route);

        public Task<Models.VendorOperatorAccountMapping> GetVendorOperatorAccountMapping(int _vendorid, string _implementvcode, int _route);

        public Task<Model.Vendor.VendorDataResponse> GetVendorData<T1, T2>(T1 _model, T2 _model_data, string _verifyfields, Model.DefaultResponse _response, Model.PubSubRequest _pubsubrequest);
    }
}
