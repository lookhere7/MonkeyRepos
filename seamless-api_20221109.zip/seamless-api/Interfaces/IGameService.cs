﻿using System.Collections.Generic;

namespace Seamless.Core.API.Interfaces
{
    public interface IGameService
    {
        public Models.Game Get(int _id);

        public Models.Game Get(string _code);

        public List<Models.Game> GetByVendor(int _vendorid);
    }
}
