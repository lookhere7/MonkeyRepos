﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Seamless.Core.API.Model
{
    public class PubSubRequest
    {
        public string type { get; set; } = "";
        public string url { get; set; } = "";
        public string merchantid { get; set; } = "";
        public string vcode { get; set; } = "";
        public string usertoken { get; set; } = "";
        public string sessiontoken { get; set; } = "";
        public string userid { get; set; } = "";
        public string wallet { get; set; } = "";
        public string amount { get; set; } = "";
        public string gameid { get; set; } = "";
        public string roundid { get; set; } = "";
        public string currency { get; set; } = "";
        public string betamount { get; set; } = "";
        public string winamount { get; set; } = "";
        public string end { get; set; } = "";
        public string transactionid { get; set; } = "";
        public string bettime { get; set; } = "";
        public string transfer { get; set; } = "";
        public string external { get; set; } = "";
        public string balance { get; set; } = "";
        public string offlinetagamount { get; set; } = "";
        public string detail { get; set; } = "";
        public Model.DefaultResponse responsedata { get; set; }
        public string createdate { get; set; } = DateTime.Now.ToShortDateString();
    }
}
