﻿using System;
using System.Collections.Generic;

namespace Seamless.Core.API.Models
{
    public partial class VendorImplementField
    {
        public int Id { get; set; }
        public int? IdVendorImplementInfo { get; set; }
        /// <summary>
        /// 1: Register\\n2: Login\\n3: TransferPoint\\n4: Play game\n5:BetLog
        /// </summary>
        public int? Type { get; set; }
        public string FieldName { get; set; }
        public sbyte? IsHash { get; set; }
        public int? HashSort { get; set; }
    }
}
