﻿using System;
using System.Collections.Generic;

namespace Seamless.Core.API.Models
{
    public partial class VendorImplementInfo
    {
        /// <summary>
        /// 系統編號
        /// </summary>
        public int Id { get; set; }
        /// <summary>
        /// 遊戲商系統編號
        /// </summary>
        public int? IdVendor { get; set; }
        /// <summary>
        /// 1. 遊戲商-商戶號代碼  \n2. 遊戲商呼叫中間層 API 時使用之 MerchantID
        /// </summary>
        public string VendorId { get; set; }
        /// <summary>
        /// 1. 密碼
        /// 2. 遊戲商呼叫中間層 API 時使用之 Password
        /// 
        /// </summary>
        public string Password { get; set; }
        /// <summary>
        /// 1. 串接代碼
        /// 2. 遊戲商呼叫中間層 API 時使用
        /// 
        /// </summary>
        public string ImplementCode { get; set; }
        /// <summary>
        /// 1. 串接Key
        /// 2. 遊戲商呼叫中間層 API 時使用
        /// 
        /// </summary>
        public string ImplementKey { get; set; }
        /// <summary>
        /// 1. 串接IV
        /// 2. 遊戲商呼叫中間層 API 時使用
        /// 
        /// </summary>
        public string ImplementIv { get; set; }
        /// <summary>
        /// 1. 遊戲商投注紀錄 API URL
        /// 2. 遊戲商呼叫中間層 API 時使用
        /// 
        /// </summary>
        public string UrlBetLog { get; set; }
        /// <summary>
        /// 1. 取得玩家是否在線 API URL
        /// 2. 遊戲商呼叫中間層 API 時使用
        /// 
        /// </summary>
        public string UrlOnline { get; set; }
        /// <summary>
        /// 1. 登出玩家 API URL
        /// 2. 遊戲商呼叫中間層 API 時使用
        /// 
        /// </summary>
        public string UrlLogout { get; set; }
        /// <summary>
        /// 1. 進入遊戲 URL
        /// 2. 遊戲商呼叫中間層 API 時使用
        /// 
        /// </summary>
        public string UrlPlay { get; set; }
        public string UrlKick { get; set; }
        /// <summary>
        /// 1. 排程撈取遊戲商投注紀錄區間
        /// 2. 每隔x分鐘
        /// </summary>
        public int? BetRecordInterval { get; set; }
        /// <summary>
        /// 1. 排程將投注紀錄轉換每小時輸贏紀錄
        /// 2. 每隔x分鐘
        /// </summary>
        public int? SummaryRecordInterval { get; set; }
        /// <summary>
        /// 啟用狀態
        /// </summary>
        public sbyte? Status { get; set; }
    }
}
