﻿using System;
using System.Collections.Generic;

namespace Seamless.Core.API.Models
{
    public partial class Maintenance
    {
        public int Id { get; set; }
        public int? IdVendor { get; set; }
        public string Path { get; set; }
        public DateTime? StartTime { get; set; }
        public DateTime? EndTime { get; set; }
        public sbyte? Active { get; set; }
        public DateTime? CreateDate { get; set; }
    }
}
