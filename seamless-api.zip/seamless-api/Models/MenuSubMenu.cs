﻿using System;
using System.Collections.Generic;

namespace Seamless.Core.API.Models
{
    public partial class MenuSubMenu
    {
        /// <summary>
        /// 系統編號
        /// </summary>
        public int Id { get; set; }
        /// <summary>
        /// 母選單系統編號
        /// </summary>
        public int? IdMenu { get; set; }
        /// <summary>
        /// 子選單名稱
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// 子選單超連結
        /// </summary>
        public string HyperLink { get; set; }
    }
}
