﻿using System;
using System.Collections.Generic;

namespace Seamless.Core.API.Models
{
    public partial class LocaleStringResource
    {
        /// <summary>
        /// 系統編號
        /// </summary>
        public int Id { get; set; }
        /// <summary>
        /// 語系系統編號
        /// </summary>
        public int? IdLanguage { get; set; }
        public string SourceDb { get; set; }
        /// <summary>
        /// 對照來源 Table Name
        /// </summary>
        public string SourceTable { get; set; }
        /// <summary>
        /// 來源 Table 中系統編號
        /// </summary>
        public int? EntityId { get; set; }
        /// <summary>
        /// 來源 Table 中欄位名稱
        /// </summary>
        public string ResourceName { get; set; }
        /// <summary>
        /// 來源 Table 中欄位對應值
        /// </summary>
        public string ResourceValue { get; set; }
    }
}
