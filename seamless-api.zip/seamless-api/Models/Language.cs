﻿using System;
using System.Collections.Generic;

namespace Seamless.Core.API.Models
{
    public partial class Language
    {
        /// <summary>
        /// 語系系統編號
        /// </summary>
        public int Id { get; set; }
        /// <summary>
        /// 語系代碼
        /// </summary>
        public string Code { get; set; }
        /// <summary>
        /// 語系名稱
        /// </summary>
        public string LanguageName { get; set; }
        /// <summary>
        /// 啟用狀態
        /// </summary>
        public sbyte? Active { get; set; }
    }
}
