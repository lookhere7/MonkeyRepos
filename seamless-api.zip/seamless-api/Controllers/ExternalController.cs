﻿using HtmlAgilityPack;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
//using Newtonsoft.Json;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Net.Http;
using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Routing;
using Seamless.Core.API.Interfaces;
using Seamless.Core.API.Utility;
using System.Dynamic;
using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Prometheus;
using System.Reflection;

/// <summary>
/// 
/// </summary>
namespace Seamless.Core.API.Controllers
{
    /// <summary>
    /// 
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class ExternalController : ControllerBase
    {
        /// <summary>
        /// 
        /// </summary>
        private readonly Models.ManufacturerCMSContext _context = new Models.ManufacturerCMSContext();
        #region Interfaces

        /// <summary>
        /// 
        /// </summary>
        private readonly IHttpContextAccessor _httpContextAccessor;

        /// <summary>
        /// 
        /// </summary>
        private readonly IGameService _gameService;

        /// <summary>
        /// 
        /// </summary>
        private readonly IOperatorService _operatorService;

        /// <summary>
        /// 
        /// </summary>
        private readonly IVendorService _vendorService;

        /// <summary>
        /// 
        /// </summary>
        private readonly ILogger<ExternalController> _logger;

        /// <summary>
        /// 
        /// </summary>
        private readonly IHttpClientFactory _httpClientFactory;

        /// <summary>
        /// 
        /// </summary>
        private readonly IConfiguration _configuration;

        /// <summary>
        /// 
        /// </summary>
        private readonly ICacheService _cacheService;

        private readonly IPubSubService _pubsubService;

        private static readonly Histogram HttpPartnerHistogram = Metrics
        .CreateHistogram("http_request_duration_seconds_partner", "request duration in seconds",
            new HistogramConfiguration
            {
                Buckets = Histogram.ExponentialBuckets(0.001, 2, 16),
                LabelNames = new[] { "method", "controller", "action", "partner_code", "partner_host", "partner_uri", "partner_method" }
            });

        #endregion

        private readonly Seamless.Core.API.Data.MySQL _mysql = new();

        /// <summary>
        /// 
        /// </summary>
        /// <param name="httpContextAccessor"></param>
        public ExternalController(IHttpContextAccessor httpContextAccessor, IOperatorService operatorService, IVendorService vendorService, IGameService gameService, ILogger<ExternalController> logger, IHttpClientFactory httpClientFactory, IConfiguration configuration, ICacheService cacheService, Seamless.Core.API.Data.MySQL mysql, IPubSubService pubsubService)
        {
            this._httpContextAccessor = httpContextAccessor;
            this._gameService = gameService;
            this._operatorService = operatorService;
            this._vendorService = vendorService;
            this._logger = logger;
            this._httpClientFactory = httpClientFactory;
            this._configuration = configuration;
            this._cacheService = cacheService;
            this._mysql = mysql;
            this._pubsubService = pubsubService;
        }

        private string[] GetAllLabelValues(HttpRequestMessage request, HttpResponseMessage response)
        {
            var RouteData = HttpContext.GetRouteData()?.Values;
            var Controller = RouteData?.GetValueOrDefault("controller", string.Empty) as string ?? string.Empty;
            var Action = RouteData?.GetValueOrDefault("action", string.Empty) as string ?? string.Empty;
            var Method = HttpContext.Request.Method.ToString();

            var PartnerCode = ((int)response.StatusCode).ToString();
            var PartnerHost = request.RequestUri?.Host ?? string.Empty;
            var PartnerPath = request.RequestUri?.AbsolutePath ?? string.Empty; ;
            var PartnerMethod = request.Method.ToString();

            return new[] { Method, Controller, Action, PartnerCode, PartnerHost, PartnerPath, PartnerMethod };
        }

        private double GetElapsedTimeFromHeader(HttpResponseMessage response, string key = "X-Partner-ElapsedTime")
        {
            //var elapsedTime = response.Headers.GetValues(key).FirstOrDefault();
            var elapsedTime = DateTime.UtcNow.ToString("yyyy-MM-dd HH:mm:ss.fff");
            if (string.IsNullOrEmpty(elapsedTime))
                elapsedTime = "0";
            else
            {
                DateTime current = DateTime.UtcNow;
                DateTime before = DateTime.Parse(elapsedTime);
                elapsedTime = (current - before).TotalSeconds.ToString();
            }

            return Convert.ToDouble(elapsedTime);
        }

        #region Table

        [HttpPost, Route("Deduction")]
        public Model.DefaultResponse Deduction()
        {
            Model.DefaultResponse _response = new Model.DefaultResponse();


            return _response;
        }

        [HttpPost, Route("DeductionRefund")]
        public Model.DefaultResponse DeductionRefund()
        {
            Model.DefaultResponse _response = new Model.DefaultResponse();


            return _response;
        }


        [HttpPost, Route("DeductionSettle")]
        public Model.DefaultResponse DeductionSettle()
        {
            Model.DefaultResponse _response = new Model.DefaultResponse();


            return _response;
        }

        #endregion

        #region Seamless        

        /// <summary>
        /// 
        /// </summary>
        /// <param name="_model"></param>
        [HttpPost, Route("CreateToken")]
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public async Task<Model.DefaultResponse> CreateToken(Model.Vendor.CreateTokenRequest _model)
        {
            Model.DefaultResponse _response = new Model.DefaultResponse();
            _response.type = "Create Token";

            try
            {
                #region 驗證相關欄位並取得相關Table資料
                //設定驗證欄位
                var _verifyfields = "merchantid,vcode,gameid";
                //取得相關Table資料(資料已Redis)
                var _vendordataresponse = await _vendorService.GetVendorData<Model.Vendor.CreateTokenRequest, Model.Vendor.CreateTokenRequestParams>(_model, _model.data, _verifyfields, _response);
                _response = _vendordataresponse.DefaultResponse;
                if (_response.code != 0) return _response;
                #endregion

                //取得相關Table資料
                var _vendoroperatoraccountmapping = _vendordataresponse.Redis_VendorOperatorAccountMapping;
                var _operatorimplementinfo = _vendordataresponse.Redis_OperatorImplementInfo;
                var _apicode = _vendordataresponse.ApiCode;
                string _uri = _operatorimplementinfo.UrlCreateToken;
                string _newgameid = _vendordataresponse.NewGameID;

                switch (_vendoroperatoraccountmapping.TestMode)
                {
                    case 0:
                        Entity.CallApiRequest.CreateTokenRequest _request = new();
                        _request.gameId = _newgameid;

                        Services.External.CallBackService _callback = new Services.External.CallBackService(_httpContextAccessor);

                        if (_apicode == "08online")
                        {
                            _uri = string.Format("{0}?gameid={1}", _uri, _newgameid);

                            #region 使用HttpClient呼叫API
                            var starttime = DateTime.Now.Millisecond;
                            //var _data = await _callback.ExecuteAsync(_request, HttpMethod.Get, _uri, null, null);
                            var _data = _callback.Execute(_request, HttpMethod.Get, _uri, null, null);
                            var endtime = DateTime.Now.Millisecond;
                            var apiresponsetime = (endtime - starttime) / 1000;
                            #endregion

                            //Todo:失敗則記錄普羅米修斯及PubSub Log

                            //Todo:成功則記錄普羅米修斯及PubSub Log

                            _response.code = 0;
                            _response.status = "Successful";
                            _response.result = JsonSerializer.Deserialize<dynamic>(_data);

                            //Todo:記錄LOG:API 呼叫紀錄寫入 Pub/Sub(End)
                            #region 記錄LOG:API 呼叫紀錄寫入 Pub/Sub(End)
                            //Model.PubSubRequest _model_pubsub = new();
                            //_model_pubsub.responsedata=_response;
                            //string _messageid = await _pubsubService.SeamlessRequestLog<Model.PubSubRequest>(_model_pubsub);
                            #endregion
                        }
                        else if (_apicode == "aceonline")
                        {
                            string[] headers = { "x-api-key" };
                            string[] values = { "e495964cb27748859d1060f53a2d3ba2" };

                            #region 使用HttpClient呼叫API
                            var starttime = DateTime.Now.Millisecond;
                            //var _data = await _callback.ExecuteAsync(_request, HttpMethod.Post, _uri, headers, values);
                            var _data = _callback.Execute(_request, HttpMethod.Post, _uri, headers, values);
                            var endtime = DateTime.Now.Millisecond;
                            var apiresponsetime = (endtime - starttime) / 1000;
                            #endregion

                            //Todo:失敗則記錄普羅米修斯及PubSub Log

                            //Todo:成功則記錄普羅米修斯及PubSub Log

                            _response.code = 0;
                            _response.status = "Successful";
                            _response.result = JsonSerializer.Deserialize<dynamic>(_data);

                            //Todo:記錄LOG:API 呼叫紀錄寫入 Pub/Sub(End)
                            #region 記錄LOG:API 呼叫紀錄寫入 Pub/Sub(End)
                            //Model.PubSubRequest _model_pubsub = new();
                            //_model_pubsub.responsedata=_response;
                            //string _messageid = await _pubsubService.SeamlessRequestLog<Model.PubSubRequest>(_model_pubsub);
                            #endregion
                        }
                        else
                        {
                            _response.code = 0;
                            _response.status = "Successful - external";
                        }

                        break;
                    case 1:
                        _response.code = 0;
                        _response.status = "Successful - test mode";
                        break;
                }
            }
            catch (Exception ex)
            {
                _response.code = 9999;
                _response.status = ex.Message;
            }

            return _response;
        }

        [HttpPost, Route("Auth")]
        public Model.DefaultResponse Auth()
        {
            Model.DefaultResponse _response = new Model.DefaultResponse();


            return _response;
        }

        [HttpPost, Route("Login")]
        public Model.DefaultResponse Login()
        {
            Model.DefaultResponse _response = new Model.DefaultResponse();


            return _response;
        }

        [HttpPost, Route("DeductionPoint")]
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public async Task<Model.DefaultResponse> Bet(Model.Vendor.BetRequest _model)
        {
            Model.DefaultResponse _response = new Model.DefaultResponse();
            _response.type = "Deduction Point";

            try
            {
                #region 驗證相關欄位並取得相關Table資料
                //設定驗證欄位
                var _verifyfields = "merchantid,vcode,usertoken";
                //取得相關Table資料(資料已Redis)
                var _vendordataresponse = await _vendorService.GetVendorData<Model.Vendor.BetRequest, Model.Vendor.BetRequestParams>(_model, _model.data, _verifyfields, _response);
                _response = _vendordataresponse.DefaultResponse;
                if (_response.code != 0) return _response;
                #endregion

                //取得相關Table資料
                var _vendoroperatoraccountmapping = _vendordataresponse.Redis_VendorOperatorAccountMapping;
                var _operatorimplementinfo = _vendordataresponse.Redis_OperatorImplementInfo;
                var _operatorimplementinfosecretkey = _operatorimplementinfo.SecretKey;
                var _apicode = _vendordataresponse.ApiCode;
                string _uri = _operatorimplementinfo.UrlWithdraw;
                string _newgameid = _vendordataresponse.NewGameID;

                switch (_vendoroperatoraccountmapping.TestMode)
                {
                    case 0:
                        Services.External.CallBackService _callback = new Services.External.CallBackService(_httpContextAccessor);

                        if (_apicode == "08online")
                        {
                            var _uid = StringHelper.makeTransactionId(16);
                            var _currenttime = DateTime.Now.ToString("yyyy/MM/dd HH:MM:ss");
                            var _bettimenow = (string.IsNullOrEmpty(_model.data.bettime)) ? _currenttime : _model.data.bettime;

                            Entity.CallApiRequest.BetRequest_08online_formdata _formdata = new();
                            _formdata.reqid = _uid;
                            _formdata.token = _model.data.usertoken;
                            _formdata.currency = _model.data.currency;
                            _formdata.gameid = _newgameid;
                            _formdata.transactionid = _model.data.transactionid;
                            _formdata.roundid = _model.data.roundid;
                            _formdata.bettime = _bettimenow;
                            _formdata.betamount = _model.data.betamount;
                            _formdata.winloseamount = _model.data.winamount;
                            _formdata.isfreeround = false;
                            _formdata.jackpot = _model.data.jackpot;
                            _formdata.bonus = 0;
                            _formdata.detail = _model.data.detail;

                            var _formhash = Utility.Encryptions.MD5_Generate(JsonSerializer.Serialize(_formdata) + _operatorimplementinfosecretkey);

                            Entity.CallApiRequest.BetRequest_08online _request = new();
                            _request.data = _formdata;
                            _request.hash = _formhash;

                            #region 使用HttpClient呼叫API
                            var starttime = DateTime.Now.Millisecond;
                            //var _data = await _callback.ExecuteAsync(_request, HttpMethod.Get, _uri, null, null);
                            var _data = _callback.Execute(_request, HttpMethod.Post, _uri, null, null);
                            var endtime = DateTime.Now.Millisecond;
                            var apiresponsetime = (endtime - starttime) / 1000;
                            #endregion

                            //Todo:失敗記錄普羅米修斯及PubSub Log

                            //Todo:成功記錄普羅米修斯及PubSub Log

                            _response.code = 0;
                            _response.status = "Successful";
                            _response.result = JsonSerializer.Deserialize<dynamic>(_data);

                            //Todo:記錄LOG:API 呼叫紀錄寫入 Pub/Sub(End)
                            #region 記錄LOG:API 呼叫紀錄寫入 Pub/Sub(End)
                            //Model.PubSubRequest _model_pubsub = new();
                            //_model_pubsub.responsedata=_response;
                            //string _messageid = await _pubsubService.SeamlessRequestLog<Model.PubSubRequest>(_model_pubsub);
                            #endregion
                        }
                        else if (_apicode == "aceonline")
                        {
                            Entity.CallApiRequest.BetRequest_aceonline _request = new();
                            _request.userId = _model.data.userid;
                            _request.transactionId = $"BET-{_model.data.transactionid}";
                            _request.accountToken = _model.data.usertoken;
                            _request.gameSessionId = _model.data.sessiontoken;
                            _request.gameId = _newgameid;
                            _request.wagerId = _model.data.transactionid;

                            string[] headers = { "x-api-key" };
                            string[] values = { "e495964cb27748859d1060f53a2d3ba2" };

                            List<Entity.CallApiRequest.BetRequest_aceonline_tags> _list_tags = new();
                            List<Entity.CallApiRequest.BetRequest_aceonline_tags_tags_actions> _list_tags_tags_actions = new();
                            List<Entity.CallApiRequest.BetRequest_aceonline_tags_tags_actions_list> _list_tags_tags_actions_list = new();
                            _list_tags_tags_actions_list.Add(new Entity.CallApiRequest.BetRequest_aceonline_tags_tags_actions_list { action = "Lose", moneyAmount = _model.data.betamount });
                            _list_tags_tags_actions_list.Add(new Entity.CallApiRequest.BetRequest_aceonline_tags_tags_actions_list { action = "Gain", moneyAmount = _model.data.winamount });
                            _list_tags_tags_actions.Add(new Entity.CallApiRequest.BetRequest_aceonline_tags_tags_actions { actions = _list_tags_tags_actions_list });
                            _list_tags.Add(new Entity.CallApiRequest.BetRequest_aceonline_tags { operationType = "WagerTagOperation", tagType = "Money", tags = _list_tags_tags_actions });
                            var _tags = JsonSerializer.Serialize(_list_tags);

                            List<Entity.CallApiRequest.BetRequest_aceonline_gametags> _list_gametags = new();
                            List<Entity.CallApiRequest.BetRequest_aceonline_gametags_tag> _list_gametags_tag = new();
                            _list_gametags_tag.Add(new Entity.CallApiRequest.BetRequest_aceonline_gametags_tag { offlineSpin = _model.data.offlinetagamount, detail = _model.data.detail });
                            _list_gametags.Add(new Entity.CallApiRequest.BetRequest_aceonline_gametags { operationType = "WagerTagOperation", tagType = "Game", tag = _list_gametags_tag });
                            var _gametags = JsonSerializer.Serialize(_list_gametags);

                            List<Entity.CallApiRequest.BetRequest_aceonline_operations> _list_operations = new();
                            List<Entity.CallApiRequest.BetRequest_aceonline_operations_list1> _list_operations_list1 = new();
                            List<Entity.CallApiRequest.BetRequest_aceonline_operations_list2> _list_operations_list2 = new();
                            _list_operations_list1.Add(new Entity.CallApiRequest.BetRequest_aceonline_operations_list1 { operationType = "WagerLifecycleOperation", action = "create" });
                            _list_operations_list2.Add(new Entity.CallApiRequest.BetRequest_aceonline_operations_list2 { operationType = "WagerWithdrawOperation", withdraw = _model.data.betamount, transfer = _model.data.transfer, id = _model.data.roundid });
                            _list_operations.Add(new Entity.CallApiRequest.BetRequest_aceonline_operations { operations_list1 = _list_operations_list1, operations_list2 = _list_operations_list2 });
                            var _operations = JsonSerializer.Serialize(_list_operations);

                            _request.operations = _operations;

                            #region 使用HttpClient呼叫API
                            var starttime = DateTime.Now.Millisecond;
                            //var _data = await _callback.ExecuteAsync(_request, HttpMethod.Post, _uri, headers, values);
                            var _data = _callback.Execute(_request, HttpMethod.Post, _uri, headers, values);
                            var endtime = DateTime.Now.Millisecond;
                            var apiresponsetime = (endtime - starttime) / 1000;
                            #endregion

                            //Todo:反解_data，取得body內的值(body.balances[0].currencyCode&body.balances[0].amount)
                            //_response.additional = string.Format("{currency:{0} ,balance:{1}}", body.balances[0].currencyCode, body.balances[0].amount);

                            //Todo:失敗記錄普羅米修斯及PubSub Log

                            //Todo:成功記錄普羅米修斯及PubSub Log

                            _response.code = 0;
                            _response.status = "Successful";
                            _response.result = JsonSerializer.Deserialize<dynamic>(_data);

                            //Todo:記錄LOG:API 呼叫紀錄寫入 Pub/Sub(End)
                            #region 記錄LOG:API 呼叫紀錄寫入 Pub/Sub(End)
                            //Model.PubSubRequest _model_pubsub = new();
                            //_model_pubsub.responsedata=_response;
                            //string _messageid = await _pubsubService.SeamlessRequestLog<Model.PubSubRequest>(_model_pubsub);
                            #endregion
                        }
                        else if (_apicode == "vm")
                        {
                            Entity.CallApiRequest.BetRequest_vm _request = new();
                            _request.roundID = _model.data.roundid;
                            _request.Currency = _model.data.currency;
                            _request.BetAmount = _model.data.betamount;
                            _request.WinAmount = _model.data.winamount;
                            _request.End = _model.data.end;
                            _request.Jackpot = _model.data.jackpot;
                            _request.External = _model.data.external;

                            _uri = _uri.Replace("{user_token}", _model.data.usertoken);
                            _uri = _uri.Replace("{session_token}", _model.data.sessiontoken);

                            #region 使用HttpClient呼叫API
                            var starttime = DateTime.Now.Millisecond;
                            //var _data = await _callback.ExecuteAsync(_request, HttpMethod.Post, _uri, headers, values);
                            var _data = _callback.Execute(_request, HttpMethod.Post, _uri, null, null);
                            var endtime = DateTime.Now.Millisecond;
                            var apiresponsetime = (endtime - starttime) / 1000;
                            #endregion

                            //Todo:失敗記錄普羅米修斯及PubSub Log

                            //Todo:成功記錄普羅米修斯及PubSub Log

                            _response.code = 0;
                            _response.status = "Successful";
                            _response.result = JsonSerializer.Deserialize<dynamic>(_data);

                            //Todo:記錄LOG:API 呼叫紀錄寫入 Pub/Sub(End)
                            #region 記錄LOG:API 呼叫紀錄寫入 Pub/Sub(End)
                            //Model.PubSubRequest _model_pubsub = new();
                            //_model_pubsub.responsedata=_response;
                            //string _messageid = await _pubsubService.SeamlessRequestLog<Model.PubSubRequest>(_model_pubsub);
                            #endregion
                        }
                        else
                        {
                            _response.code = 0;
                            _response.status = "Successful - external";
                        }

                        break;
                    case 1:
                        _response.code = 0;
                        _response.status = "Successful - test mode";
                        break;
                }
            }
            catch (Exception ex)
            {
                _response.code = 9999;
                _response.status = ex.Message;
            }

            return _response;
        }

        [HttpPost, Route("Settle")]
        public Model.DefaultResponse Settle()
        {
            Model.DefaultResponse _response = new Model.DefaultResponse();


            return _response;
        }

        [HttpPost, Route("Cancel")]
        public Model.DefaultResponse Cancel()
        {
            Model.DefaultResponse _response = new Model.DefaultResponse();


            return _response;
        }

        [HttpPost, Route("Event")]
        public Model.DefaultResponse Event()
        {
            Model.DefaultResponse _response = new Model.DefaultResponse();


            return _response;
        }

        #endregion

        #region Health Check

        [HttpPost, Route("dbhealthz")]
        public Model.DefaultResponse DBHealthz()
        {
            Model.DefaultResponse _response = new Model.DefaultResponse();


            return _response;
        }

        [HttpPost, Route("healthz")]
        public Model.DefaultResponse Healthz()
        {
            Model.DefaultResponse _response = new Model.DefaultResponse();


            return _response;
        }

        #endregion

    }
}
