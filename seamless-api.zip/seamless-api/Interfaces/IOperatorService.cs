﻿using System.Threading.Tasks;
using System.Collections.Generic;

namespace Seamless.Core.API.Interfaces
{
    public interface IOperatorService
    {
        public Task<Models.Operator> GetOperator(string _username);

        public Task<Models.Operator> GetOperator(int _id);

        public Task<Models.OperatorImplementInfo> GetOperatorImplementInfo(int _operatorid);

        public Task<Models.OperatorImplementInfo> GetOperatorImplementInfo(string _merchantid);
    }
}
