﻿using System.Linq;
using System;
using System.Threading.Tasks;
using System.Collections.Generic;
using Microsoft.Extensions.Caching.Distributed;

namespace Seamless.Core.API.Interfaces
{
    public interface ICacheService
    {
        public Task<T> GetFromCache<T>(string key) where T : class;

        public Task SetCache<T>(string key, T value, DistributedCacheEntryOptions options) where T : class;

        public Task SetCache<T>(string key, T value, int cachetime) where T : class;

        public Task ClearCache(string key);
    }
}
