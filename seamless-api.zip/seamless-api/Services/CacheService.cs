﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Seamless.Core.API.Interfaces;
using Microsoft.Extensions.Caching.Distributed;
using System.Text.Json;

namespace Seamless.Core.API.Services
{
    public class CacheService : ICacheService
    {
        /// <summary>
        /// 定義參數
        /// </summary>
        private readonly IDistributedCache _cache;

        /// <summary>
        /// 建構參數
        /// </summary>
        /// <param name="cache"></param>
        public CacheService(IDistributedCache cache)
        {
            _cache = cache;
        }

        /// <summary>
        /// 取得Redis快取
        /// </summary>
        /// <typeparam name="T"></typeparam>
        public async Task<T> GetFromCache<T>(string key) where T : class
        {
            var cachedResponse = await _cache.GetStringAsync(key);
            return cachedResponse == null ? null : JsonSerializer.Deserialize<T>(cachedResponse);
        }

        /// <summary>
        /// 設定Redis快取(傳入options)
        /// </summary>
        /// <typeparam name="T"></typeparam>
        public async Task SetCache<T>(string key, T value, DistributedCacheEntryOptions options) where T : class
        {
            var response = JsonSerializer.Serialize(value);
            await _cache.SetStringAsync(key, response, options);
        }

        /// <summary>
        /// 設定Redis快取(傳入時間(分鐘))
        /// </summary>
        /// <typeparam name="T"></typeparam>
        public async Task SetCache<T>(string key, T value, int cachetime) where T : class
        {
            //設定Redis快取的options
            //SetAbsoluteExpiration:設定快取項目的絕對到期時間
            //SetSlidingExpiration:設定快取項目在移除前可處於非使用中狀態的時間長度 (例如，未經存取)。 這不會讓項目存留期超過絕對到期的時間 (如已設定)
            //EX:若SetAbsoluteExpiration設3分鐘，SetSlidingExpiration設1分鐘:
            //   快取總時間為3分鐘，但過1分鐘後這個快取就變成非使用狀態，但快取還在，3分鐘過後該快取會消失
            DistributedCacheEntryOptions options = new DistributedCacheEntryOptions()
                .SetAbsoluteExpiration(DateTime.Now.AddMinutes(cachetime))
                .SetSlidingExpiration(TimeSpan.FromMinutes(cachetime));

            var response = JsonSerializer.Serialize(value);
            await _cache.SetStringAsync(key, response, options);
        }

        /// <summary>
        /// 清除Redis快取
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public async Task ClearCache(string key)
        {
            await _cache.RemoveAsync(key);
        }
    }
}