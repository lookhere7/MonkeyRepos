﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Seamless.Core.API.Interfaces;
using Microsoft.Extensions.Caching.Distributed;
using System.Text.Json;
using Google.Cloud.PubSub.V1;
using Microsoft.Extensions.Configuration;
using System.IO;

namespace Seamless.Core.API.Services
{
    public class PubSubService : IPubSubService
    {
        /// <summary>
        /// 定義參數
        /// </summary>
        //private readonly IDistributedCache _cache;

        /// <summary>
        /// 建構參數
        /// </summary>
        /// <param name="cache"></param>
        //public PubSubService(IDistributedCache cache)
        //{
        //    _cache = cache;
        //}

        /// <summary>
        /// 記錄Log(Pub/Sub)
        /// </summary>
        /// <typeparam name="string"></typeparam>
        public async Task<string> SeamlessRequestLog<T>(T _model) where T : class
        {
            string _json = JsonSerializer.Serialize(_model);

            var builder = new ConfigurationBuilder()
                  .SetBasePath(Directory.GetCurrentDirectory())
                  .AddJsonFile("appsettings.json");
            var config = builder.Build();

            var projectid = config["BigQuery:projectid"];
            var topicid = config["PubSub:topic"];
            var subscriptionid = config["PubSub:subscription"];

            #region 記錄LOG:API 呼叫紀錄寫入 Pub/Sub
            // First create a topic.
            PublisherServiceApiClient publisherService = await PublisherServiceApiClient.CreateAsync();
            TopicName topicName = new TopicName(projectid, topicid);
            publisherService.CreateTopic(topicName);

            // Subscribe to the topic.
            SubscriberServiceApiClient subscriberService = await SubscriberServiceApiClient.CreateAsync();
            SubscriptionName subscriptionName = new SubscriptionName(projectid, subscriptionid);
            subscriberService.CreateSubscription(subscriptionName, topicName, pushConfig: null, ackDeadlineSeconds: 60);

            // Publish a message to the topic using PublisherClient.
            PublisherClient publisher = await PublisherClient.CreateAsync(topicName);
            // PublishAsync() has various overloads. Here we're using the string overload.
            string messageId = await publisher.PublishAsync(_json);
            // PublisherClient instance should be shutdown after use.
            // The TimeSpan specifies for how long to attempt to publish locally queued messages.
            await publisher.ShutdownAsync(TimeSpan.FromSeconds(15));

            // Pull messages from the subscription using SubscriberClient.
            SubscriberClient subscriber = await SubscriberClient.CreateAsync(subscriptionName);
            List<PubsubMessage> receivedMessages = new List<PubsubMessage>();
            // Start the subscriber listening for messages.
            await subscriber.StartAsync((msg, cancellationToken) =>
            {
                receivedMessages.Add(msg);
                Console.WriteLine($"Received message {msg.MessageId} published at {msg.PublishTime.ToDateTime()}");
                Console.WriteLine($"Text: '{msg.Data.ToStringUtf8()}'");
                // Stop this subscriber after one message is received.
                // This is non-blocking, and the returned Task may be awaited.
                subscriber.StopAsync(TimeSpan.FromSeconds(15));
                // Return Reply.Ack to indicate this message has been handled.
                return Task.FromResult(SubscriberClient.Reply.Ack);
            });

            // Tidy up by deleting the subscription and the topic.
            //subscriberService.DeleteSubscription(subscriptionName);
            //publisherService.DeleteTopic(topicName);
            #endregion

            return messageId;
        }
    }
}