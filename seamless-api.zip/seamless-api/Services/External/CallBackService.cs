﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
//using Newtonsoft.Json;
using System.Text.Json;
using System.Net.Http;
using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Routing;
using Seamless.Core.API.Interfaces;
using Prometheus;
using System.IO;
using System.Text;
using System.Net;

namespace Seamless.Core.API.Services.External
{
    public class CallBackService
    {
        private readonly IHttpContextAccessor _httpContextAccessor;

        /// <summary>
        /// 
        /// </summary>
        private static readonly Histogram HttpPartnerHistogram = Metrics
       .CreateHistogram("http_request_duration_seconds_partner", "request duration in seconds",
           new HistogramConfiguration
           {
               Buckets = Histogram.ExponentialBuckets(0.001, 2, 16),
               LabelNames = new[] { "method", "controller", "action", "partner_code", "partner_host", "partner_uri", "partner_method" }
           });

        /// <summary>
        /// 
        /// </summary>
        /// <param name="request"></param>
        /// <param name="response"></param>
        /// <returns></returns>
        private string[] GetAllLabelValues(HttpWebRequest request, HttpWebResponse response)
        {
            var RouteData = _httpContextAccessor.HttpContext.GetRouteData()?.Values;
            var Controller = RouteData?.GetValueOrDefault("controller", string.Empty) as string ?? string.Empty;
            var Action = RouteData?.GetValueOrDefault("action", string.Empty) as string ?? string.Empty;
            var Method = _httpContextAccessor.HttpContext.Request.Method.ToString();

            var PartnerCode = ((int)response.StatusCode).ToString();
            var PartnerHost = request.RequestUri?.Host ?? string.Empty;
            var PartnerPath = request.RequestUri?.AbsolutePath ?? string.Empty; ;
            var PartnerMethod = request.Method.ToString();

            return new[] { Method, Controller, Action, PartnerCode, PartnerHost, PartnerPath, PartnerMethod };
        }

        private string[] GetAllLabelValues(HttpRequestMessage request, HttpResponseMessage response)
        {
            var RouteData = _httpContextAccessor.HttpContext.GetRouteData()?.Values;
            var Controller = RouteData?.GetValueOrDefault("controller", string.Empty) as string ?? string.Empty;
            var Action = RouteData?.GetValueOrDefault("action", string.Empty) as string ?? string.Empty;
            var Method = _httpContextAccessor.HttpContext.Request.Method.ToString();

            var PartnerCode = ((int)response.StatusCode).ToString();
            var PartnerHost = request.RequestUri?.Host ?? string.Empty;
            var PartnerPath = request.RequestUri?.AbsolutePath ?? string.Empty; ;
            var PartnerMethod = request.Method.ToString();

            return new[] { Method, Controller, Action, PartnerCode, PartnerHost, PartnerPath, PartnerMethod };
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="response"></param>
        /// <param name="key"></param>
        /// <returns></returns>
        private double GetElapsedTimeFromHeader(HttpWebResponse response, string key = "X-Partner-ElapsedTime")
        {
            var elapsedTime = response.LastModified.ToString("yyyy-MM-dd HH:mm:ss.fff");// .Headers.GetValues(key).FirstOrDefault();
            if (string.IsNullOrEmpty(elapsedTime))
                elapsedTime = "0";
            else
            {
                DateTime current = DateTime.UtcNow;
                DateTime before = DateTime.Parse(elapsedTime);
                elapsedTime = (current - before).TotalSeconds.ToString();
            }

            return Convert.ToDouble(elapsedTime);
        }

        private double GetElapsedTimeFromHeader(HttpResponseMessage response, string key = "X-Partner-ElapsedTime")
        {
            //var elapsedTime = response.Headers.GetValues(key).FirstOrDefault();
            var elapsedTime = DateTime.UtcNow.ToString("yyyy-MM-dd HH:mm:ss.fff");
            if (string.IsNullOrEmpty(elapsedTime))
                elapsedTime = "0";
            else
            {
                DateTime current = DateTime.UtcNow;
                DateTime before = DateTime.Parse(elapsedTime);
                elapsedTime = (current - before).TotalSeconds.ToString();
            }

            return Convert.ToDouble(elapsedTime);
        }

        public CallBackService(IHttpContextAccessor httpContextAccessor)
        {
            this._httpContextAccessor = httpContextAccessor;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="uri"></param>
        /// <param name="headers"></param>
        /// <param name="values"></param>
        /// <param name="body"></param>
        /// <returns></returns>
        public string Execute(string uri, string method, string[] headers, string[] values, string body)
        {
            string _response = String.Empty;
            string api = string.Format("{0}", uri);
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(api);
            request.Method = method;
            //request.Timeout = 000;
            request.ContentType = "application/json";
            request.Headers.Add("X-Partner-ElapsedTime", DateTime.UtcNow.ToString());

            if (headers != null)
            {
                int i = 0;
                foreach (var p in headers)
                {
                    request.Headers.Add(p, values[i].ToString());
                    i++;
                }
            }

            byte[] byteArray = null;
            if (!string.IsNullOrEmpty(body))
            {
                byteArray = Encoding.UTF8.GetBytes(body);
                request.ContentLength = byteArray.Length;
                using (Stream stream = request.GetRequestStream())
                {
                    stream.Write(byteArray, 0, byteArray.Length);
                    stream.Close();
                }
            }

            using (var response = request.GetResponse() as HttpWebResponse)
            {
                var labelValues = GetAllLabelValues(request, response);
                var PartnerElapsedTime = GetElapsedTimeFromHeader(response);
                HttpPartnerHistogram.WithLabels(labelValues).Observe(PartnerElapsedTime);

                var reader = new StreamReader(response.GetResponseStream(), Encoding.UTF8);
                _response = reader.ReadToEnd();
            }

            return _response;
        }

        // public async Task<string> Execute(IHttpClientFactory _httpClientFactory, string _uri, string[] headers, string[] values, string _body)
        // {
        //    string _response = String.Empty;
        //    var request = new HttpRequestMessage(HttpMethod.Post, _uri);
        //    var httpClient = _httpClientFactory.CreateClient("Partner");

        //    HttpRequestMessage message = new HttpRequestMessage();            
        //    message.Content = new StringContent(_body, System.Text.Encoding.UTF8, "application/json");

        //    if (headers != null)
        //    {
        //        int i = 0;
        //        foreach (var p in headers)
        //        {
        //            request.Headers.Add(p, values[i].ToString());
        //            i++;
        //        }
        //    }

        //    var httpResponseMessage = await httpClient.SendAsync(request);
        //    using (var contentStream = await httpResponseMessage.Content.ReadAsStreamAsync())
        //    {
        //        _response = contentStream.ToString();

        //        var labelValues = GetAllLabelValues(request, httpResponseMessage);
        //        var PartnerElapsedTime = GetElapsedTimeFromHeader(httpResponseMessage);
        //        HttpPartnerHistogram.WithLabels(labelValues).Observe(PartnerElapsedTime);
        //    }

        //    return _response;
        // }

        /// <summary>
        /// 非同步呼叫API方法
        /// </summary>
        /// <param name="_request"></param>
        /// <param name="_method"></param>
        /// <param name="_uri"></param>
        /// <param name="headers"></param>
        /// <param name="values"></param>
        /// <returns></returns>
        public async Task<string> ExecuteAsync<T>(T _request, HttpMethod _method, string _uri, string[] headers, string[] values)
        {
            string _response = String.Empty;
            using (var client = new HttpClient())
            using (var request = new HttpRequestMessage(_method, _uri))
            {
                if (headers != null)
                {
                    int i = 0;
                    foreach (var p in headers)
                    {
                        request.Headers.Add(p, values[i].ToString());
                        i++;
                    }
                }

                var json = JsonSerializer.Serialize(_request);
                using (var stringContent = new StringContent(json, System.Text.Encoding.UTF8, "application/json"))
                {
                    request.Content = stringContent;

                    using (var response = await client.SendAsync(request, HttpCompletionOption.ResponseHeadersRead).ConfigureAwait(false))
                    {
                        var data = response.Content.ReadAsStringAsync().Result;
                        var labelValues = GetAllLabelValues(request, response);
                        var PartnerElapsedTime = GetElapsedTimeFromHeader(response);
                        HttpPartnerHistogram.WithLabels(labelValues).Observe(PartnerElapsedTime);

                        _response = data;
                    }
                }
            }
            return _response;
        }

        /// <summary>
        /// 同步呼叫API方法
        /// </summary>
        /// <param name="_request"></param>
        /// <param name="_method"></param>
        /// <param name="_uri"></param>
        /// <param name="headers"></param>
        /// <param name="values"></param>
        /// <returns></returns>
        public string Execute<T>(T _request, HttpMethod _method, string _uri, string[] headers, string[] values)
        {
            string _response = String.Empty;
            using (var client = new HttpClient())
            using (var request = new HttpRequestMessage(_method, _uri))
            {
                if (headers != null)
                {
                    int i = 0;
                    foreach (var p in headers)
                    {
                        request.Headers.Add(p, values[i].ToString());
                        i++;
                    }
                }

                var json = JsonSerializer.Serialize(_request);
                using (var stringContent = new StringContent(json, System.Text.Encoding.UTF8, "application/json"))
                {
                    request.Content = stringContent;

                    using (var response = client.Send(request, HttpCompletionOption.ResponseHeadersRead))
                    {
                        var data = response.Content.ReadAsStringAsync().Result;
                        var labelValues = GetAllLabelValues(request, response);
                        var PartnerElapsedTime = GetElapsedTimeFromHeader(response);
                        HttpPartnerHistogram.WithLabels(labelValues).Observe(PartnerElapsedTime);

                        _response = data;
                    }
                }
            }
            return _response;
        }
    }
}
