﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Seamless.Core.API.Interfaces;

namespace Seamless.Core.API.Services
{
    /// <summary>
    /// 
    /// </summary>
    public class GameService : IGameService
    {
        /// <summary>
        /// 
        /// </summary>
        private readonly Models.ManufacturerCMSContext _context = new Models.ManufacturerCMSContext();

        /// <summary>
        /// 
        /// </summary>
        /// <param name="context"></param>
        //public GameService(Models.ManufacturerCMSContext context)
        //{
        //    this._context = context;      
        //}

        /// <summary>
        /// 
        /// </summary>
        /// <param name="_id"></param>
        /// <returns></returns>
        public Models.Game Get(int _id)
        {
            var _response = _context.Games.Where(x => x.Id == _id).FirstOrDefault();
            return _response;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="_code"></param>
        /// <returns></returns>
        public Models.Game Get(string _code)
        {
            var _response = _context.Games.Where(x => x.Code == _code).FirstOrDefault();
            return _response;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="_vendorid"></param>
        /// <returns></returns>
        public List<Models.Game> GetByVendor(int _vendorid)
        {
            var _response = _context.Games.Where(x => x.IdVendor == _vendorid).ToList();
            return _response;
        }
    }
}
