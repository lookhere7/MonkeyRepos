﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Seamless.Core.API.Interfaces;
using Microsoft.EntityFrameworkCore;
using Seamless.Core.API.Utility;
using System.Text.Json;

namespace Seamless.Core.API.Services
{
    public class VendorService : IVendorService
    {
        /// <summary>
        /// 
        /// </summary>
        private readonly Models.ManufacturerCMSContext _context = new Models.ManufacturerCMSContext();
        private readonly Models.SP_ManufacturerCMSContext _sp_context = new Models.SP_ManufacturerCMSContext();
        private readonly ICacheService _cacheService;
        private readonly IOperatorService _operatorService;
        private readonly IPubSubService _pubsubService;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="context"></param>
        public VendorService(ICacheService cacheService, IOperatorService operatorService, IPubSubService pubsubService)
        {
            //_context = context;
            _cacheService = cacheService;
            _operatorService = operatorService;
            _pubsubService = pubsubService;
        }

        /// <summary>
        /// EF Add(Sample)
        /// </summary>
        /// <param name="_model"></param>
        /// <returns></returns>
        public async Task<int> Add(Models.Vendor _model)
        {
            _context.Vendors.Add(_model);
            return await _context.SaveChangesAsync();
        }

        /// <summary>
        /// EF Call SP(Sample)
        /// </summary>
        /// <param name="_spname"></param>
        /// <param name="_paras"></param>
        /// <returns></returns>
        public async Task<List<Model.SP_VendorImplementInfoResponse>> GetImplementInfo_CallSP(string _spname, string[] _paras)
        {
            string _strparas = "";
            for (var i = 0; i < _paras.Length; i++)
            {
                _strparas += $"?p{i.ToString()},";
            }
            if (_strparas.Length > 0) _strparas = _strparas.Substring(0, _strparas.Length - 1);
            var _response = await _sp_context.Set<Model.SP_VendorImplementInfoResponse>().FromSqlRaw($"Call {_spname}({_strparas});", parameters: _paras).ToListAsync();
            return _response;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="_id"></param>
        /// <returns></returns>
        public async Task<Models.Vendor> GetVendor(int _id)
        {
            #region 取得Redis快取
            //取得Redis快取
            var _response = await _cacheService.GetFromCache<Models.Vendor>($"Vendor_{_id.ToString()}");
            if (_response == null)
            {
                //若無快取，則重新撈取資料
                _response = await _context.Vendors.Where(x => x.Id == _id).FirstOrDefaultAsync();

                //新增Redis快取
                await _cacheService.SetCache<Models.Vendor>($"Vendor_{_id.ToString()}", _response, 3);
            }
            #endregion

            return _response;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="_vendorid"></param>
        /// <returns></returns>
        public async Task<Models.VendorImplementInfo> GetVendorImplementInfo(int _vendorid)
        {
            #region 取得Redis快取
            //取得Redis快取
            var _response = await _cacheService.GetFromCache<Models.VendorImplementInfo>($"VendorImplementInfo_{_vendorid.ToString()}");
            if (_response == null)
            {
                //若無快取，則重新撈取資料
                _response = await _context.VendorImplementInfos.Where(x => x.IdVendor == _vendorid).FirstOrDefaultAsync();

                //新增Redis快取
                await _cacheService.SetCache<Models.VendorImplementInfo>($"VendorImplementInfo_{_vendorid.ToString()}", _response, 3);
            }
            #endregion

            return _response;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="_vendorid"></param>
        /// <returns></returns>
        public async Task<Models.VendorImplementInfo> GetVendorImplementInfo(string _vendorid)
        {
            #region 取得Redis快取
            //取得Redis快取
            var _response = await _cacheService.GetFromCache<Models.VendorImplementInfo>($"VendorImplementInfo_{_vendorid}");
            if (_response == null)
            {
                //若無快取，則重新撈取資料
                _response = await _context.VendorImplementInfos.Where(x => x.VendorId == _vendorid).FirstOrDefaultAsync();

                //新增Redis快取
                await _cacheService.SetCache<Models.VendorImplementInfo>($"VendorImplementInfo_{_vendorid}", _response, 3);
            }
            #endregion

            return _response;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="_vendorid"></param>
        /// <param name="_operatorid"></param>
        /// <param name="_gameid"></param>
        /// <returns></returns>
        public async Task<List<Models.VendorOperatorAccountMapping>> GetVendorOperatorAccountMapping(int _vendorid, int _operatorid, int _gameid)
        {
            #region 取得Redis快取
            //取得Redis快取
            var _response = await _cacheService.GetFromCache<List<Models.VendorOperatorAccountMapping>>($"VendorOperatorAccountMapping_{_vendorid.ToString()}_{_operatorid.ToString()}_{_gameid.ToString()}");
            if (_response == null)
            {
                //若無快取，則重新撈取資料
                _response = await _context.VendorOperatorAccountMappings.Where(x => x.IdOperator == _operatorid && x.IdVendor == _vendorid && x.GameId == _gameid).ToListAsync();

                //新增Redis快取
                await _cacheService.SetCache<List<Models.VendorOperatorAccountMapping>>($"VendorOperatorAccountMapping_{_vendorid.ToString()}_{_operatorid.ToString()}_{_gameid.ToString()}", _response, 3);
            }
            #endregion

            return _response;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="_vendorid"></param>
        /// <param name="_operatorid"></param>
        /// <param name="_gameid"></param>
        /// <param name="_route"></param>
        /// <returns></returns>
        public async Task<Models.VendorOperatorAccountMapping> GetVendorOperatorAccountMapping(int _vendorid, int _operatorid, int _gameid, int _route)
        {
            #region 取得Redis快取
            //取得Redis快取
            var _response = await _cacheService.GetFromCache<Models.VendorOperatorAccountMapping>($"VendorOperatorAccountMapping_{_vendorid.ToString()}_{_operatorid.ToString()}_{_gameid.ToString()}");
            if (_response == null)
            {
                //若無快取，則重新撈取資料
                _response = await _context.VendorOperatorAccountMappings.Where(x => x.IdOperator == _operatorid && x.IdVendor == _vendorid && x.GameId == _gameid && x.Route == _route).FirstOrDefaultAsync();

                //新增Redis快取
                await _cacheService.SetCache<Models.VendorOperatorAccountMapping>($"VendorOperatorAccountMapping_{_vendorid.ToString()}_{_operatorid.ToString()}_{_gameid.ToString()}", _response, 3);
            }
            #endregion

            return _response;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="_vendorid"></param>
        /// <param name="_operatorid"></param>
        /// <param name="_implementid"></param>
        /// <returns></returns>
        public async Task<List<Models.VendorOperatorAccountMapping>> GetVendorOperatorAccountMapping(int _vendorid, int _operatorid, string _implementid)
        {
            #region 取得Redis快取
            //取得Redis快取
            var _response = await _cacheService.GetFromCache<List<Models.VendorOperatorAccountMapping>>($"VendorOperatorAccountMapping_{_vendorid.ToString()}_{_operatorid.ToString()}_{_implementid}");
            if (_response == null)
            {
                //若無快取，則重新撈取資料
                _response = await _context.VendorOperatorAccountMappings.Where(x => x.IdOperator == _operatorid && x.IdVendor == _vendorid && x.ImplementId == _implementid).ToListAsync();

                //新增Redis快取
                await _cacheService.SetCache<List<Models.VendorOperatorAccountMapping>>($"VendorOperatorAccountMapping_{_vendorid.ToString()}_{_operatorid.ToString()}_{_implementid}", _response, 3);
            }
            #endregion

            return _response;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="_vendorid"></param>
        /// <param name="_operatorid"></param>
        /// <param name="_implementid"></param>
        /// <param name="_route"></param>
        /// <returns></returns>
        public async Task<Models.VendorOperatorAccountMapping> GetVendorOperatorAccountMapping(int _vendorid, int _operatorid, string _implementid, int _route)
        {
            #region 取得Redis快取
            //取得Redis快取
            var _response = await _cacheService.GetFromCache<Models.VendorOperatorAccountMapping>($"VendorOperatorAccountMapping_{_vendorid.ToString()}_{_operatorid.ToString()}_{_implementid}");
            if (_response == null)
            {
                //若無快取，則重新撈取資料
                _response = await _context.VendorOperatorAccountMappings.Where(x => x.IdOperator == _operatorid && x.IdVendor == _vendorid && x.ImplementId == _implementid && x.Route == _route).FirstOrDefaultAsync();

                //新增Redis快取
                await _cacheService.SetCache<Models.VendorOperatorAccountMapping>($"VendorOperatorAccountMapping_{_vendorid.ToString()}_{_operatorid.ToString()}_{_implementid}", _response, 3);
            }
            #endregion

            return _response;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="_vendorid"></param>
        /// <param name="_operatorid"></param>
        /// <param name="_implementvcode"></param>
        /// <param name="_route"></param>
        /// <returns></returns>
        public async Task<Models.VendorOperatorAccountMapping> GetVendorOperatorAccountMapping(int _vendorid, string _implementvcode, int _route)
        {
            #region 取得Redis快取
            //取得Redis快取
            var _response = await _cacheService.GetFromCache<Models.VendorOperatorAccountMapping>($"VendorOperatorAccountMapping_{_vendorid.ToString()}_{_implementvcode}");
            if (_response == null)
            {
                //若無快取，則重新撈取資料
                _response = await _context.VendorOperatorAccountMappings.Where(x => x.IdVendor == _vendorid && x.ImplementVcode == _implementvcode && x.Route == _route).FirstOrDefaultAsync();

                //新增Redis快取
                await _cacheService.SetCache<Models.VendorOperatorAccountMapping>($"VendorOperatorAccountMapping_{_vendorid.ToString()}_{_implementvcode}", _response, 3);
            }
            #endregion

            return _response;
        }

        /// <summary>
        /// 取得相關Table資料(資料已Redis)
        /// </summary>
        /// <param name="_model"></param>
        /// <param name="_verifyfields"></param>
        /// <param name="_response"></param>
        /// <returns></returns>
        public async Task<Model.Vendor.VendorDataResponse> GetVendorData<T1, T2>(T1 _model, T2 _model_data, string _verifyfields, Model.DefaultResponse _response)
        {
            Model.Vendor.VendorDataResponse _vendordata = new();
            
            string _merchantid = "";
            string _vcode = "";
            string _gameid = "";
            string _hash = "";
            
            #region 驗證傳入參數
            //驗證Request的值(_model)
            _response = VerifyReqParams<T1>.verifyReqParams(_response, _model, "data,hash");
            if (_response.code != 0)
            {
                _vendordata.DefaultResponse = _response;
                return _vendordata;
            }

            //驗證Request的值(_model.data)
            _response = VerifyReqParams<T2>.verifyReqParams(_response, _model_data, _verifyfields);
            if (_response.code != 0)
            {
                _vendordata.DefaultResponse = _response;
                return _vendordata;
            }
            #endregion

            foreach (var prop in _model.GetType().GetProperties())
            {
                //取得hash的值
                switch (prop.Name.ToLower())
                {
                    case "hash":
                        {
                            _hash = (prop.GetValue(_model) == null) ? "" : prop.GetValue(_model).ToString();
                            break;
                        }
                    default:
                        break;
                }
            }
            foreach (var prop in _model_data.GetType().GetProperties())
            {
                //取得data裡的值
                switch (prop.Name.ToLower())
                {
                    case "merchantid":
                        {
                            _merchantid = (prop.GetValue(_model_data) == null) ? "" : prop.GetValue(_model_data).ToString();
                            break;
                        }
                    case "vcode":
                        {
                            _vcode = (prop.GetValue(_model_data) == null) ? "" : prop.GetValue(_model_data).ToString();
                            break;
                        }
                    case "gameid":
                        {
                            _gameid = (prop.GetValue(_model_data) == null) ? "" : prop.GetValue(_model_data).ToString();
                            break;
                        }
                    default:
                        break;
                }
            }
            //var _data = _model.GetType().GetProperties()[0].GetValue(_model).ToString();
            //var _hash = _model.GetType().GetProperties()[1].GetValue(_model).ToString();
            //var _merchantid = _model_data.GetType().GetProperties()[0].GetValue(_model_data).ToString();
            //var _vcode = _model_data.GetType().GetProperties()[1].GetValue(_model_data).ToString();
            //var _gameid = _model_data.GetType().GetProperties()[2].GetValue(_model_data).ToString();

            //Todo:記錄LOG:API 呼叫紀錄寫入 Pub/Sub
            #region 記錄LOG:API 呼叫紀錄寫入 Pub/Sub(Start)
            //Model.PubSubRequest _model_pubsub = new();
            //_model_pubsub.gameid = _gameid;
            //string _messageid = await _pubsubService.SeamlessRequestLog<Model.PubSubRequest>(_model_pubsub);
            #endregion

            //取得VendorImplementInfo Redis快取資料
            var _vendorimplementinfo = await GetVendorImplementInfo(_merchantid);
            if (_vendorimplementinfo == null)
            {
                _response.code = 1006;
                _response.status = "VendorImplementInfo mapping data not exist";
            }
            if (_response.code != 0)
            {
                _vendordata.DefaultResponse = _response;
                return _vendordata;
            }
            _vendordata.Redis_VendorImplementInfo = _vendorimplementinfo;

            //取得Vendor Redis快取資料
            var _vendor = await GetVendor((int)_vendorimplementinfo.IdVendor);
            if (_vendor == null)
            {
                _response.code = 1006;
                _response.status = "Vendor mapping data not exist";
            }
            if (_response.code != 0)
            {
                _vendordata.DefaultResponse = _response;
                return _vendordata;
            }
            _vendordata.Redis_Vendor = _vendor;

            string _json = JsonSerializer.Serialize(_model_data);
            string _hashkey = _vendor.HashKey;
            string _realhash = Utility.Encryptions.MD5_Generate(_json + _hashkey);

            //判斷Hash是否正確
            if (_hash != _realhash)
            {
                _response.code = 1006;
                _response.status = "Hash Error:" + _realhash;
            }
            if (_response.code != 0)
            {
                _vendordata.DefaultResponse = _response;
                return _vendordata;
            }

            //取得VendorOperatorAccountMapping Redis快取資料
            var _vendoroperatoraccountmapping = await GetVendorOperatorAccountMapping((int)_vendorimplementinfo.IdVendor, _vcode, 2);
            if (_vendoroperatoraccountmapping == null)
            {
                _response.code = 1006;
                _response.status = "VendorOperatorAccountMapping mapping data not exist";
            }
            if (_response.code != 0)
            {
                _vendordata.DefaultResponse = _response;
                return _vendordata;
            }
            _vendordata.Redis_VendorOperatorAccountMapping = _vendoroperatoraccountmapping;

            //取得VendorOperatorAccountMapping Redis快取資料
            var _vendoroperatoraccountmapping1 = await GetVendorOperatorAccountMapping((int)_vendorimplementinfo.IdVendor, (int)_vendoroperatoraccountmapping.IdOperator, _gameid, 2);
            if (_vendoroperatoraccountmapping1 == null && _gameid != "")
            {
                _response.code = 1006;
                _response.status = "VendorOperatorAccountMapping1 mapping data not exist";
            }
            if (_response.code != 0)
            {
                _vendordata.DefaultResponse = _response;
                return _vendordata;
            }
            _vendordata.Redis_VendorOperatorAccountMapping1 = _vendoroperatoraccountmapping1;

            int _operatorid = (int)_vendoroperatoraccountmapping.IdOperator;

            //取得Operator Redis快取資料
            var _operator = await _operatorService.GetOperator(_operatorid);
            if (_operator == null)
            {
                _response.code = 1006;
                _response.status = "Operator mapping data not exist";
            }
            if (_response.code != 0)
            {
                _vendordata.DefaultResponse = _response;
                return _vendordata;
            }
            _vendordata.Redis_Operator = _operator;

            string _apicode = _operator.ApiCode;

            //取得OperatorImplementInfo Redis快取資料
            var _operatorimplementinfo = await _operatorService.GetOperatorImplementInfo(_operatorid);
            if (_operatorimplementinfo == null)
            {
                _response.code = 1006;
                _response.status = "OperatorImplementInfo mapping data not exist";
            }
            if (_response.code != 0)
            {
                _vendordata.DefaultResponse = _response;
                return _vendordata;
            }
            _vendordata.Redis_OperatorImplementInfo = _operatorimplementinfo;

            string _newgameid = (_vendoroperatoraccountmapping1 == null) ? "" : _vendoroperatoraccountmapping1.OperatorImplementId;

            _vendordata.ApiCode = _apicode;
            _vendordata.NewGameID = _newgameid;
            _vendordata.DefaultResponse = _response;

            return _vendordata;
        }
    }
}
