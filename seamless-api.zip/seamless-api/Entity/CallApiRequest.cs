﻿using System.Collections.Generic;

namespace Seamless.Core.API.Entity.CallApiRequest
{
    public class CreateTokenRequest
    {
        public string gameId { get; set; }
    }

    public class BetRequest_vm
    {
        public string roundID { get; set; }
        public string Currency { get; set; }
        public string BetAmount { get; set; }
        public string WinAmount { get; set; }
        public bool End { get; set; }
        public bool Jackpot { get; set; }
        public string External { get; set; }
    }

    public class BetRequest_aceonline
    {
        public string userId { get; set; }
        public string transactionId { get; set; }
        public string accountToken { get; set; }
        public string gameSessionId { get; set; }
        public string gameId { get; set; }
        public string wagerId { get; set; }
        public string operations { get; set; }
    }

    public class BetRequest_aceonline_tags
    {
        public string operationType { get; set; }
        public string tagType { get; set; }
        public ICollection<BetRequest_aceonline_tags_tags_actions> tags { get; set; }
    }

    public class BetRequest_aceonline_tags_tags_actions
    {
        public ICollection<BetRequest_aceonline_tags_tags_actions_list> actions {get;set;}
    }

    public class BetRequest_aceonline_tags_tags_actions_list
    {
        public string action { get; set; }
        public string moneyAmount { get; set; }
    }

    public class BetRequest_aceonline_gametags
    {
        public string operationType { get; set; }
        public string tagType { get; set; }
        public ICollection<BetRequest_aceonline_gametags_tag> tag { get; set; }
    }

    public class BetRequest_aceonline_gametags_tag
    {
        public string offlineSpin { get; set; }
        public string detail { get; set; }
    }

    public class BetRequest_aceonline_operations
    {
        public ICollection<BetRequest_aceonline_operations_list1> operations_list1 { get; set; }
        public ICollection<BetRequest_aceonline_operations_list2> operations_list2 { get; set; }
    }

    public class BetRequest_aceonline_operations_list1
    {
        public string operationType { get; set; }
        public string action { get; set; }
    }

    public class BetRequest_aceonline_operations_list2
    {
        public string operationType { get; set; }
        public string withdraw { get; set; }
        public bool transfer { get; set; }
        public string id { get; set; }
    }

    public class BetRequest_08online_formdata
    {
        public string reqid { get; set; }
        public string token { get; set; }
        public string currency { get; set; }
        public string gameid { get; set; }
        public string transactionid { get; set; }
        public string roundid { get; set; }
        public string bettime { get; set; }
        public string betamount { get; set; }
        public string winloseamount { get; set; }
        public bool isfreeround { get; set; }
        public bool jackpot { get; set; }
        public int bonus { get; set; }
        public bool end { get; set; }
        public string detail { get; set; }
    }

    public class BetRequest_08online
    {
        public BetRequest_08online_formdata data { get; set; }
        public string hash { get; set; }
    }
}
