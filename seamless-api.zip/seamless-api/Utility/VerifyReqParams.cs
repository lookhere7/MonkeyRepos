﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Diagnostics;

namespace Seamless.Core.API.Utility
{
    public class VerifyReqParams<T>
    {
        public static Model.DefaultResponse verifyReqParams(Model.DefaultResponse _response, T _model, string _verifyfields)
        {
            //驗證Request的值
            var _arrverifyfields = _verifyfields.Split(',');
            foreach (var prop in _model.GetType().GetProperties())
            {
                var _datafield = (prop.GetValue(_model) == null) ? "" : prop.GetValue(_model).ToString();
                foreach (var vfield in _arrverifyfields)
                {
                    //只驗證需要驗證的欄位
                    if (prop.Name.ToLower() == vfield.ToLower())
                    {
                        if (string.IsNullOrEmpty(_datafield))
                        {
                            _response.code = 1006;
                            _response.status = $"{prop.Name} can not empty";
                        }
                    }
                }
            }

            return _response;
        }
    }
}
