﻿using System;
using System.Collections.Generic;

namespace WebAPI1.Models
{
    public partial class Test
    {
        public string CountryCode { get; set; } = null!;
        public string Language { get; set; } = null!;
        public string IsOfficial { get; set; } = null!;
        public decimal Percentage { get; set; }

        public ICollection<Test_Detail> CountryCodeNavigation { get; set; } = null!;
    }

    public partial class Test_Detail
    {
        public string argname { get; set; } = null!;
        public string argage { get; set; } = null!;
    }
}
