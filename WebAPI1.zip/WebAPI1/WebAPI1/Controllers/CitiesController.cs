﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using NuGet.Packaging;
using WebAPI1.Models;
using System.Text.Json;

namespace WebAPI1.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class CitiesController : Controller
    {
        private readonly WorldContext _context = new();

        public CitiesController()
        {
        }

        [HttpGet, Route("GetCities")]
        // GET: Cities
        public List<City> GetCities()
        {
            var id = 1;
            var post = _context.Cities.Find(id);
            var posts = _context.Cities.Where(p => p.Id < 10).OrderBy(p => p.Id).ToList();
            return posts;
        }

        [HttpGet, Route("GetCities2")]
        // GET: Cities
        public List<City> GetCities2()
        {
            var id = 1;
            var post = _context.Cities.Find(id);
            var posts = _context.Cities.Where(p => p.Id < 10).OrderBy(p => p.Id).ToList();
            return posts;
        }

        [HttpGet, Route("Test")]
        // GET: Cities
        public List<Test> Test()
        {
            List<Test> _mytest=new List<Test>();

            List<Test_Detail> _mytest_detail=new List<Test_Detail>();
            _mytest_detail.Add(new Test_Detail() { argname = "stanley", argage = "40" });
            _mytest_detail.Add(new Test_Detail() { argname = "eddie", argage = "11" });

            _mytest.Add(new Test() { CountryCode = "1", Language = "A",CountryCodeNavigation= _mytest_detail });
            return _mytest;
        }

        [HttpGet, Route("Test2")]
        // GET: Cities
        public string Test2()
        {
            List<Test> _mytest = new List<Test>();

            List<Test_Detail> _mytest_detail = new List<Test_Detail>();
            _mytest_detail.Add(new Test_Detail() { argname = "stanley", argage = "40" });
            _mytest_detail.Add(new Test_Detail() { argname = "eddie", argage = "11" });

            _mytest.Add(new Test() { CountryCode = "1", Language = "A", CountryCodeNavigation = _mytest_detail });
            var aa = JsonSerializer.Serialize(_mytest);
            return aa;
        }

        [HttpGet, Route("Test3")]
        // GET: Cities
        public List<Test> Test3()
        {
            List<Test> _mytest = new List<Test>();

            List<Test_Detail> _mytest_detail = new List<Test_Detail>();
            _mytest_detail.Add(new Test_Detail() { argname = "stanley", argage = "40" });
            _mytest_detail.Add(new Test_Detail() { argname = "eddie", argage = "11" });

            _mytest.Add(new Test() { CountryCode = "1", Language = "A", CountryCodeNavigation = _mytest_detail });
            var aa = JsonSerializer.Serialize(_mytest);
            var bb = JsonSerializer.Deserialize<List<Test>>(aa);
            return bb;
        }
    }
}
