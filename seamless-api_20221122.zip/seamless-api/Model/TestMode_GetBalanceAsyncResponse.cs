﻿using System;
using System.Collections.Generic;

namespace Seamless.Core.API.Model
{
    /// <summary>
    /// 呼叫SP回傳的model參數設定
    /// </summary>
    public partial class TestMode_GetBalanceAsyncResponse
    {
        public float Balance { get; set; }
    }
}
