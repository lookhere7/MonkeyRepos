﻿using System;
using System.Collections.Generic;

namespace Seamless.Core.API.Model
{
    /// <summary>
    /// 呼叫SP回傳的model參數設定
    /// </summary>
    public partial class TestMode_CreateTokenAsyncResponse
    {
        public string Username { get; set; }
        public float Balance { get; set; }
        public string Token { get; set; }
    }
}
