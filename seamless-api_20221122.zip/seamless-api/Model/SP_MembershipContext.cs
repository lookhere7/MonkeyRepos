﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.Extensions.Configuration;
using System.IO;
using System.Linq;

namespace Seamless.Core.API.Model
{
    /// <summary>
    /// 提供呼叫SP使用
    /// </summary>
    public partial class SP_MembershipContext : DbContext
    {
        public SP_MembershipContext()
        {
        }

        public SP_MembershipContext(DbContextOptions<SP_MembershipContext> options)
            : base(options)
        {
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {

            if (!optionsBuilder.IsConfigured)
            {
                var builder = new ConfigurationBuilder()
                  .SetBasePath(Directory.GetCurrentDirectory())
                  .AddJsonFile("appsettings.json");
                var config = builder.Build();

                optionsBuilder.UseMySql(config.GetConnectionString("Connection_Membership"), Microsoft.EntityFrameworkCore.ServerVersion.Parse("5.7.36-mysql"));
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.UseCollation("utf8_general_ci")
                .HasCharSet("utf8");

            modelBuilder.Entity<Model.TestMode_CreateTokenAsyncResponse>(entity =>
            {
                entity.HasNoKey();

                entity.Property(e => e.Username)
                    .HasColumnType("VARCHAR(45)");

                entity.Property(e => e.Balance)
                    .HasColumnType("DECIMAL(18,2)");

                entity.Property(e => e.Token)
                    .HasColumnType("VARCHAR(2000)");
            });

            modelBuilder.Entity<Model.TestMode_BetAsyncResponse>(entity =>
            {
                entity.HasNoKey();

                entity.Property(e => e.Code)
                    .HasColumnType("INT");

                entity.Property(e => e.Balance)
                    .HasColumnType("DECIMAL(18,2)");

                entity.Property(e => e.OldBalance)
                    .HasColumnType("DECIMAL(18,2)");
            });

            modelBuilder.Entity<Model.TestMode_AuthAsyncResponse>(entity =>
            {
                entity.HasNoKey();

                entity.Property(e => e.Code)
                    .HasColumnType("INT");

                entity.Property(e => e.Username)
                    .HasColumnType("VARCHAR(45)");

                entity.Property(e => e.Nickname)
                    .HasColumnType("VARCHAR(45)");

                entity.Property(e => e.Token)
                    .HasColumnType("VARCHAR(2000)");

                entity.Property(e => e.Balance)
                    .HasColumnType("DECIMAL(18,2)");

                entity.Property(e => e.Currency)
                    .HasColumnType("VARCHAR(20)");
            });

            modelBuilder.Entity<Model.TestMode_SettleAsyncResponse>(entity =>
            {
                entity.HasNoKey();

                entity.Property(e => e.Code)
                    .HasColumnType("INT");

                entity.Property(e => e.Balance)
                    .HasColumnType("DECIMAL(18,2)");

                entity.Property(e => e.OldBalance)
                    .HasColumnType("DECIMAL(18,2)");
            });

            modelBuilder.Entity<Model.TestMode_GetBalanceAsyncResponse>(entity =>
            {
                entity.HasNoKey();

                entity.Property(e => e.Balance)
                    .HasColumnType("DECIMAL(18,2)");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
