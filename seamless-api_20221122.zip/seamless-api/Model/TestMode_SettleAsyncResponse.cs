﻿using System;
using System.Collections.Generic;

namespace Seamless.Core.API.Model
{
    /// <summary>
    /// 呼叫SP回傳的model參數設定
    /// </summary>
    public partial class TestMode_SettleAsyncResponse
    {
        public int Code { get; set; }
        public float Balance { get; set; }
        public float OldBalance { get; set; }
    }
}
