﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Seamless.Core.API.Model.Environment
{
    public class PubSubAppSettingVariables
    {
        public string topic { get; set; }
        public string topic_login { get; set; }
        public string subscription { get; set; }
        public string subscription_login { get; set; }
        public string keyfile { get; set; }
        public Layer3 layer3 { get; set; }

        public class Layer3
        {
            public string layer4 { get; set; }
        }
    }
}
