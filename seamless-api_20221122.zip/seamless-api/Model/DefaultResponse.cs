﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Seamless.Core.API.Model
{
    public class DefaultResponse
    {
        public int code { get; set; }
        public string status { get; set; }
        public dynamic result { get; set; }
        public dynamic additional { get; set; }
        public string type { get; set; }
        public string gameurl {get;set;}
        public dynamic info {get;set;}
    }
}
