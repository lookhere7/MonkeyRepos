﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Routing;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
//using Newtonsoft.Json;
using Prometheus;
using Seamless.Core.API.Data;
using Seamless.Core.API.Interfaces;
using Seamless.Core.API.Utility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;


namespace Seamless.Core.API.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class SeamlessController : ControllerBase
    {
        /// <summary>
        /// 
        /// </summary>
        private readonly Models.DB_ManufacturerCMS.ManufacturerCMSContext _manufacturercmscontext = new();
        #region Interfaces

        /// <summary>
        /// 
        /// </summary>
        private readonly IHttpContextAccessor _httpContextAccessor;

        /// <summary>
        /// 
        /// </summary>
        private readonly IGameService _gameService;

        /// <summary>
        /// 
        /// </summary>
        private readonly IOperatorService _operatorService;

        /// <summary>
        /// 
        /// </summary>
        private readonly IVendorService _vendorService;

        /// <summary>
        /// 
        /// </summary>
        private readonly ILogger<ExternalController> _logger;

        /// <summary>
        /// 
        /// </summary>
        private readonly IHttpClientFactory _httpClientFactory;

        /// <summary>
        /// 
        /// </summary>
        private readonly IConfiguration _configuration;

        /// <summary>
        /// 
        /// </summary>
        private readonly ICacheService _cacheService;

        /// <summary>
        /// 
        /// </summary>
        private readonly IPubSubService _pubsubService;

        /// <summary>
        /// 
        /// </summary>
        /// <value></value>
        private static readonly Histogram HttpPartnerHistogram = Metrics
        .CreateHistogram("http_request_duration_seconds_partner", "request duration in seconds",
            new HistogramConfiguration
            {
                Buckets = Histogram.ExponentialBuckets(0.001, 2, 16),
                LabelNames = new[] { "method", "controller", "action", "partner_code", "partner_host", "partner_uri", "partner_method" }
            });

        #endregion

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        private readonly MySQL _mysql = new();

        /// <summary>
        /// 
        /// </summary>
        /// <param name="httpContextAccessor"></param>
        public SeamlessController(IHttpContextAccessor httpContextAccessor, IOperatorService operatorService, IVendorService vendorService, IGameService gameService, ILogger<ExternalController> logger, IHttpClientFactory httpClientFactory, IConfiguration configuration, ICacheService cacheService, MySQL mysql, IPubSubService pubsubService)
        {
            _httpContextAccessor = httpContextAccessor;
            _gameService = gameService;
            _operatorService = operatorService;
            _vendorService = vendorService;
            _logger = logger;
            _httpClientFactory = httpClientFactory;
            _configuration = configuration;
            _cacheService = cacheService;
            _mysql = mysql;
            _pubsubService = pubsubService;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="request"></param>
        /// <param name="response"></param>
        /// <returns></returns>
        private string[] GetAllLabelValues(HttpRequestMessage request, HttpResponseMessage response)
        {
            var RouteData = HttpContext.GetRouteData()?.Values;
            var Controller = RouteData?.GetValueOrDefault("controller", string.Empty) as string ?? string.Empty;
            var Action = RouteData?.GetValueOrDefault("action", string.Empty) as string ?? string.Empty;
            var Method = HttpContext.Request.Method.ToString();

            var PartnerCode = ((int)response.StatusCode).ToString();
            var PartnerHost = request.RequestUri?.Host ?? string.Empty;
            var PartnerPath = request.RequestUri?.AbsolutePath ?? string.Empty; ;
            var PartnerMethod = request.Method.ToString();

            return new[] { Method, Controller, Action, PartnerCode, PartnerHost, PartnerPath, PartnerMethod };
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="response"></param>
        /// <param name="key"></param>
        /// <returns></returns>
        private double GetElapsedTimeFromHeader(HttpResponseMessage response, string key = "X-Partner-ElapsedTime")
        {
            //var elapsedTime = response.Headers.GetValues(key).FirstOrDefault();
            var elapsedTime = DateTime.UtcNow.ToString("yyyy-MM-dd HH:mm:ss.fff");
            if (string.IsNullOrEmpty(elapsedTime))
                elapsedTime = "0";
            else
            {
                DateTime current = DateTime.UtcNow;
                DateTime before = DateTime.Parse(elapsedTime);
                elapsedTime = (current - before).TotalSeconds.ToString();
            }

            return Convert.ToDouble(elapsedTime);
        }

        /// <summary>
        /// 進入遊戲 (POST) - 原生進入使用
        /// </summary>
        /// <param name="_model"></param>
        /// <returns></returns>
        [HttpPost, Route("Startup")]
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public async Task<Model.DefaultResponse> Startup(Model.Vendor.StartupRequest _model)
        {
            Model.DefaultResponse _response = new();
            Model.PubSubRequest _model_pubsub = new();
            _response.type = "Startup";
            //設定記錄Pub/Sub相關參數
            _model_pubsub.merchantid = _model.data.merchantid;
            _model_pubsub.vcode = _model.data.vcode;
            _model_pubsub.gameid = _model.data.gameid;
            _model_pubsub.usertoken = _model.data.usertoken;
            _model_pubsub.sessiontoken = _model.data.sessiontoken;
            _model_pubsub.currency = _model.data.currency;

            try
            {
                #region 驗證相關欄位並取得相關Table資料
                //設定驗證欄位
                var _verifyfields = "merchantid,vcode,usertoken";
                //取得相關Table資料(資料已Redis)
                var _vendordataresponse = await _vendorService.GetVendorData<Model.Vendor.StartupRequest, Model.Vendor.StartupRequestParams>(_model, _model.data, _verifyfields, _response, _model_pubsub);
                _response = _vendordataresponse.DefaultResponse;
                if (_response.code != 0) return _response;
                #endregion

                //取得相關Table資料
                var _vendoroperatoraccountmapping = _vendordataresponse.Redis_VendorOperatorAccountMapping;
                var _operatorimplementinfo = _vendordataresponse.Redis_OperatorImplementInfo;
                var _vendorvariable = _vendordataresponse.Redis_VendorVariable;
                var _vendorbundlemapping = _vendordataresponse.Redis_VendorBundleMapping;
                var _operatorimplementinfosecretkey = _operatorimplementinfo.SecretKey;
                var _apicode = _vendordataresponse.ApiCode;
                string _uri = _operatorimplementinfo.UrlPlay;
                string _newgameid = _vendordataresponse.NewGameID;
                _model_pubsub.url = _uri;

                //switch (_vendoroperatoraccountmapping.TestMode)
                //{
                //    case 0:
                Services.External.CallBackService _callback = new Services.External.CallBackService(_httpContextAccessor);

                _uri = (string.IsNullOrEmpty(_vendoroperatoraccountmapping.UrlPlay)) ? _uri : _vendoroperatoraccountmapping.UrlPlay;
                _uri = (string.IsNullOrEmpty(_model.data.usertoken)) ? _uri : _uri.Replace("{usertoken}", _model.data.usertoken.Trim());
                _uri = (string.IsNullOrEmpty(_model.data.sessiontoken)) ? _uri : _uri.Replace("{sessiontoken}", _model.data.sessiontoken.Trim());
                _uri = (string.IsNullOrEmpty(_model.data.gameid)) ? _uri : _uri.Replace("{gameid}", _model.data.gameid.Trim());
                _uri = (string.IsNullOrEmpty(_model.data.language)) ? _uri : _uri.Replace("{language}", _model.data.language.Trim());
                _uri = (string.IsNullOrEmpty(_model.data.launchfrom)) ? _uri : $"{_uri}&launchFrom={_model.data.launchfrom.Trim()}";
                _uri = (string.IsNullOrEmpty(_model.data.bundlesdk)) ? _uri : $"{_uri}&bundlesdk={_model.data.bundlesdk.Trim()}";
                _uri = (string.IsNullOrEmpty(_model.data.roadcontrol)) ? _uri : _uri.Replace("{useRoadControl}", _model.data.roadcontrol.Trim());
                _uri = (string.IsNullOrEmpty(_model.data.lobbystyle)) ? _uri : _uri.Replace("{lobbyStyle}", _model.data.lobbystyle.Trim());
                _uri = (string.IsNullOrEmpty(_model.data.debugmenu)) ? _uri.Replace("{debugMenu}", "") : _uri.Replace("{debugMenu}", _model.data.debugmenu.Trim());

                if (_model.data.vcode == "audere")
                {
                    _uri = (string.IsNullOrEmpty(_vendoroperatoraccountmapping.OperatorGameId)) ? _uri.Replace("{serverid}", "") : _uri.Replace("{serverid}", _vendoroperatoraccountmapping.OperatorGameId.Trim());
                    _uri = (string.IsNullOrEmpty(_vendoroperatoraccountmapping.OperatorKey)) ? _uri.Replace("{systemid}", "") : _uri.Replace("{systemid}", _vendoroperatoraccountmapping.OperatorKey.Trim());
                    _uri = (string.IsNullOrEmpty(_vendoroperatoraccountmapping.OperatorId)) ? _uri.Replace("{operatorid}", "") : _uri.Replace("{operatorid}", _vendoroperatoraccountmapping.OperatorId.Trim());

                    if (!string.IsNullOrEmpty(_vendoroperatoraccountmapping.ImplementId))
                    {
                        _uri = _uri.Replace("{selectGame}", _vendoroperatoraccountmapping.ImplementId.Trim());
                        _uri = $"{_uri}&gameId={_vendoroperatoraccountmapping.ImplementId.Trim()}";
                    }

                    var _games = _model.data.games.Replace("audere_", "");
                    _games = _games.Replace("dragontiger", "dragonTiger");
                    _games = _games.Replace("classicbaccarat", "classicBaccarat");
                    _games = _games.Replace("supersixsqueeze", "superSixSqueeze");
                    _games = _games.Replace("supersix", "superSix");
                    _games = _games.Replace("superdragontiger", "superDragonTiger");
                    _games = _games.Replace("dragontiger", "dragonTiger");

                    _uri = _uri.Replace("{games}", _games);

                    _uri = (string.IsNullOrEmpty(_model.data.site)) ? _uri : _uri.Replace("{site}", _model.data.site.Trim());
                }

                if (_model.data.vcode == "chess")
                {
                    _uri = (string.IsNullOrEmpty(_vendoroperatoraccountmapping.ImplementVcode)) ? _uri.Replace("{vcode}", "") : _uri.Replace("{vcode}", _vendoroperatoraccountmapping.ImplementVcode.Trim());
                    _uri = (string.IsNullOrEmpty(_vendoroperatoraccountmapping.OperatorKey)) ? _uri.Replace("{systemid}", "") : _uri.Replace("{systemid}", _vendoroperatoraccountmapping.OperatorKey.Trim());
                }

                if (!string.IsNullOrEmpty(_uri))
                {
                    if (_vendorvariable == null)
                    {
                        _response.code = 9997;
                        _response.status = "VendorVariable mapping data not exist";
                    }
                    if (_response.code != 0)
                    {
                        //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                        _model_pubsub.type = _response.type + " GetVendorData.GetVendorVariable";
                        _model_pubsub.responsedata = _response;
                        await _pubsubService.PublishMessagesAsync(_model_pubsub);
                        return _response;
                    }

                    var _startup = Newtonsoft.Json.JsonConvert.DeserializeObject<dynamic>(_vendorvariable.ParameterValue)!;
                    _startup.startup.url = _uri;

                    switch (_model.data.vcode)
                    {
                        case "chess":
                            if (_vendorbundlemapping == null)
                            {
                                _response.code = 9997;
                                _response.status = "VendorBundleMapping mapping data not exist";
                            }
                            if (_response.code != 0)
                            {
                                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                                _model_pubsub.type = _response.type + " GetVendorData.GetVendorBundleMapping";
                                _model_pubsub.responsedata = _response;
                                await _pubsubService.PublishMessagesAsync(_model_pubsub);
                                return _response;
                            }
                            _startup.bundle.bundleVers.packageName = _vendorbundlemapping.PackageName;
                            _startup.bundle.bundleVers.bundleName = _vendorbundlemapping.BundleName;

                            _response.code = 0;
                            _response.status = "Successful";
                            _response.gameurl = _uri;
                            _response.info = _startup;
                            break;
                        default:
                            break;
                    }
                }
                else
                {
                    _response.code = 1010;
                    _response.status = "Game Url not defined";
                    _response.gameurl = _uri;
                }

                //         break;
                //     case 1:

                //         break;
                // }

                //記錄LOG:API 呼叫記錄寫入 Pub/Sub(End)
                #region 記錄LOG:API 呼叫記錄寫入 Pub/Sub(End)
                _model_pubsub.type = $"{_response.type} End";
                _model_pubsub.url = _uri;
                _model_pubsub.responsedata = _response;
                await _pubsubService.PublishMessagesAsync(_model_pubsub);
                #endregion
            }
            catch (Exception ex)
            {
                _response.code = 9999;
                _response.status = ex.Message;

                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                _model_pubsub.type = $"{_response.type} End Catch Exception";
                _model_pubsub.responsedata = _response;
                await _pubsubService.PublishMessagesAsync(_model_pubsub);
            }

            return _response;
        }

        /// <summary>
        /// 進入遊戲 (GET)
        /// </summary>
        /// <param name="_model"></param>
        /// <returns></returns>
        [HttpGet, Route("Login")]
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public async Task<Model.DefaultResponse> Login([FromQuery] Model.Vendor.PlayRequest _model)
        {
            Model.DefaultResponse _response = new Model.DefaultResponse();
            Model.PubSubRequest _model_pubsub = new();

            var _vcode = "";
            var _operatorid = 0;
            var _playURL = "";

            var merchantid = _model.merchantid;
            var usertoken = _model.usertoken != "" ? _model.usertoken : _model.token != "" ? _model.token : _model.accesstoken;
            var sessiontoken = _model.sessiontoken != "" ? _model.sessiontoken : _model.token1;
            var licenseeid = _model.licenseeid;
            var vcode = _model.vcode;
            var gameid = _model.gameid;
            var configurationid = _model.configurationid;
            var language = _model.language != "" ? _model.language : _model.lang;
            var launchfrom = _model.launchfrom;
            var bundlesdk = _model.bundlesdk != "" ? _model.bundlesdk : _model.psdk;
            var vip = _model.vip;
            var currency = _model.currency;
            var isNative = _model.isNative;
            var isBridge = _model.isBridge;
            var roomType = _model.roomType;
            var history = _model.history;
            var gamebetid = _model.gamebetid;
            var debugMenu = _model.debugMenu;
            var games = _model.games;
            var site = _model.site;
            var roomid = _model.roomid;
            var roompwd = _model.roompwd;
            var roadcontrol = _model.roadcontrol;
            var lobbystyle = _model.lobbystyle;

            #region 偵測 User-Agent 內容 來源裝置
            //偵測 User-Agent 內容 來源裝置
            if (Request.Headers.TryGetValue("User-Agent", out var useragent) && launchfrom == "")
            {
                if (useragent.ToString().Contains("iPhone") || useragent.ToString().Contains("iPad"))
                {
                    launchfrom = "ios";
                }
                else if (useragent.ToString().Contains("Android"))
                {
                    launchfrom = "android";
                }
                else
                {
                    launchfrom = "web";
                }
            }
            #endregion

            #region 偵測 vcode 如果是空值, 使用帶入參數判斷是哪個來源 Operator
            //偵測 vcode 如果是空值, 使用帶入參數判斷是哪個來源 Operator
            if (vcode.Length <= 0)
            {
                if (usertoken.Length > 0 && sessiontoken.Length > 0 && licenseeid.Length > 0 && gameid.Length > 0 && configurationid.Length > 0 && language.Length > 0)
                {
                    _vcode = "fishking";
                }
                else if (usertoken.Length > 0 && gameid.Length > 0 && language.Length > 0)
                {
                    _vcode = "audere";
                }
            }
            else
            {
                _vcode = vcode;
            }
            #endregion

            var _vendor_defaultresponse = await _vendorService.GetVendor(_response, _model_pubsub, _vcode);
            var _vendor = _vendor_defaultresponse.result;

            if (_vendor == null)
            {
                _response.code = _vendor_defaultresponse.code;
                _response.status = _vendor_defaultresponse.status;
            }
            else
            {
                var _maintenance_defaultresponse = await _vendorService.GetMaintenance(_response, _model_pubsub, _vendor.Id);
                var _maintenance = _maintenance_defaultresponse.result;
                if (_maintenance == null)
                {
                    _response.code = _maintenance_defaultresponse.code;
                    _response.status = _maintenance_defaultresponse.status;
                    _response.result = null;
                }
                else
                {
                    _response.code = 0;
                    _response.status = "Successful";
                    _response.result = _maintenance;
                }
            }

            return _response;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="vendorid"></param>
        /// <param name="vcode"></param>
        /// <returns></returns>
        //[HttpPost, Route("Test")]
        //public Model.VendorSeamlessImplementResponse Test(string vendorid, string vcode)
        //{
        //    var res = Data.MySQL.Get_VendorSeamless_Implement(vendorid, vcode);
        //    return res;
        //}
    }
}
