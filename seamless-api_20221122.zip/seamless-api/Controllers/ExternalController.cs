﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Routing;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
//using Newtonsoft.Json;
using Prometheus;
using Seamless.Core.API.Data;
using Seamless.Core.API.Interfaces;
using Seamless.Core.API.Utility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;

/// <summary>
/// 
/// </summary>
namespace Seamless.Core.API.Controllers
{
    /// <summary>
    /// 
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class ExternalController : ControllerBase
    {
        /// <summary>
        /// 
        /// </summary>
        private readonly Models.DB_ManufacturerCMS.ManufacturerCMSContext _manufacturercmscontext = new();
        private readonly Models.DB_Membership.MembershipContext _membershipcontext = new();
        #region Interfaces

        /// <summary>
        /// 
        /// </summary>
        private readonly IHttpContextAccessor _httpContextAccessor;

        /// <summary>
        /// 
        /// </summary>
        private readonly IGameService _gameService;

        /// <summary>
        /// 
        /// </summary>
        private readonly IOperatorService _operatorService;

        /// <summary>
        /// 
        /// </summary>
        private readonly IVendorService _vendorService;

        /// <summary>
        /// 
        /// </summary>
        private readonly ILogger<ExternalController> _logger;

        /// <summary>
        /// 
        /// </summary>
        private readonly IHttpClientFactory _httpClientFactory;

        /// <summary>
        /// 
        /// </summary>
        private readonly IConfiguration _configuration;

        /// <summary>
        /// 
        /// </summary>
        private readonly ICacheService _cacheService;

        /// <summary>
        /// 
        /// </summary>
        private readonly IPubSubService _pubsubService;

        /// <summary>
        /// 
        /// </summary>
        /// <value></value>
        private static readonly Histogram HttpPartnerHistogram = Metrics
        .CreateHistogram("http_request_duration_seconds_partner", "request duration in seconds",
            new HistogramConfiguration
            {
                Buckets = Histogram.ExponentialBuckets(0.001, 2, 16),
                LabelNames = new[] { "method", "controller", "action", "partner_code", "partner_host", "partner_uri", "partner_method" }
            });

        #endregion

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        private readonly MySQL _mysql = new();

        /// <summary>
        /// 
        /// </summary>
        /// <param name="httpContextAccessor"></param>
        /// <param name="operatorService"></param>
        /// <param name="vendorService"></param>
        /// <param name="gameService"></param>
        /// <param name="logger"></param>
        /// <param name="httpClientFactory"></param>
        /// <param name="configuration"></param>
        /// <param name="cacheService"></param>
        /// <param name="mysql"></param>
        /// <param name="pubsubService"></param>
        public ExternalController(IHttpContextAccessor httpContextAccessor, IOperatorService operatorService, IVendorService vendorService, IGameService gameService, ILogger<ExternalController> logger, IHttpClientFactory httpClientFactory, IConfiguration configuration, ICacheService cacheService, MySQL mysql, IPubSubService pubsubService)
        {
            _httpContextAccessor = httpContextAccessor;
            _gameService = gameService;
            _operatorService = operatorService;
            _vendorService = vendorService;
            _logger = logger;
            _httpClientFactory = httpClientFactory;
            _configuration = configuration;
            _cacheService = cacheService;
            _mysql = mysql;
            _pubsubService = pubsubService;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="request"></param>
        /// <param name="response"></param>
        /// <returns></returns>
        private string[] GetAllLabelValues(HttpRequestMessage request, HttpResponseMessage response)
        {
            var RouteData = HttpContext.GetRouteData()?.Values;
            var Controller = RouteData?.GetValueOrDefault("controller", string.Empty) as string ?? string.Empty;
            var Action = RouteData?.GetValueOrDefault("action", string.Empty) as string ?? string.Empty;
            var Method = HttpContext.Request.Method.ToString();

            var PartnerCode = ((int)response.StatusCode).ToString();
            var PartnerHost = request.RequestUri?.Host ?? string.Empty;
            var PartnerPath = request.RequestUri?.AbsolutePath ?? string.Empty; ;
            var PartnerMethod = request.Method.ToString();

            return new[] { Method, Controller, Action, PartnerCode, PartnerHost, PartnerPath, PartnerMethod };
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="response"></param>
        /// <param name="key"></param>
        /// <returns></returns>
        private double GetElapsedTimeFromHeader(HttpResponseMessage response, string key = "X-Partner-ElapsedTime")
        {
            //var elapsedTime = response.Headers.GetValues(key).FirstOrDefault();
            var elapsedTime = DateTime.UtcNow.ToString("yyyy-MM-dd HH:mm:ss.fff");
            if (string.IsNullOrEmpty(elapsedTime))
                elapsedTime = "0";
            else
            {
                DateTime current = DateTime.UtcNow;
                DateTime before = DateTime.Parse(elapsedTime);
                elapsedTime = (current - before).TotalSeconds.ToString();
            }

            return Convert.ToDouble(elapsedTime);
        }

        #region Table
        /// <summary>
        /// 客製化扣點 - 相關參數各自支援之平台商端, 可參考 API 文件說明
        /// </summary>
        /// <param name="_model">Model.Vendor.DeductionRequest</param>
        /// <returns></returns>
        [HttpPost, Route("Deduction")]
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public async Task<Model.DefaultResponse> Deduction(Model.Vendor.DeductionRequest _model)
        {
            Model.DefaultResponse _response = new();
            Model.PubSubRequest _model_pubsub = new();
            _response.type = "Deduction";
            //設定記錄Pub/Sub相關參數
            _model_pubsub.merchantid = _model.data.merchantid;
            _model_pubsub.vcode = _model.data.vcode;
            _model_pubsub.gameid = _model.data.gameid;
            _model_pubsub.usertoken = _model.data.usertoken;
            _model_pubsub.sessiontoken = _model.data.sessiontoken;
            _model_pubsub.roundid = _model.data.tableid;
            _model_pubsub.transactionid = _model.data.transactionid;
            _model_pubsub.userid = _model.data.userid;
            _model_pubsub.currency = _model.data.currency;
            _model_pubsub.amount = _model.data.amount.ToString();
            _model_pubsub.bettime = _model.data.time;
            _model_pubsub.transactionid = _model.data.transactionid;
            _model_pubsub.detail = _model.data.detail;

            try
            {
                #region 驗證相關欄位並取得相關Table資料
                //設定驗證欄位
                var _verifyfields = "merchantid,vcode,usertoken";
                //取得相關Table資料(資料已Redis)
                var _vendordataresponse = await _vendorService.GetVendorData<Model.Vendor.DeductionRequest, Model.Vendor.DeductionRequestParams>(_model, _model.data, _verifyfields, _response, _model_pubsub);
                _response = _vendordataresponse.DefaultResponse;
                if (_response.code != 0) return _response;
                #endregion

                //取得相關Table資料
                var _vendoroperatoraccountmapping = _vendordataresponse.Redis_VendorOperatorAccountMapping;
                var _operatorimplementinfo = _vendordataresponse.Redis_OperatorImplementInfo;
                var _operatorimplementinfosecretkey = _operatorimplementinfo.SecretKey;
                var _apicode = _vendordataresponse.ApiCode;
                string _uri = _operatorimplementinfo.UrlDeduction;
                string _newgameid = _vendordataresponse.NewGameID;
                _model_pubsub.url = _uri;

                switch (_vendoroperatoraccountmapping.TestMode)
                {
                    case 0:
                        Services.External.CallBackService _callback = new Services.External.CallBackService(_httpContextAccessor);

                        if (_apicode == "08online")
                        {
                            var _uid = StringHelper.makeTransactionId(16);
                            var _currenttime = DateTime.Now.ToString("yyyy/MM/dd HH:MM:ss");
                            var _bettimenow = (string.IsNullOrEmpty(_model.data.time)) ? _currenttime : _model.data.time;

                            var _formdata = new
                            {
                                reqid = _uid,
                                token = _model.data.usertoken,
                                sessiontoken = _model.data.sessiontoken,
                                currency = _model.data.currency,
                                gameid = _newgameid,
                                tableuuid = _model.data.tableuuid,
                                tableid = _model.data.tableid,
                                transactionid = _model.data.transactionid,
                                time = _bettimenow,
                                amount = _model.data.amount,
                                detail = _model.data.detail,
                                type = _model.data.type
                            };
                            var _formhash = Utility.Encryptions.MD5_Generate(JsonSerializer.Serialize(_formdata) + _operatorimplementinfosecretkey);

                            var _request = new { data = _formdata, hash = _formhash };

                            #region 使用HttpClient呼叫API
                            var starttime = DateTime.Now;
                            var _data = await _callback.ExecuteAsync(_request, HttpMethod.Post, _uri, null, null);
                            //var _data = _callback.Execute(_request, HttpMethod.Post, _uri, null, null);
                            var endtime = DateTime.Now;
                            var apiresponsetime = (endtime - starttime).TotalMilliseconds / 1000;
                            #endregion

                            //取得API回傳result內各屬性的值
                            var dynamicObject = Newtonsoft.Json.JsonConvert.DeserializeObject<dynamic>(_data.result)!;
                            var _bodycode = dynamicObject.code.Value;
                            var _bodymessage = dynamicObject.message.Value;
                            var _bodyresult = Newtonsoft.Json.JsonConvert.SerializeObject(dynamicObject.result);

                            if (_data.code != 200)
                            {
                                _response.code = _data.code;
                                _response.status = $"Failure - statusCode not 200({_data.code.ToString()})";

                                //Todo:失敗則記錄普羅米修斯

                                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                                _model_pubsub.type = $"{_response.type} End [{_apicode}]CallBackAPI.ExecuteAsync";
                                _model_pubsub.url = _uri;
                                _model_pubsub.responsedata = _response;
                                await _pubsubService.PublishMessagesAsync(_model_pubsub);
                            }
                            if (_response.code != 0) return _response;

                            if (_bodyresult == null)
                            {
                                _response.code = _data.code;
                                _response.status = "Failure - body is null";

                                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                                _model_pubsub.type = $"{_response.type} End [{_apicode}]CallBackAPI.ExecuteAsync";
                                _model_pubsub.url = _uri;
                                _model_pubsub.responsedata = _response;
                                await _pubsubService.PublishMessagesAsync(_model_pubsub);
                            }
                            if (_response.code != 0) return _response;

                            //Todo:成功記錄普羅米修斯

                            _response.code = 0;
                            _response.status = "Successful";
                            if (_bodycode != 0)
                            {
                                _response.code = (int)_bodycode;
                                _response.status = _bodymessage;
                            }
                            _response.result = JsonSerializer.Deserialize<dynamic>(_bodyresult);
                        }
                        else if (_apicode == "aceonline")
                        {
                            string[] headers = { "x-api-key" };
                            string[] values = { "e495964cb27748859d1060f53a2d3ba2" };

                            dynamic _meta = new { tableid = _model.data.tableid, tableuuid = _model.data.tableuuid, detail = _model.data.detail, time = _model.data.time };
                            dynamic _operations = new { operationType = "WagerWithdrawOperation", withdraw = _model.data.amount, @event = _model.data.type, meta = _meta };

                            var _request = new
                            {
                                wagerId = _model.data.transactionid,
                                transactionId = $"DEDUCTION-{_model.data.tableuuid}",
                                userId = _model.data.userid,
                                gameId = _newgameid,
                                accountToken = _model.data.usertoken,
                                operations = _operations
                            };

                            #region 使用HttpClient呼叫API
                            var starttime = DateTime.Now;
                            var _data = await _callback.ExecuteAsync(_request, HttpMethod.Post, _uri, headers, values);
                            //var _data = _callback.Execute(_request, HttpMethod.Post, _uri, headers, values);
                            var endtime = DateTime.Now;
                            var apiresponsetime = (endtime - starttime).TotalMilliseconds / 1000;
                            #endregion

                            //取得API回傳result內各屬性的值
                            var dynamicObject = Newtonsoft.Json.JsonConvert.DeserializeObject<dynamic>(_data.result)!;
                            var _bodystatuscode = dynamicObject.statusCode.Value;
                            var _bodybalancescurrencycode = dynamicObject.balances[0].currencyCode.Value;
                            var _bodybalancesamount = dynamicObject.balances[0].amount.Value;

                            if (_data.code != 200)
                            {
                                _response.code = _data.code;
                                _response.status = $"Failure - statusCode not 200({_data.code.ToString()})";

                                //Todo:失敗則記錄普羅米修斯

                                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                                _model_pubsub.type = $"{_response.type} End [{_apicode}]CallBackAPI.ExecuteAsync";
                                _model_pubsub.url = _uri;
                                _model_pubsub.responsedata = _response;
                                await _pubsubService.PublishMessagesAsync(_model_pubsub);
                            }
                            if (_response.code != 0) return _response;

                            if (_bodystatuscode == "RS_ERROR_SYSTEM_IN_MAINTAIN")
                            {
                                _response.code = 9998;
                            }
                            else if (_bodystatuscode == "RS_ERROR_INVALID_USER_TOKEN" || _bodystatuscode == "RS_ERROR_INVALID_ACCOUNT_TOKEN")
                            {
                                _response.code = 9997;
                            }
                            if (_response.code != 0)
                            {
                                _response.status = $"Failure - body statusCode:({_bodystatuscode})";

                                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                                _model_pubsub.type = $"{_response.type} End [{_apicode}]CallBackAPI.ExecuteAsync";
                                _model_pubsub.url = _uri;
                                _model_pubsub.responsedata = _response;
                                await _pubsubService.PublishMessagesAsync(_model_pubsub);

                                return _response;
                            }

                            //Todo:成功記錄普羅米修斯

                            _response.code = 0;
                            _response.status = "Successful";
                            _response.result = JsonSerializer.Deserialize<dynamic>(_data.result);
                            _response.additional = new { currency = _bodybalancescurrencycode, balance = _bodybalancesamount };
                        }
                        else if (_apicode == "vm")
                        {
                            _response.code = 9999;
                            _response.status = "This Operator does not support this function";

                            //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                            _model_pubsub.type = $"{_response.type} End [{_apicode}]CallBackAPI.ExecuteAsync";
                            _model_pubsub.url = _uri;
                            _model_pubsub.responsedata = _response;
                            await _pubsubService.PublishMessagesAsync(_model_pubsub);

                            return _response;
                        }
                        else
                        {
                            _response.code = 0;
                            _response.status = "Successful - external";
                        }

                        break;
                    case 1:
                        //Node.js版本無TestMode
                        _response.code = 0;
                        _response.status = "Successful - test mode";
                        break;
                }

                //記錄LOG:API 呼叫記錄寫入 Pub/Sub(End)
                #region 記錄LOG:API 呼叫記錄寫入 Pub/Sub(End)
                _model_pubsub.type = $"{_response.type} End";
                _model_pubsub.url = _uri;
                _model_pubsub.responsedata = _response;
                await _pubsubService.PublishMessagesAsync(_model_pubsub);
                #endregion
            }
            catch (Exception ex)
            {
                _response.code = 9999;
                _response.status = ex.Message;

                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                _model_pubsub.type = $"{_response.type} Catch Exception";
                _model_pubsub.responsedata = _response;
                await _pubsubService.PublishMessagesAsync(_model_pubsub);
            }

            return _response;
        }

        /// <summary>
        /// 客製化扣點返款
        /// </summary>
        /// <param name="_model">Model.Vendor.DeductionRefundRequest</param>
        /// <returns></returns>
        [HttpPost, Route("DeductionRefund")]
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public async Task<Model.DefaultResponse> DeductionRefund(Model.Vendor.DeductionRefundRequest _model)
        {
            Model.DefaultResponse _response = new();
            Model.PubSubRequest _model_pubsub = new();
            _response.type = "DeductionRefund";
            //設定記錄Pub/Sub相關參數
            _model_pubsub.merchantid = _model.data.merchantid;
            _model_pubsub.vcode = _model.data.vcode;
            _model_pubsub.gameid = _model.data.gameid;
            _model_pubsub.usertoken = _model.data.usertoken;
            _model_pubsub.sessiontoken = _model.data.sessiontoken;
            _model_pubsub.roundid = _model.data.tableid;
            _model_pubsub.transactionid = _model.data.transactionid;
            _model_pubsub.userid = _model.data.userid;
            _model_pubsub.amount = _model.data.amount.ToString();
            _model_pubsub.bettime = _model.data.time;
            _model_pubsub.transactionid = _model.data.transactionid;

            try
            {
                #region 驗證相關欄位並取得相關Table資料
                //設定驗證欄位
                var _verifyfields = "merchantid,vcode,usertoken";
                //取得相關Table資料(資料已Redis)
                var _vendordataresponse = await _vendorService.GetVendorData<Model.Vendor.DeductionRefundRequest, Model.Vendor.DeductionRefundRequestParams>(_model, _model.data, _verifyfields, _response, _model_pubsub);
                _response = _vendordataresponse.DefaultResponse;
                if (_response.code != 0) return _response;
                #endregion

                //取得相關Table資料
                var _vendoroperatoraccountmapping = _vendordataresponse.Redis_VendorOperatorAccountMapping;
                var _operatorimplementinfo = _vendordataresponse.Redis_OperatorImplementInfo;
                var _operatorimplementinfosecretkey = _operatorimplementinfo.SecretKey;
                var _apicode = _vendordataresponse.ApiCode;
                string _uri = _operatorimplementinfo.UrlDeductionRefund;
                string _newgameid = _vendordataresponse.NewGameID;
                _model_pubsub.url = _uri;

                switch (_vendoroperatoraccountmapping.TestMode)
                {
                    case 0:
                        Services.External.CallBackService _callback = new Services.External.CallBackService(_httpContextAccessor);

                        if (_apicode == "08online")
                        {
                            var _uid = StringHelper.makeTransactionId(16);
                            var _currenttime = DateTime.Now.ToString("yyyy/MM/dd HH:MM:ss");
                            var _bettimenow = (string.IsNullOrEmpty(_model.data.time)) ? _currenttime : _model.data.time;

                            var _formdata = new
                            {
                                reqid = _uid,
                                token = _model.data.usertoken,
                                sessiontoken = _model.data.sessiontoken,
                                gameid = _newgameid,
                                transactionid = _model.data.transactionid,
                                tableuuid = _model.data.tableuuid,
                                tableid = _model.data.tableid,
                                time = _bettimenow,
                                amount = _model.data.amount
                            };
                            var _formhash = Utility.Encryptions.MD5_Generate(JsonSerializer.Serialize(_formdata) + _operatorimplementinfosecretkey);

                            var _request = new { data = _formdata, hash = _formhash };

                            #region 使用HttpClient呼叫API
                            var starttime = DateTime.Now;
                            var _data = await _callback.ExecuteAsync(_request, HttpMethod.Post, _uri, null, null);
                            //var _data = _callback.Execute(_request, HttpMethod.Post, _uri, null, null);
                            var endtime = DateTime.Now;
                            var apiresponsetime = (endtime - starttime).TotalMilliseconds / 1000;
                            #endregion

                            //取得API回傳result內各屬性的值
                            var dynamicObject = Newtonsoft.Json.JsonConvert.DeserializeObject<dynamic>(_data.result)!;
                            var _bodycode = dynamicObject.code.Value;
                            var _bodymessage = dynamicObject.message.Value;
                            var _bodyresult = Newtonsoft.Json.JsonConvert.SerializeObject(dynamicObject.result);

                            if (_data.code != 200)
                            {
                                _response.code = _data.code;
                                _response.status = $"Failure - statusCode not 200({_data.code.ToString()})";

                                //Todo:失敗則記錄普羅米修斯

                                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                                _model_pubsub.type = $"{_response.type} End [{_apicode}]CallBackAPI.ExecuteAsync";
                                _model_pubsub.url = _uri;
                                _model_pubsub.responsedata = _response;
                                await _pubsubService.PublishMessagesAsync(_model_pubsub);
                            }
                            if (_response.code != 0) return _response;

                            if (_bodyresult == null)
                            {
                                _response.code = _data.code;
                                _response.status = "Failure - body is null";

                                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                                _model_pubsub.type = $"{_response.type} End [{_apicode}]CallBackAPI.ExecuteAsync";
                                _model_pubsub.url = _uri;
                                _model_pubsub.responsedata = _response;
                                await _pubsubService.PublishMessagesAsync(_model_pubsub);
                            }
                            if (_response.code != 0) return _response;

                            //Todo:成功記錄普羅米修斯

                            _response.code = 0;
                            _response.status = "Successful";
                            if (_bodycode != 0)
                            {
                                _response.code = (int)_bodycode;
                                _response.status = _bodymessage;
                            }
                            _response.result = JsonSerializer.Deserialize<dynamic>(_bodyresult);
                        }
                        else if (_apicode == "aceonline")
                        {
                            string[] headers = { "x-api-key" };
                            string[] values = { "e495964cb27748859d1060f53a2d3ba2" };

                            dynamic _operations = new { operationType = "WagerLifecycleOperation", action = "cancel" };

                            var _request = new
                            {
                                wagerId = _model.data.transactionid,
                                transactionId = $"DEDUCTIONREFUND-{_model.data.tableuuid}",
                                userId = _model.data.userid,
                                gameId = _newgameid,
                                accountToken = _model.data.usertoken,
                                operations = _operations
                            };

                            #region 使用HttpClient呼叫API
                            var starttime = DateTime.Now;
                            var _data = await _callback.ExecuteAsync(_request, HttpMethod.Post, _uri, headers, values);
                            //var _data = _callback.Execute(_request, HttpMethod.Post, _uri, headers, values);
                            var endtime = DateTime.Now;
                            var apiresponsetime = (endtime - starttime).TotalMilliseconds / 1000;
                            #endregion

                            //取得API回傳result內各屬性的值
                            var dynamicObject = Newtonsoft.Json.JsonConvert.DeserializeObject<dynamic>(_data.result)!;
                            var _bodystatuscode = dynamicObject.statusCode.Value;
                            var _bodybalancescurrencycode = dynamicObject.balances[0].currencyCode.Value;
                            var _bodybalancesamount = dynamicObject.balances[0].amount.Value;

                            if (_data.code != 200)
                            {
                                _response.code = _data.code;
                                _response.status = $"Failure - statusCode not 200({_data.code.ToString()})";

                                //Todo:失敗則記錄普羅米修斯

                                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                                _model_pubsub.type = $"{_response.type} End [{_apicode}]CallBackAPI.ExecuteAsync";
                                _model_pubsub.url = _uri;
                                _model_pubsub.responsedata = _response;
                                await _pubsubService.PublishMessagesAsync(_model_pubsub);
                            }
                            if (_response.code != 0) return _response;

                            if (_bodystatuscode == "RS_ERROR_SYSTEM_IN_MAINTAIN")
                            {
                                _response.code = 9998;
                            }
                            else if (_bodystatuscode == "RS_ERROR_INVALID_USER_TOKEN" || _bodystatuscode == "RS_ERROR_INVALID_ACCOUNT_TOKEN")
                            {
                                _response.code = 9997;
                            }
                            if (_response.code != 0)
                            {
                                _response.status = $"Failure - body statusCode:({_bodystatuscode})";

                                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                                _model_pubsub.type = $"{_response.type} End [{_apicode}]CallBackAPI.ExecuteAsync";
                                _model_pubsub.url = _uri;
                                _model_pubsub.responsedata = _response;
                                await _pubsubService.PublishMessagesAsync(_model_pubsub);

                                return _response;
                            }

                            //Todo:成功記錄普羅米修斯

                            _response.code = 0;
                            _response.status = "Successful";
                            _response.result = JsonSerializer.Deserialize<dynamic>(_data.result);
                            _response.additional = new { currency = _bodybalancescurrencycode, balance = _bodybalancesamount };
                        }
                        else if (_apicode == "vm")
                        {
                            _response.code = 9999;
                            _response.status = "This Operator does not support this function";

                            //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                            _model_pubsub.type = $"{_response.type} End [{_apicode}]CallBackAPI.ExecuteAsync";
                            _model_pubsub.url = _uri;
                            _model_pubsub.responsedata = _response;
                            await _pubsubService.PublishMessagesAsync(_model_pubsub);

                            return _response;
                        }
                        else
                        {
                            _response.code = 0;
                            _response.status = "Successful - external";
                        }

                        break;
                    case 1:
                        //Node.js版本無TestMode
                        _response.code = 0;
                        _response.status = "Successful - test mode";
                        break;
                }

                //記錄LOG:API 呼叫記錄寫入 Pub/Sub(End)
                #region 記錄LOG:API 呼叫記錄寫入 Pub/Sub(End)
                _model_pubsub.type = $"{_response.type} End";
                _model_pubsub.url = _uri;
                _model_pubsub.responsedata = _response;
                await _pubsubService.PublishMessagesAsync(_model_pubsub);
                #endregion
            }
            catch (Exception ex)
            {
                _response.code = 9999;
                _response.status = ex.Message;

                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                _model_pubsub.type = $"{_response.type} Catch Exception";
                _model_pubsub.responsedata = _response;
                await _pubsubService.PublishMessagesAsync(_model_pubsub);
            }

            return _response;
        }

        /// <summary>
        /// 客製化扣點結算
        /// </summary>
        /// <param name="_model">Model.Vendor.DeductionSettleRequest</param>
        /// <returns></returns>
        [HttpPost, Route("DeductionSettle")]
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public async Task<Model.DefaultResponse> DeductionSettle(Model.Vendor.DeductionSettleRequest _model)
        {
            Model.DefaultResponse _response = new();
            Model.PubSubRequest _model_pubsub = new();
            _response.type = "DeductionSettle";
            //設定記錄Pub/Sub相關參數
            _model_pubsub.merchantid = _model.data.merchantid;
            _model_pubsub.vcode = _model.data.vcode;
            _model_pubsub.gameid = _model.data.gameid;
            _model_pubsub.usertoken = _model.data.usertoken;
            _model_pubsub.sessiontoken = _model.data.sessiontoken;
            _model_pubsub.roundid = _model.data.tableid;
            _model_pubsub.transactionid = _model.data.transactionid;
            _model_pubsub.userid = _model.data.userid;
            _model_pubsub.currency = _model.data.currency;
            _model_pubsub.amount = _model.data.amount.ToString();
            _model_pubsub.bettime = _model.data.time;
            _model_pubsub.transactionid = _model.data.transactionid;
            _model_pubsub.detail = _model.data.detail;

            try
            {
                #region 驗證相關欄位並取得相關Table資料
                //設定驗證欄位
                var _verifyfields = "merchantid,vcode,usertoken";
                //取得相關Table資料(資料已Redis)
                var _vendordataresponse = await _vendorService.GetVendorData<Model.Vendor.DeductionSettleRequest, Model.Vendor.DeductionSettleRequestParams>(_model, _model.data, _verifyfields, _response, _model_pubsub);
                _response = _vendordataresponse.DefaultResponse;
                if (_response.code != 0) return _response;
                #endregion

                //取得相關Table資料
                var _vendoroperatoraccountmapping = _vendordataresponse.Redis_VendorOperatorAccountMapping;
                var _operatorimplementinfo = _vendordataresponse.Redis_OperatorImplementInfo;
                var _operatorimplementinfosecretkey = _operatorimplementinfo.SecretKey;
                var _apicode = _vendordataresponse.ApiCode;
                string _uri = _operatorimplementinfo.UrlDeductionSettle;
                string _newgameid = _vendordataresponse.NewGameID;
                _model_pubsub.url = _uri;

                switch (_vendoroperatoraccountmapping.TestMode)
                {
                    case 0:
                        Services.External.CallBackService _callback = new Services.External.CallBackService(_httpContextAccessor);

                        if (_apicode == "08online")
                        {
                            var _uid = StringHelper.makeTransactionId(16);
                            var _currenttime = DateTime.Now.ToString("yyyy/MM/dd HH:MM:ss");
                            var _bettimenow = (string.IsNullOrEmpty(_model.data.time)) ? _currenttime : _model.data.time;

                            var _formdata = new
                            {
                                reqid = _uid,
                                token = _model.data.usertoken,
                                sessiontoken = _model.data.sessiontoken,
                                currency = _model.data.currency,
                                gameid = _newgameid,
                                tableuuid = _model.data.tableuuid,
                                tableid = _model.data.tableid,
                                transactionid = _model.data.transactionid,
                                time = _bettimenow,
                                amount = _model.data.amount,
                                detail = _model.data.detail,
                                type = _model.data.type,
                                end = true
                            };
                            var _formhash = Utility.Encryptions.MD5_Generate(JsonSerializer.Serialize(_formdata) + _operatorimplementinfosecretkey);

                            var _request = new { data = _formdata, hash = _formhash };

                            #region 使用HttpClient呼叫API
                            var starttime = DateTime.Now;
                            var _data = await _callback.ExecuteAsync(_request, HttpMethod.Post, _uri, null, null);
                            //var _data = _callback.Execute(_request, HttpMethod.Post, _uri, null, null);
                            var endtime = DateTime.Now;
                            var apiresponsetime = (endtime - starttime).TotalMilliseconds / 1000;
                            #endregion

                            //取得API回傳result內各屬性的值
                            var dynamicObject = Newtonsoft.Json.JsonConvert.DeserializeObject<dynamic>(_data.result)!;
                            var _bodycode = dynamicObject.code.Value;
                            var _bodymessage = dynamicObject.message.Value;
                            var _bodyresult = Newtonsoft.Json.JsonConvert.SerializeObject(dynamicObject.result);

                            if (_data.code != 200)
                            {
                                _response.code = _data.code;
                                _response.status = $"Failure - statusCode not 200({_data.code.ToString()})";

                                //Todo:失敗則記錄普羅米修斯

                                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                                _model_pubsub.type = $"{_response.type} End [{_apicode}]CallBackAPI.ExecuteAsync";
                                _model_pubsub.url = _uri;
                                _model_pubsub.responsedata = _response;
                                await _pubsubService.PublishMessagesAsync(_model_pubsub);
                            }
                            if (_response.code != 0) return _response;

                            if (_bodyresult == null)
                            {
                                _response.code = _data.code;
                                _response.status = "Failure - body is null";

                                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                                _model_pubsub.type = $"{_response.type} End [{_apicode}]CallBackAPI.ExecuteAsync";
                                _model_pubsub.url = _uri;
                                _model_pubsub.responsedata = _response;
                                await _pubsubService.PublishMessagesAsync(_model_pubsub);
                            }
                            if (_response.code != 0) return _response;

                            //Todo:成功記錄普羅米修斯

                            _response.code = 0;
                            _response.status = "Successful";
                            if (_bodycode != 0)
                            {
                                _response.code = (int)_bodycode;
                                _response.status = _bodymessage;
                            }
                            _response.result = JsonSerializer.Deserialize<dynamic>(_bodyresult);
                        }
                        else if (_apicode == "aceonline")
                        {
                            string[] headers = { "x-api-key" };
                            string[] values = { "e495964cb27748859d1060f53a2d3ba2" };

                            dynamic _meta = new { tableid = _model.data.tableid, tableuuid = _model.data.tableuuid, detail = _model.data.detail, time = _model.data.time };
                            dynamic _operations = new { operationType = "WagerLifecycleOperation", confirm = "confirm" };

                            var _request = new
                            {
                                wagerId = _model.data.transactionid,
                                transactionId = $"DEDUCTIONSETTLE-{_model.data.tableuuid}",
                                userId = _model.data.userid,
                                gameId = _newgameid,
                                accountToken = _model.data.usertoken,
                                operations = _operations
                            };

                            #region 使用HttpClient呼叫API
                            var starttime = DateTime.Now;
                            var _data = await _callback.ExecuteAsync(_request, HttpMethod.Post, _uri, headers, values);
                            //var _data = _callback.Execute(_request, HttpMethod.Post, _uri, headers, values);
                            var endtime = DateTime.Now;
                            var apiresponsetime = (endtime - starttime).TotalMilliseconds / 1000;
                            #endregion

                            //取得API回傳result內各屬性的值
                            var dynamicObject = Newtonsoft.Json.JsonConvert.DeserializeObject<dynamic>(_data.result)!;
                            var _bodystatuscode = dynamicObject.statusCode.Value;
                            var _bodybalancescurrencycode = dynamicObject.balances[0].currencyCode.Value;
                            var _bodybalancesamount = dynamicObject.balances[0].amount.Value;

                            if (_data.code != 200)
                            {
                                _response.code = _data.code;
                                _response.status = $"Failure - statusCode not 200({_data.code.ToString()})";

                                //Todo:失敗則記錄普羅米修斯

                                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                                _model_pubsub.type = $"{_response.type} End [{_apicode}]CallBackAPI.ExecuteAsync";
                                _model_pubsub.url = _uri;
                                _model_pubsub.responsedata = _response;
                                await _pubsubService.PublishMessagesAsync(_model_pubsub);
                            }
                            if (_response.code != 0) return _response;

                            if (_bodystatuscode == "RS_ERROR_SYSTEM_IN_MAINTAIN")
                            {
                                _response.code = 9998;
                            }
                            else if (_bodystatuscode == "RS_ERROR_INVALID_USER_TOKEN" || _bodystatuscode == "RS_ERROR_INVALID_ACCOUNT_TOKEN")
                            {
                                _response.code = 9997;
                            }
                            if (_response.code != 0)
                            {
                                _response.status = $"Failure - body statusCode:({_bodystatuscode})";

                                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                                _model_pubsub.type = $"{_response.type} End [{_apicode}]CallBackAPI.ExecuteAsync";
                                _model_pubsub.url = _uri;
                                _model_pubsub.responsedata = _response;
                                await _pubsubService.PublishMessagesAsync(_model_pubsub);

                                return _response;
                            }

                            //Todo:成功記錄普羅米修斯

                            _response.code = 0;
                            _response.status = "Successful";
                            _response.result = JsonSerializer.Deserialize<dynamic>(_data.result);
                            _response.additional = new { currency = _bodybalancescurrencycode, balance = _bodybalancesamount };
                        }
                        else if (_apicode == "vm")
                        {
                            _response.code = 9999;
                            _response.status = "This Operator does not support this function";

                            //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                            _model_pubsub.type = $"{_response.type} End [{_apicode}]CallBackAPI.ExecuteAsync";
                            _model_pubsub.url = _uri;
                            _model_pubsub.responsedata = _response;
                            await _pubsubService.PublishMessagesAsync(_model_pubsub);

                            return _response;
                        }
                        else
                        {
                            _response.code = 0;
                            _response.status = "Successful - external";
                        }

                        break;
                    case 1:
                        //Node.js無TestMode
                        _response.code = 0;
                        _response.status = "Successful - test mode";
                        break;
                }

                //記錄LOG:API 呼叫記錄寫入 Pub/Sub(End)
                #region 記錄LOG:API 呼叫記錄寫入 Pub/Sub(End)
                _model_pubsub.type = $"{_response.type} End";
                _model_pubsub.url = _uri;
                _model_pubsub.responsedata = _response;
                await _pubsubService.PublishMessagesAsync(_model_pubsub);
                #endregion
            }
            catch (Exception ex)
            {
                _response.code = 9999;
                _response.status = ex.Message;

                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                _model_pubsub.type = $"{_response.type} Catch Exception";
                _model_pubsub.responsedata = _response;
                await _pubsubService.PublishMessagesAsync(_model_pubsub);
            }

            return _response;
        }

        #endregion

        #region Seamless        

        /// <summary>
        /// 建立測試 Token - 僅支援平台商端測試環境
        /// </summary>
        /// <param name="_model">Model.Vendor.CreateTokenRequest</param>
        [HttpPost, Route("CreateToken")]
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public async Task<Model.DefaultResponse> CreateToken(Model.Vendor.CreateTokenRequest _model)
        {
            Model.DefaultResponse _response = new();
            Model.PubSubRequest _model_pubsub = new();
            _response.type = "CreateToken";
            //設定記錄Pub/Sub相關參數
            _model_pubsub.merchantid = _model.data.merchantid;
            _model_pubsub.vcode = _model.data.vcode;
            _model_pubsub.gameid = _model.data.gameid;

            try
            {
                #region 驗證相關欄位並取得相關Table資料
                //設定驗證欄位
                var _verifyfields = "merchantid,vcode,gameid";
                //取得相關Table資料(資料已Redis)
                var _vendordataresponse = await _vendorService.GetVendorData<Model.Vendor.CreateTokenRequest, Model.Vendor.CreateTokenRequestParams>(_model, _model.data, _verifyfields, _response, _model_pubsub);
                _response = _vendordataresponse.DefaultResponse;
                if (_response.code != 0) return _response;
                #endregion

                //取得相關Table資料
                var _vendoroperatoraccountmapping = _vendordataresponse.Redis_VendorOperatorAccountMapping;
                var _operatorimplementinfo = _vendordataresponse.Redis_OperatorImplementInfo;
                var _apicode = _vendordataresponse.ApiCode;
                string _uri = _operatorimplementinfo.UrlCreateToken;
                string _newgameid = _vendordataresponse.NewGameID;
                _model_pubsub.url = _uri;

                switch (_vendoroperatoraccountmapping.TestMode)
                {
                    case 0:
                        Services.External.CallBackService _callback = new Services.External.CallBackService(_httpContextAccessor);

                        if (_apicode == "08online")
                        {
                            _uri = $"{_uri}?gameid={_newgameid}";

                            var _request = new { gameId = _newgameid };

                            #region 使用HttpClient呼叫API
                            var starttime = DateTime.Now;
                            var _data = await _callback.ExecuteAsync(_request, HttpMethod.Get, _uri, null, null);
                            //var _data = _callback.Execute(_request, HttpMethod.Get, _uri, null, null);
                            var endtime = DateTime.Now;
                            var apiresponsetime = (endtime - starttime).TotalMilliseconds / 1000;
                            #endregion

                            if (_data.code != 200)
                            {
                                _response.code = _data.code;
                                _response.status = $"Failure - statusCode not 200({_data.code.ToString()})";

                                //Todo:失敗則記錄普羅米修斯

                                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                                _model_pubsub.type = $"{_response.type} End [{_apicode}]CallBackAPI.ExecuteAsync";
                                _model_pubsub.url = _uri;
                                _model_pubsub.responsedata = _response;
                                await _pubsubService.PublishMessagesAsync(_model_pubsub);
                            }
                            if (_response.code != 0) return _response;

                            //Todo:成功則記錄普羅米修斯

                            _response.code = 0;
                            _response.status = "Successful";
                            _response.result = new { token = JsonSerializer.Deserialize<dynamic>(_data.result) };
                            _response.additional = new { token = JsonSerializer.Deserialize<dynamic>(_data.result) };
                        }
                        else if (_apicode == "aceonline")
                        {
                            string[] headers = { "x-api-key" };
                            string[] values = { "e495964cb27748859d1060f53a2d3ba2" };

                            var _request = new { gameId = _newgameid };

                            #region 使用HttpClient呼叫API
                            var starttime = DateTime.Now;
                            //var _data = await _callback.ExecuteAsync(_request, HttpMethod.Post, _uri, headers, values);
                            var _data = _callback.Execute(_request, HttpMethod.Post, _uri, headers, values);
                            var endtime = DateTime.Now;
                            var apiresponsetime = (endtime - starttime).TotalMilliseconds / 1000;
                            #endregion

                            //取得API回傳result內各屬性的值
                            var dynamicObject = Newtonsoft.Json.JsonConvert.DeserializeObject<dynamic>(_data.result)!;
                            var _bodystatuscode = dynamicObject.statusCode.Value;
                            var _bodyuserId = dynamicObject.userId.Value;
                            var _bodytoken = dynamicObject.token.Value;

                            if (_data.code != 200)
                            {
                                _response.code = _data.code;
                                _response.status = $"Failure - statusCode not 200({_bodystatuscode.ToString()})";

                                //Todo:失敗則記錄普羅米修斯

                                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                                _model_pubsub.type = $"{_response.type} End [{_apicode}]CallBackAPI.ExecuteAsync";
                                _model_pubsub.url = _uri;
                                _model_pubsub.responsedata = _response;
                                await _pubsubService.PublishMessagesAsync(_model_pubsub);
                            }
                            if (_response.code != 0) return _response;

                            if (_bodystatuscode == "RS_ERROR_SYSTEM_IN_MAINTAIN")
                            {
                                _response.code = 9998;
                            }
                            else if (_bodystatuscode == "RS_ERROR_INVALID_USER_TOKEN" || _bodystatuscode == "RS_ERROR_INVALID_ACCOUNT_TOKEN")
                            {
                                _response.code = 9997;
                            }
                            if (_response.code != 0)
                            {
                                _response.status = $"Failure - body statusCode:({_bodystatuscode})";

                                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                                _model_pubsub.type = $"{_response.type} End [{_apicode}]CallBackAPI.ExecuteAsync";
                                _model_pubsub.url = _uri;
                                _model_pubsub.responsedata = _response;
                                await _pubsubService.PublishMessagesAsync(_model_pubsub);

                                return _response;
                            }

                            //Todo:成功則記錄普羅米修斯

                            _response.code = 0;
                            _response.status = "Successful";
                            _response.result = JsonSerializer.Deserialize<dynamic>(_data.result);
                            _response.additional = new { userId = _bodyuserId, token = _bodytoken };
                        }
                        else
                        {
                            _response.code = 0;
                            _response.status = "Successful - external";
                        }

                        break;
                    case 1:
                        //呼叫SP
                        var _paras = new object[] { 1 };
                        var _sp_response = await _mysql.CallSP<Model.TestMode_CreateTokenAsyncResponse>("Membership.SP_MEMBERSHIP_TOKEN_AUTO_ADD", _paras);

                        _response.code = _sp_response.code;
                        _response.status = _sp_response.status;
                        _response.result = (_response.code == 0) ? _sp_response.result[0] : "";
                        break;
                }

                //記錄LOG:API 呼叫記錄寫入 Pub/Sub(End)
                #region 記錄LOG:API 呼叫記錄寫入 Pub/Sub(End)
                _model_pubsub.type = $"{_response.type} End";
                _model_pubsub.url = _uri;
                _model_pubsub.responsedata = _response;
                await _pubsubService.PublishMessagesAsync(_model_pubsub);
                #endregion
            }
            catch (Exception ex)
            {
                _response.code = 9999;
                _response.status = ex.Message;

                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                _model_pubsub.type = $"{_response.type} End Catch Exception";
                _model_pubsub.responsedata = _response;
                await _pubsubService.PublishMessagesAsync(_model_pubsub);
            }

            return _response;
        }

        /// <summary>
        /// 認證 User Token
        /// </summary>
        /// <param name="_model">Model.Vendor.AuthRequest</param>
        /// <returns></returns>
        [HttpPost, Route("AuthenticateToken")]
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public async Task<Model.DefaultResponse> Auth(Model.Vendor.AuthRequest _model)
        {
            Model.DefaultResponse _response = new();
            Model.PubSubRequest _model_pubsub = new();
            _response.type = "AuthToken";
            //設定記錄Pub/Sub相關參數
            _model_pubsub.merchantid = _model.data.merchantid;
            _model_pubsub.vcode = _model.data.vcode;
            _model_pubsub.usertoken = _model.data.usertoken;
            _model_pubsub.sessiontoken = _model.data.sessiontoken;

            try
            {
                #region 驗證相關欄位並取得相關Table資料
                //設定驗證欄位
                var _verifyfields = "merchantid,vcode,usertoken";
                //取得相關Table資料(資料已Redis)
                var _vendordataresponse = await _vendorService.GetVendorData<Model.Vendor.AuthRequest, Model.Vendor.AuthRequestParams>(_model, _model.data, _verifyfields, _response, _model_pubsub);
                _response = _vendordataresponse.DefaultResponse;
                if (_response.code != 0) return _response;
                #endregion

                //取得相關Table資料
                var _vendoroperatoraccountmapping = _vendordataresponse.Redis_VendorOperatorAccountMapping;
                var _operatorimplementinfo = _vendordataresponse.Redis_OperatorImplementInfo;
                var _apicode = _vendordataresponse.ApiCode;
                var _operatorimplementinfosecretkey = _operatorimplementinfo.SecretKey;
                var _idoperator = _operatorimplementinfo.IdOperator;
                var _idvendor = _vendoroperatoraccountmapping.IdVendor;
                string _uri = _operatorimplementinfo.UrlAuthenticateUser;
                string _newgameid = _vendordataresponse.NewGameID;
                _model_pubsub.url = _uri;

                switch (_vendoroperatoraccountmapping.TestMode)
                {
                    case 0:
                        Services.External.CallBackService _callback = new Services.External.CallBackService(_httpContextAccessor);

                        if (_apicode == "08online")
                        {
                            var _uid = StringHelper.makeTransactionId(16);
                            var _currenttime = DateTime.Now.ToString("yyyy/MM/dd HH:MM:ss");

                            var _formdata = new
                            {
                                reqid = _uid,
                                token = _model.data.usertoken
                            };
                            var _formhash = Utility.Encryptions.MD5_Generate(JsonSerializer.Serialize(_formdata) + _operatorimplementinfosecretkey);

                            var _request = new { data = _formdata, hash = _formhash };

                            #region 使用HttpClient呼叫API
                            var starttime = DateTime.Now;
                            var _data = await _callback.ExecuteAsync(_request, HttpMethod.Post, _uri, null, null);
                            //var _data = _callback.Execute(_request, HttpMethod.Get, _uri, null, null);
                            var endtime = DateTime.Now;
                            var apiresponsetime = (endtime - starttime).TotalMilliseconds / 1000;
                            #endregion

                            //取得API回傳result內各屬性的值
                            var dynamicObject = Newtonsoft.Json.JsonConvert.DeserializeObject<dynamic>(_data.result)!;
                            var _bodycode = dynamicObject.code.Value;
                            var _bodymessage = dynamicObject.message.Value;
                            var _bodyresultusername = dynamicObject.result.username.Value;
                            var _bodyresult = Newtonsoft.Json.JsonConvert.SerializeObject(dynamicObject.result);

                            if (_data.code != 200)
                            {
                                _response.code = _data.code;
                                _response.status = $"Failure - statusCode not 200({_data.code.ToString()})";

                                //Todo:失敗則記錄普羅米修斯

                                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                                _model_pubsub.type = $"{_response.type} End [{_apicode}]CallBackAPI.ExecuteAsync";
                                _model_pubsub.url = _uri;
                                _model_pubsub.responsedata = _response;
                                await _pubsubService.PublishMessagesAsync(_model_pubsub);
                            }
                            if (_response.code != 0) return _response;

                            //Todo:成功則記錄普羅米修斯

                            //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                            dynamic _dynamicrequest = new { idoperator = _idoperator, idvendor = _idvendor, username = _bodyresultusername };
                            await _pubsubService.PublishMessagesAsync(_dynamicrequest);

                            _response.code = 0;
                            _response.status = "Successful";
                            if (_bodycode != 0)
                            {
                                _response.code = (int)_bodycode;
                                _response.status = _bodymessage;
                            }
                            _response.result = JsonSerializer.Deserialize<dynamic>(_bodyresult);
                        }
                        else if (_apicode == "aceonline")
                        {
                            string[] headers = { "x-api-key" };
                            string[] values = { "e495964cb27748859d1060f53a2d3ba2" };

                            var _request = new { userToken = _model.data.usertoken };

                            #region 使用HttpClient呼叫API
                            var starttime = DateTime.Now;
                            //var _data = await _callback.ExecuteAsync(_request, HttpMethod.Post, _uri, headers, values);
                            var _data = _callback.Execute(_request, HttpMethod.Post, _uri, headers, values);
                            var endtime = DateTime.Now;
                            var apiresponsetime = (endtime - starttime).TotalMilliseconds / 1000;
                            #endregion

                            //取得API回傳result內各屬性的值
                            var dynamicObject = Newtonsoft.Json.JsonConvert.DeserializeObject<dynamic>(_data.result)!;
                            var _bodystatuscode = dynamicObject.statusCode.Value;
                            var _bodyuserId = dynamicObject.userId.Value;
                            var _bodybalancescurrencycode = dynamicObject.balances[0].currencyCode.Value;
                            var _bodybalancesamount = dynamicObject.balances[0].amount.Value;
                            var _bodycardtype = dynamicObject.vip.Value;

                            if (_data.code != 200)
                            {
                                _response.code = _data.code;
                                _response.status = $"Failure - statusCode not 200({_bodystatuscode.ToString()})";

                                //Todo:失敗則記錄普羅米修斯

                                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                                _model_pubsub.type = $"{_response.type} End [{_apicode}]CallBackAPI.ExecuteAsync";
                                _model_pubsub.url = _uri;
                                _model_pubsub.responsedata = _response;
                                await _pubsubService.PublishMessagesAsync(_model_pubsub);
                            }
                            if (_response.code != 0) return _response;

                            if (_bodystatuscode == "RS_ERROR_SYSTEM_IN_MAINTAIN")
                            {
                                _response.code = 9998;
                            }
                            else if (_bodystatuscode == "RS_ERROR_INVALID_USER_TOKEN" || _bodystatuscode == "RS_ERROR_INVALID_ACCOUNT_TOKEN")
                            {
                                _response.code = 9997;
                            }
                            if (_response.code != 0)
                            {
                                _response.status = $"Failure - body statusCode:({_bodystatuscode})";

                                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                                _model_pubsub.type = $"{_response.type} End [{_apicode}]CallBackAPI.ExecuteAsync";
                                _model_pubsub.url = _uri;
                                _model_pubsub.responsedata = _response;
                                await _pubsubService.PublishMessagesAsync(_model_pubsub);

                                return _response;
                            }

                            //Todo:成功則記錄普羅米修斯

                            //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                            dynamic _dynamicrequest = new { idoperator = _idoperator, idvendor = _idvendor, username = _bodyuserId };
                            await _pubsubService.PublishMessagesAsync(_dynamicrequest);

                            _response.code = 0;
                            _response.status = "Successful";
                            _response.result = JsonSerializer.Deserialize<dynamic>(_data.result);
                            _response.additional = new { userId = _bodyuserId, currency = _bodybalancescurrencycode, balance = _bodybalancesamount, cardType = _bodycardtype };
                        }
                        else if (_apicode == "vm")
                        {
                            _uri = _uri.Replace("{user_token}", _model.data.usertoken);
                            _uri = _uri.Replace("{session_token}", _model.data.sessiontoken);

                            var _request = new { };

                            #region 使用HttpClient呼叫API
                            var starttime = DateTime.Now;
                            var _data = await _callback.ExecuteAsync(_request, HttpMethod.Get, _uri, null, null);
                            //var _data = _callback.Execute(_request, HttpMethod.Post, _uri, null, null);
                            var endtime = DateTime.Now;
                            var apiresponsetime = (endtime - starttime).TotalMilliseconds / 1000;
                            #endregion

                            if (_data.code != 200)
                            {
                                _response.code = _data.code;
                                _response.status = $"Failure - statusCode not 200({_data.code.ToString()})";

                                //Todo:失敗則記錄普羅米修斯

                                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                                _model_pubsub.type = $"{_response.type} End [{_apicode}]CallBackAPI.ExecuteAsync";
                                _model_pubsub.url = _uri;
                                _model_pubsub.responsedata = _response;
                                await _pubsubService.PublishMessagesAsync(_model_pubsub);
                            }
                            if (_response.code != 0) return _response;

                            //Todo:成功記錄普羅米修斯

                            _response.code = 0;
                            _response.status = "Successful";
                            _response.result = JsonSerializer.Deserialize<dynamic>(_data.result);
                        }
                        else
                        {
                            _response.code = 0;
                            _response.status = "Successful - external";
                        }

                        break;
                    case 1:
                        //呼叫SP
                        var _paras = new object[] { _model.data.usertoken };
                        var _sp_response = await _mysql.CallSP<Model.TestMode_AuthAsyncResponse>("Membership.SP_MEMBERSHIP_TOKEN_CHK", _paras);

                        _response.code = _sp_response.code;
                        _response.status = _sp_response.status;

                        if (_response.code == 0)
                        {
                            Model.TestMode_AuthAsyncResponse _model_testmode_result = _sp_response.result[0];
                            switch (_model_testmode_result.Code)
                            {
                                case 1001:
                                    _response.status = "Token not exist";
                                    _response.result = new { username = _model_testmode_result.Username };
                                    break;
                                case 0:
                                    _response.status = "Success";
                                    _response.result = new { username = _model_testmode_result.Username, userphoto = "", usernickname = _model_testmode_result.Nickname, currency = _model_testmode_result.Currency, balance = _model_testmode_result.Balance, token = _model_testmode_result.Token };
                                    break;
                            }
                        }
                        else
                        {
                            //_response.result = new { balance = 0, renew_balance = 0 };
                        }
                        break;
                }

                //記錄LOG:API 呼叫記錄寫入 Pub/Sub(End)
                #region 記錄LOG:API 呼叫記錄寫入 Pub/Sub(End)
                _model_pubsub.type = $"{_response.type} End";
                _model_pubsub.url = _uri;
                _model_pubsub.responsedata = _response;
                await _pubsubService.PublishMessagesAsync(_model_pubsub);
                #endregion
            }
            catch (Exception ex)
            {
                _response.code = 9999;
                _response.status = ex.Message;

                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                _model_pubsub.type = $"{_response.type} End Catch Exception";
                _model_pubsub.responsedata = _response;
                await _pubsubService.PublishMessagesAsync(_model_pubsub);
            }

            return _response;
        }

        /// <summary>
        /// 登入 - 支援平台商可參考 API 文件說明
        /// </summary>
        /// <param name="_model">Model.Vendor.LoginRequest</param>
        /// <returns></returns>
        [HttpPost, Route("Login")]
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public async Task<Model.DefaultResponse> Login(Model.Vendor.LoginRequest _model)
        {
            Model.DefaultResponse _response = new();
            Model.PubSubRequest _model_pubsub = new();
            _response.type = "Login";
            //設定記錄Pub/Sub相關參數
            _model_pubsub.merchantid = _model.data.merchantid;
            _model_pubsub.vcode = _model.data.vcode;
            _model_pubsub.gameid = _model.data.gameid;
            _model_pubsub.usertoken = _model.data.usertoken;
            _model_pubsub.sessiontoken = _model.data.sessiontoken;
            _model_pubsub.wallet = _model.data.wallet;
            _model_pubsub.amount = _model.data.amount.ToString();
            _model_pubsub.userid = _model.data.userid;

            try
            {
                #region 驗證相關欄位並取得相關Table資料
                //設定驗證欄位
                var _verifyfields = "merchantid,vcode,usertoken";
                //取得相關Table資料(資料已Redis)
                var _vendordataresponse = await _vendorService.GetVendorData<Model.Vendor.LoginRequest, Model.Vendor.LoginRequestParams>(_model, _model.data, _verifyfields, _response, _model_pubsub);
                _response = _vendordataresponse.DefaultResponse;
                if (_response.code != 0) return _response;
                #endregion

                //取得相關Table資料
                var _vendoroperatoraccountmapping = _vendordataresponse.Redis_VendorOperatorAccountMapping;
                var _operatorimplementinfo = _vendordataresponse.Redis_OperatorImplementInfo;
                var _operatorimplementinfosecretkey = _operatorimplementinfo.SecretKey;
                var _apicode = _vendordataresponse.ApiCode;
                string _uri = _operatorimplementinfo.UrlLogin;
                string _newgameid = _vendordataresponse.NewGameID;
                _model_pubsub.url = _uri;

                switch (_vendoroperatoraccountmapping.TestMode)
                {
                    case 0:
                        Services.External.CallBackService _callback = new Services.External.CallBackService(_httpContextAccessor);

                        if (_apicode == "08online" || _apicode == "08online-exp")
                        {
                            _response.code = 9999;
                            _response.status = "This Operator does not support this function";

                            //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                            _model_pubsub.type = $"{_response.type} End [{_apicode}]CallBackAPI.ExecuteAsync";
                            _model_pubsub.url = _uri;
                            _model_pubsub.responsedata = _response;
                            await _pubsubService.PublishMessagesAsync(_model_pubsub);

                            return _response;
                        }
                        else if (_apicode == "aceonline")
                        {
                            string[] headers = { "x-api-key" };
                            string[] values = { "e495964cb27748859d1060f53a2d3ba2" };

                            var _request = new
                            {
                                userId = _model.data.userid,
                                userToken = _model.data.usertoken,
                                gameSessionId = _model.data.sessiontoken,
                                gameId = _newgameid
                            };

                            #region 使用HttpClient呼叫API
                            var starttime = DateTime.Now;
                            var _data = await _callback.ExecuteAsync(_request, HttpMethod.Post, _uri, headers, values);
                            //var _data = _callback.Execute(_request, HttpMethod.Post, _uri, headers, values);
                            var endtime = DateTime.Now;
                            var apiresponsetime = (endtime - starttime).TotalMilliseconds / 1000;
                            #endregion

                            //取得API回傳result內各屬性的值
                            var dynamicObject = Newtonsoft.Json.JsonConvert.DeserializeObject<dynamic>(_data.result)!;
                            var _bodystatuscode = dynamicObject.statusCode.Value;
                            var _bodyaccounttoken = dynamicObject.accountToken.Value;
                            var _bodybalancescurrencycode = dynamicObject.balances[0].currencyCode.Value;
                            var _bodybalancesamount = dynamicObject.balances[0].amount.Value;

                            if (_data.code != 200)
                            {
                                _response.code = _data.code;
                                _response.status = $"Failure - statusCode not 200({_bodystatuscode.ToString()})";

                                //Todo:失敗則記錄普羅米修斯

                                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                                _model_pubsub.type = $"{_response.type} End [{_apicode}]CallBackAPI.ExecuteAsync";
                                _model_pubsub.url = _uri;
                                _model_pubsub.responsedata = _response;
                                await _pubsubService.PublishMessagesAsync(_model_pubsub);
                            }
                            if (_response.code != 0) return _response;

                            if (_bodystatuscode == "RS_ERROR_SYSTEM_IN_MAINTAIN")
                            {
                                _response.code = 9998;
                            }
                            else if (_bodystatuscode == "RS_ERROR_INVALID_USER_TOKEN" || _bodystatuscode == "RS_ERROR_INVALID_ACCOUNT_TOKEN")
                            {
                                _response.code = 9997;
                            }
                            if (_response.code != 0)
                            {
                                _response.status = $"Failure - body statusCode:({_bodystatuscode})";

                                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                                _model_pubsub.type = $"{_response.type} End [{_apicode}]CallBackAPI.ExecuteAsync";
                                _model_pubsub.url = _uri;
                                _model_pubsub.responsedata = _response;
                                await _pubsubService.PublishMessagesAsync(_model_pubsub);

                                return _response;
                            }

                            //Todo:成功記錄普羅米修斯

                            _response.code = 0;
                            _response.status = "Successful";
                            _response.result = JsonSerializer.Deserialize<dynamic>(_data.result);
                            _response.additional = new { AccountToken = _bodyaccounttoken, currency = _bodybalancescurrencycode, balance = _bodybalancesamount };
                        }
                        else if (_apicode == "vm")
                        {
                            _uri = _uri.Replace("{user_token}", _model.data.usertoken);
                            _uri = _uri.Replace("{session_token}", _model.data.sessiontoken);
                            _uri = _uri.Replace("{wallet}", _model.data.wallet);
                            _uri = _uri.Replace("{amount}", _model.data.amount.ToString());

                            var _request = new { };

                            #region 使用HttpClient呼叫API
                            var starttime = DateTime.Now;
                            var _data = await _callback.ExecuteAsync(_request, HttpMethod.Get, _uri, null, null);
                            //var _data = _callback.Execute(_request, HttpMethod.Post, _uri, null, null);
                            var endtime = DateTime.Now;
                            var apiresponsetime = (endtime - starttime).TotalMilliseconds / 1000;
                            #endregion

                            //取得API回傳result內各屬性的值
                            var dynamicObject = Newtonsoft.Json.JsonConvert.DeserializeObject<dynamic>(_data.result)!;
                            var _bodysessiontoken = dynamicObject.SessionToken.Value;

                            if (_data.code != 200)
                            {
                                _response.code = _data.code;
                                _response.status = $"Failure - statusCode not 200({_data.code.ToString()})";

                                //Todo:失敗則記錄普羅米修斯

                                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                                _model_pubsub.type = $"{_response.type} End [{_apicode}]CallBackAPI.ExecuteAsync";
                                _model_pubsub.url = _uri;
                                _model_pubsub.responsedata = _response;
                                await _pubsubService.PublishMessagesAsync(_model_pubsub);
                            }
                            if (_response.code != 0) return _response;

                            //Todo:成功記錄普羅米修斯

                            _uri = _operatorimplementinfo.UrlBalance;
                            if (_model.data.vcode == "wm")
                            {
                                _uri = _uri.Replace("{user_token}", _model.data.usertoken);
                                _uri = _uri.Replace("{session_token}", _bodysessiontoken);

                                #region 使用HttpClient呼叫API
                                var starttime2 = DateTime.Now;
                                var _data2 = await _callback.ExecuteAsync(_request, HttpMethod.Get, _uri, null, null);
                                //var _data = _callback.Execute(_request, HttpMethod.Post, _uri, null, null);
                                var endtime2 = DateTime.Now;
                                var apiresponsetime2 = (endtime2 - starttime2).TotalMilliseconds / 1000;
                                #endregion

                                //取得API回傳result內各屬性的值
                                var dynamicObject2 = Newtonsoft.Json.JsonConvert.DeserializeObject<dynamic>(_data2.result)!;
                                var _bodyusertoken2 = dynamicObject2.UserToken.Value;
                                var _bodysessiontoken2 = dynamicObject2.SessionToken.Value;
                                var _bodygameidentity2 = dynamicObject2.GameIdentity.Value;
                                var _bodygamecode2 = dynamicObject2.GameCode.Value;
                                var _bodycurrency2 = dynamicObject2.Currency.Value;
                                var _bodycashbalance2 = dynamicObject2.CashBalance.Value;
                                var _bodytype2 = dynamicObject2.Type.Value;
                                var _bodystatus2 = dynamicObject2.Status.Value;
                                var _bodyplayer2 = dynamicObject2.Player.Value;
                                var _bodylanguage2 = dynamicObject2.Language.Value;
                                var _bodychannel2 = dynamicObject2.Channel.Value;

                                if (_data2.code != 200)
                                {
                                    _response.code = _data2.code;
                                    _response.status = $"Failure - statusCode not 200({_data2.code.ToString()})";
                                    _response.result = JsonSerializer.Deserialize<dynamic>(_data2.result);

                                    //Todo:失敗則記錄普羅米修斯

                                    //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                                    _model_pubsub.type = $"{_response.type} End [{_model.data.vcode}][2]CallBackAPI.ExecuteAsync";
                                    _model_pubsub.url = _uri;
                                    _model_pubsub.responsedata = _response;
                                    await _pubsubService.PublishMessagesAsync(_model_pubsub);
                                }
                                if (_response.code != 0) return _response;

                                //Todo:成功記錄普羅米修斯

                                _response.code = 0;
                                _response.status = "Successful";
                                _response.result = JsonSerializer.Deserialize<dynamic>(_data.result);
                                _response.additional = new
                                {
                                    UserToken = _bodyusertoken2,
                                    SessionToken = _bodysessiontoken2,
                                    GameIdentity = _bodygameidentity2,
                                    GameCode = _bodygamecode2,
                                    Currency = _bodycurrency2,
                                    CashBalance = _bodycashbalance2,
                                    Type = _bodytype2,
                                    Status = _bodystatus2,
                                    Player = _bodyplayer2,
                                    Language = _bodylanguage2,
                                    Channel = _bodychannel2
                                };
                            }
                        }
                        else
                        {
                            _response.code = 0;
                            _response.status = "Successful - external";
                        }

                        break;
                    case 1:
                        //Node.js版本無TestMode
                        _response.code = 0;
                        _response.status = "Successful - test mode";
                        break;
                }

                //記錄LOG:API 呼叫記錄寫入 Pub/Sub(End)
                #region 記錄LOG:API 呼叫記錄寫入 Pub/Sub(End)
                _model_pubsub.type = $"{_response.type} End";
                _model_pubsub.url = _uri;
                _model_pubsub.responsedata = _response;
                await _pubsubService.PublishMessagesAsync(_model_pubsub);
                #endregion
            }
            catch (Exception ex)
            {
                _response.code = 9999;
                _response.status = ex.Message;

                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                _model_pubsub.type = $"{_response.type} End Catch Exception";
                _model_pubsub.responsedata = _response;
                await _pubsubService.PublishMessagesAsync(_model_pubsub);
            }

            return _response;
        }

        /// <summary>
        /// 押注 - 相關參數各自支援之平台商端, 可參考 API 文件說明
        /// </summary>
        /// <param name="_model">Model.Vendor.BetRequest</param>
        /// <returns></returns>
        [HttpPost, Route("DeductionPoint")]
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public async Task<Model.DefaultResponse> Bet(Model.Vendor.BetRequest _model)
        {
            Model.DefaultResponse _response = new();
            Model.PubSubRequest _model_pubsub = new();
            _response.type = "Bet";
            //設定記錄Pub/Sub相關參數
            _model_pubsub.merchantid = _model.data.merchantid;
            _model_pubsub.vcode = _model.data.vcode;
            _model_pubsub.gameid = _model.data.gameid;
            _model_pubsub.usertoken = _model.data.usertoken;
            _model_pubsub.sessiontoken = _model.data.sessiontoken;
            _model_pubsub.roundid = _model.data.roundid;
            _model_pubsub.currency = _model.data.currency;
            _model_pubsub.betamount = _model.data.betamount;
            _model_pubsub.winamount = _model.data.winamount;
            _model_pubsub.end = _model.data.end.ToString();
            _model_pubsub.transactionid = _model.data.transactionid;
            _model_pubsub.bettime = _model.data.bettime;
            _model_pubsub.transfer = _model.data.transfer.ToString();
            _model_pubsub.external = _model.data.external;
            _model_pubsub.balance = _model.data.balance;
            _model_pubsub.offlinetagamount = _model.data.offlinetagamount;
            _model_pubsub.detail = _model.data.detail;

            try
            {
                #region 驗證相關欄位並取得相關Table資料
                //設定驗證欄位
                var _verifyfields = "merchantid,vcode,usertoken";
                //取得相關Table資料(資料已Redis)
                var _vendordataresponse = await _vendorService.GetVendorData<Model.Vendor.BetRequest, Model.Vendor.BetRequestParams>(_model, _model.data, _verifyfields, _response, _model_pubsub);
                _response = _vendordataresponse.DefaultResponse;
                if (_response.code != 0) return _response;
                #endregion

                //取得相關Table資料
                var _vendoroperatoraccountmapping = _vendordataresponse.Redis_VendorOperatorAccountMapping;
                var _operatorimplementinfo = _vendordataresponse.Redis_OperatorImplementInfo;
                var _operatorimplementinfosecretkey = _operatorimplementinfo.SecretKey;
                var _apicode = _vendordataresponse.ApiCode;
                string _uri = _operatorimplementinfo.UrlWithdraw;
                string _newgameid = _vendordataresponse.NewGameID;
                _model_pubsub.url = _uri;

                switch (_vendoroperatoraccountmapping.TestMode)
                {
                    case 0:
                        Services.External.CallBackService _callback = new Services.External.CallBackService(_httpContextAccessor);

                        if (_apicode == "08online")
                        {
                            var _uid = StringHelper.makeTransactionId(16);
                            var _currenttime = DateTime.Now.ToString("yyyy/MM/dd HH:MM:ss");
                            var _bettimenow = (string.IsNullOrEmpty(_model.data.bettime)) ? _currenttime : _model.data.bettime;

                            var _formdata = new
                            {
                                reqid = _uid,
                                token = _model.data.usertoken,
                                currency = _model.data.currency,
                                gameid = _newgameid,
                                transactionid = _model.data.transactionid,
                                roundid = _model.data.roundid,
                                bettime = _bettimenow,
                                betamount = _model.data.betamount,
                                winloseamount = _model.data.winamount,
                                isfreeround = false,
                                jackpot = _model.data.jackpot,
                                bonus = 0,
                                detail = _model.data.detail
                            };
                            var _formhash = Utility.Encryptions.MD5_Generate(JsonSerializer.Serialize(_formdata) + _operatorimplementinfosecretkey);

                            var _request = new { data = _formdata, hash = _formhash };

                            #region 使用HttpClient呼叫API
                            var starttime = DateTime.Now;
                            var _data = await _callback.ExecuteAsync(_request, HttpMethod.Post, _uri, null, null);
                            //var _data = _callback.Execute(_request, HttpMethod.Post, _uri, null, null);
                            var endtime = DateTime.Now;
                            var apiresponsetime = (endtime - starttime).TotalMilliseconds / 1000;
                            #endregion

                            //取得API回傳result內各屬性的值
                            var dynamicObject = Newtonsoft.Json.JsonConvert.DeserializeObject<dynamic>(_data.result)!;
                            var _bodycode = dynamicObject.code.Value;
                            var _bodymessage = dynamicObject.message.Value;
                            var _bodyresult = Newtonsoft.Json.JsonConvert.SerializeObject(dynamicObject.result);

                            if (_data.code != 200)
                            {
                                _response.code = _data.code;
                                _response.status = $"Failure - statusCode not 200({_bodycode.ToString()})";

                                //Todo:失敗則記錄普羅米修斯

                                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                                _model_pubsub.type = $"{_response.type} End [{_apicode}]CallBackAPI.ExecuteAsync";
                                _model_pubsub.url = _uri;
                                _model_pubsub.responsedata = _response;
                                await _pubsubService.PublishMessagesAsync(_model_pubsub);
                            }
                            if (_response.code != 0) return _response;

                            //Todo:成功記錄普羅米修斯

                            _response.code = 0;
                            _response.status = "Successful";
                            if (_bodycode != 0)
                            {
                                _response.code = (int)_bodycode;
                                _response.status = _bodymessage;
                            }
                            _response.result = JsonSerializer.Deserialize<dynamic>(_bodyresult);
                        }
                        else if (_apicode == "aceonline")
                        {
                            string[] headers = { "x-api-key" };
                            string[] values = { "e495964cb27748859d1060f53a2d3ba2" };

                            var _tags_actions_list = new dynamic[] {
                                new { action = "Lose", moneyAmount = _model.data.betamount },
                                new { action = "Gain", moneyAmount = _model.data.winamount }
                                };
                            var _tags_actions = new { actions = _tags_actions_list };
                            var _tags = new { operationType = "WagerTagOperation", tagType = "Money", tags = _tags_actions };

                            var _gametags = new { operationType = "WagerTagOperation", tagType = "Money", tag = new { offlineSpin = _model.data.offlinetagamount, detail = _model.data.detail } };

                            dynamic _operations1 = new { operationType = "WagerLifecycleOperation", action = "create" };
                            dynamic _operations2 = new { operationType = "WagerWithdrawOperation", withdraw = _model.data.betamount, transfer = _model.data.transfer, id = _model.data.roundid };
                            dynamic _operations = new { _operations1, _operations2 };

                            if (_model.data.end && int.Parse(_model.data.winamount) > 0)
                            {
                                _operations1 = new { operationType = "WagerLifecycleOperation", deposit = string.IsNullOrEmpty(_model.data.balance) ? _model.data.winamount : _model.data.balance, transfer = _model.data.transfer };
                                _operations2 = new { operationType = "WagerLifecycleOperation", action = "confirm" };
                                _operations = new { _operations1, tags = _tags, gametags = _gametags, _operations2 };
                            }

                            var _request = new
                            {
                                userId = _model.data.userid,
                                transactionId = $"BET-{_model.data.transactionid}",
                                accountToken = _model.data.usertoken,
                                gameSessionId = _model.data.sessiontoken,
                                gameId = _newgameid,
                                wagerId = _model.data.transactionid,
                                operations = _operations
                            };

                            #region 使用HttpClient呼叫API
                            var starttime = DateTime.Now;
                            var _data = await _callback.ExecuteAsync(_request, HttpMethod.Post, _uri, headers, values);
                            //var _data = _callback.Execute(_request, HttpMethod.Post, _uri, headers, values);
                            var endtime = DateTime.Now;
                            var apiresponsetime = (endtime - starttime).TotalMilliseconds / 1000;
                            #endregion

                            //取得API回傳result內各屬性的值
                            var dynamicObject = Newtonsoft.Json.JsonConvert.DeserializeObject<dynamic>(_data.result)!;
                            var _bodystatuscode = dynamicObject.statusCode.Value;
                            var _bodybalancescurrencycode = dynamicObject.balances[0].currencyCode.Value;
                            var _bodybalancesamount = dynamicObject.balances[0].amount.Value;

                            if (_data.code != 200)
                            {
                                _response.code = _data.code;
                                _response.status = $"Failure - statusCode not 200({_bodystatuscode.ToString()})";

                                //Todo:失敗則記錄普羅米修斯

                                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                                _model_pubsub.type = $"{_response.type} End [{_apicode}]CallBackAPI.ExecuteAsync";
                                _model_pubsub.url = _uri;
                                _model_pubsub.responsedata = _response;
                                await _pubsubService.PublishMessagesAsync(_model_pubsub);
                            }
                            if (_response.code != 0) return _response;

                            if (_bodystatuscode == "RS_ERROR_SYSTEM_IN_MAINTAIN")
                            {
                                _response.code = 9998;
                            }
                            else if (_bodystatuscode == "RS_ERROR_INVALID_USER_TOKEN" || _bodystatuscode == "RS_ERROR_INVALID_ACCOUNT_TOKEN")
                            {
                                _response.code = 9997;
                            }
                            if (_response.code != 0)
                            {
                                _response.status = $"Failure - body statusCode:({_bodystatuscode})";

                                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                                _model_pubsub.type = $"{_response.type} End [{_apicode}]CallBackAPI.ExecuteAsync";
                                _model_pubsub.url = _uri;
                                _model_pubsub.responsedata = _response;
                                await _pubsubService.PublishMessagesAsync(_model_pubsub);

                                return _response;
                            }

                            //Todo:成功記錄普羅米修斯

                            _response.code = 0;
                            _response.status = "Successful";
                            _response.result = JsonSerializer.Deserialize<dynamic>(_data.result);
                            _response.additional = new { currency = _bodybalancescurrencycode, balance = _bodybalancesamount };
                        }
                        else if (_apicode == "vm")
                        {
                            _uri = _uri.Replace("{user_token}", _model.data.usertoken);
                            _uri = _uri.Replace("{session_token}", _model.data.sessiontoken);

                            var _request = new
                            {
                                roundID = _model.data.roundid,
                                Currency = _model.data.currency,
                                BetAmount = _model.data.betamount,
                                WinAmount = _model.data.winamount,
                                End = _model.data.end,
                                Jackpot = _model.data.jackpot,
                                External = _model.data.external
                            };

                            #region 使用HttpClient呼叫API
                            var starttime = DateTime.Now;
                            var _data = await _callback.ExecuteAsync(_request, HttpMethod.Post, _uri, null, null);
                            //var _data = _callback.Execute(_request, HttpMethod.Post, _uri, null, null);
                            var endtime = DateTime.Now;
                            var apiresponsetime = (endtime - starttime).TotalMilliseconds / 1000;
                            #endregion

                            if (_data.code != 200)
                            {
                                _response.code = _data.code;
                                _response.status = $"Failure - statusCode not 200({_data.code.ToString()})";

                                //Todo:失敗則記錄普羅米修斯

                                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                                _model_pubsub.type = $"{_response.type} End [{_apicode}]CallBackAPI.ExecuteAsync";
                                _model_pubsub.url = _uri;
                                _model_pubsub.responsedata = _response;
                                await _pubsubService.PublishMessagesAsync(_model_pubsub);
                            }
                            if (_response.code != 0) return _response;

                            //Todo:成功記錄普羅米修斯

                            _response.code = 0;
                            _response.status = "Successful";
                            _response.result = JsonSerializer.Deserialize<dynamic>(_data.result);
                        }
                        else
                        {
                            _response.code = 0;
                            _response.status = "Successful - external";
                        }

                        break;
                    case 1:
                        //呼叫SP
                        var _paras = new object[] { _model.data.usertoken, float.Parse(_model.data.betamount), _model.data.transactionid, _model.data.roundid, _vendoroperatoraccountmapping.IdVendor, _vendoroperatoraccountmapping.IdOperator, _model.data.gameid };
                        var _sp_response = await _mysql.CallSP<Model.TestMode_BetAsyncResponse>("Membership.SP_MEMBERSHIP_DEDUCTION_POINT_UPD", _paras);

                        _response.code = _sp_response.code;
                        _response.status = _sp_response.status;

                        if (_response.code == 0)
                        {
                            Model.TestMode_BetAsyncResponse _model_testmode_result = _sp_response.result[0];
                            switch (_model_testmode_result.Code)
                            {
                                case 1001:
                                    _response.status = "Token not exist";
                                    break;
                                case 1002:
                                    _response.status = "Balance not enough";
                                    break;
                                case 1003:
                                    _response.status = "Transactionid exist";
                                    break;
                                case 0:
                                    _response.status = "Success";
                                    break;
                            }

                            _response.result = new { balance = _model_testmode_result.OldBalance, renew_balance = _model_testmode_result.Balance };
                        }
                        else
                        {
                            _response.result = new { balance = 0, renew_balance = 0 };
                        }
                        break;
                }

                //記錄LOG:API 呼叫記錄寫入 Pub/Sub(End)
                #region 記錄LOG:API 呼叫記錄寫入 Pub/Sub(End)
                _model_pubsub.type = $"{_response.type} End";
                _model_pubsub.url = _uri;
                _model_pubsub.responsedata = _response;
                await _pubsubService.PublishMessagesAsync(_model_pubsub);
                #endregion
            }
            catch (Exception ex)
            {
                _response.code = 9999;
                _response.status = ex.Message;

                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                _model_pubsub.type = $"{_response.type} End Catch Exception";
                _model_pubsub.responsedata = _response;
                await _pubsubService.PublishMessagesAsync(_model_pubsub);
            }

            return _response;
        }

        /// <summary>
        /// 結算 - 相關參數各自支援之平台商端, 可參考 API 文件說明
        /// </summary>
        /// <param name="_model">Model.Vendor.SettleRequest</param>
        /// <returns></returns>
        [HttpPost, Route("DepositPoint")]
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public async Task<Model.DefaultResponse> Settle(Model.Vendor.SettleRequest _model)
        {
            Model.DefaultResponse _response = new();
            Model.PubSubRequest _model_pubsub = new();
            _response.type = "Settle";
            //設定記錄Pub/Sub相關參數
            _model_pubsub.merchantid = _model.data.merchantid;
            _model_pubsub.vcode = _model.data.vcode;
            _model_pubsub.gameid = _model.data.gameid;
            _model_pubsub.usertoken = _model.data.usertoken;
            _model_pubsub.sessiontoken = _model.data.sessiontoken;
            _model_pubsub.roundid = _model.data.roundid;
            _model_pubsub.currency = _model.data.currency;
            _model_pubsub.betamount = _model.data.betamount.ToString();
            _model_pubsub.winamount = _model.data.winamount.ToString();
            _model_pubsub.end = _model.data.end.ToString();
            _model_pubsub.userid = _model.data.userid.ToString();
            _model_pubsub.transactionid = _model.data.transactionid;
            _model_pubsub.bettime = _model.data.bettime;
            _model_pubsub.transfer = _model.data.transfer.ToString();
            _model_pubsub.external = _model.data.external;
            _model_pubsub.balance = _model.data.balance;
            _model_pubsub.offlinetagamount = _model.data.offlinetagamount;
            _model_pubsub.detail = _model.data.detail;

            try
            {
                #region 驗證相關欄位並取得相關Table資料
                //設定驗證欄位
                var _verifyfields = "merchantid,vcode,usertoken";
                //取得相關Table資料(資料已Redis)
                var _vendordataresponse = await _vendorService.GetVendorData<Model.Vendor.SettleRequest, Model.Vendor.SettleRequestParams>(_model, _model.data, _verifyfields, _response, _model_pubsub);
                _response = _vendordataresponse.DefaultResponse;
                if (_response.code != 0) return _response;
                #endregion

                //取得相關Table資料
                var _vendoroperatoraccountmapping = _vendordataresponse.Redis_VendorOperatorAccountMapping;
                var _operatorimplementinfo = _vendordataresponse.Redis_OperatorImplementInfo;
                var _operatorimplementinfosecretkey = _operatorimplementinfo.SecretKey;
                var _apicode = _vendordataresponse.ApiCode;
                string _uri = _operatorimplementinfo.UrlDeposit;
                string _newgameid = _vendordataresponse.NewGameID;
                _model_pubsub.url = _uri;

                switch (_vendoroperatoraccountmapping.TestMode)
                {
                    case 0:
                        Services.External.CallBackService _callback = new Services.External.CallBackService(_httpContextAccessor);

                        if (_apicode == "08online")
                        {
                            var _uid = StringHelper.makeTransactionId(16);
                            var _currenttime = DateTime.Now.ToString("yyyy/MM/dd HH:MM:ss");

                            var _formdata = new
                            {
                                reqid = _uid,
                                token = _model.data.usertoken,
                                currency = _model.data.currency,
                                gameid = _newgameid,
                                transactionid = _model.data.transactionid,
                                roundid = _model.data.roundid,
                                bettime = _currenttime,
                                betamount = _model.data.betamount,
                                winloseamount = _model.data.winamount,
                                servicefee = _model.data.servicefee,
                                isfreeround = false,
                                jackpot = _model.data.jackpot,
                                bonus = _model.data.bonus,
                                offlinetagamount = _model.data.offlinetagamount,
                                end = true,
                                detail = _model.data.detail
                            };
                            var _formhash = Utility.Encryptions.MD5_Generate(JsonSerializer.Serialize(_formdata) + _operatorimplementinfosecretkey);

                            var _request = new { data = _formdata, hash = _formhash };

                            #region 使用HttpClient呼叫API
                            var starttime = DateTime.Now;
                            var _data = await _callback.ExecuteAsync(_request, HttpMethod.Post, _uri, null, null);
                            //var _data = _callback.Execute(_request, HttpMethod.Post, _uri, null, null);
                            var endtime = DateTime.Now;
                            var apiresponsetime = (endtime - starttime).TotalMilliseconds / 1000;
                            #endregion

                            //取得API回傳result內各屬性的值
                            var dynamicObject = Newtonsoft.Json.JsonConvert.DeserializeObject<dynamic>(_data.result)!;
                            var _bodycode = dynamicObject.code.Value;
                            var _bodymessage = dynamicObject.message.Value;
                            var _bodyresult = Newtonsoft.Json.JsonConvert.SerializeObject(dynamicObject.result);

                            if (_data.code != 200)
                            {
                                _response.code = _data.code;
                                _response.status = $"Failure - statusCode not 200({_data.code.ToString()})";

                                //Todo:失敗則記錄普羅米修斯

                                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                                _model_pubsub.type = $"{_response.type} End [{_apicode}]CallBackAPI.ExecuteAsync";
                                _model_pubsub.url = _uri;
                                _model_pubsub.responsedata = _response;
                                await _pubsubService.PublishMessagesAsync(_model_pubsub);
                            }
                            if (_response.code != 0) return _response;

                            if (_bodyresult == null)
                            {
                                _response.code = _data.code;
                                _response.status = "Failure - body is null";

                                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                                _model_pubsub.type = $"{_response.type} End [{_apicode}]CallBackAPI.ExecuteAsync";
                                _model_pubsub.url = _uri;
                                _model_pubsub.responsedata = _response;
                                await _pubsubService.PublishMessagesAsync(_model_pubsub);
                            }
                            if (_response.code != 0) return _response;

                            //Todo:成功記錄普羅米修斯

                            _response.code = 0;
                            _response.status = "Successful";
                            if (_bodycode != 0)
                            {
                                _response.code = (int)_bodycode;
                                _response.status = _bodymessage;
                            }
                            _response.result = JsonSerializer.Deserialize<dynamic>(_bodyresult);
                        }
                        else if (_apicode == "aceonline")
                        {
                            string[] headers = { "x-api-key" };
                            string[] values = { "e495964cb27748859d1060f53a2d3ba2" };

                            var _tags_actions_list = new dynamic[] {
                                new { action = "Lose", moneyAmount = _model.data.betamount },
                                new { action = "Gain", moneyAmount = _model.data.winamount }
                                };
                            var _tags_actions = new { actions = _tags_actions_list };
                            var _tags = new { operationType = "WagerTagOperation", tagType = "Money", tags = _tags_actions };

                            var _gametags = new { operationType = "WagerTagOperation", tagType = "Game", tag = new { offlineSpin = _model.data.offlinetagamount, detail = _model.data.detail } };

                            float _deposit = 0;
                            if (_model.data.balance == null)
                            {
                                _deposit = _model.data.winamount;
                            }
                            else if (float.Parse(_model.data.balance) <= 0)
                            {
                                _deposit = _model.data.winamount;
                            }
                            else
                            {
                                _deposit = float.Parse(_model.data.balance);
                            }

                            dynamic _operations1 = new { operationType = "WagerDepositOperation", deposit = _deposit, transfer = _model.data.transfer, id = _model.data.roundid };
                            dynamic _operations2 = new { operationType = "WagerLifecycleOperation", action = "confirm" };
                            dynamic _operations = new { _operations1, tags = _tags, gametags = _gametags, _operations2 };

                            var _request = new
                            {
                                userId = _model.data.userid,
                                transactionId = $"SETTLE-{_model.data.transactionid}",
                                accountToken = _model.data.usertoken,
                                gameSessionId = _model.data.sessiontoken,
                                gameId = _newgameid,
                                wagerId = _model.data.transactionid,
                                operations = _operations
                            };

                            #region 使用HttpClient呼叫API
                            var starttime = DateTime.Now;
                            var _data = await _callback.ExecuteAsync(_request, HttpMethod.Post, _uri, headers, values);
                            //var _data = _callback.Execute(_request, HttpMethod.Post, _uri, headers, values);
                            var endtime = DateTime.Now;
                            var apiresponsetime = (endtime - starttime).TotalMilliseconds / 1000;
                            #endregion

                            //取得API回傳result內各屬性的值
                            var dynamicObject = Newtonsoft.Json.JsonConvert.DeserializeObject<dynamic>(_data.result)!;
                            var _bodystatuscode = dynamicObject.statusCode.Value;
                            var _bodybalancescurrencycode = dynamicObject.balances[0].currencyCode.Value;
                            var _bodybalancesamount = dynamicObject.balances[0].amount.Value;

                            if (_data.code != 200)
                            {
                                _response.code = _data.code;
                                _response.status = $"Failure - statusCode not 200({_data.code.ToString()})";

                                //Todo:失敗則記錄普羅米修斯

                                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                                _model_pubsub.type = $"{_response.type} End [{_apicode}]CallBackAPI.ExecuteAsync";
                                _model_pubsub.url = _uri;
                                _model_pubsub.responsedata = _response;
                                await _pubsubService.PublishMessagesAsync(_model_pubsub);
                            }
                            if (_response.code != 0) return _response;

                            if (_bodystatuscode == "RS_ERROR_SYSTEM_IN_MAINTAIN")
                            {
                                _response.code = 9998;
                            }
                            else if (_bodystatuscode == "RS_ERROR_INVALID_USER_TOKEN" || _bodystatuscode == "RS_ERROR_INVALID_ACCOUNT_TOKEN")
                            {
                                _response.code = 9997;
                            }
                            else if (_bodystatuscode == "RS_OK")
                            {
                                _response.code = 0;
                            }
                            else
                            {
                                _response.code = 9999;
                            }
                            if (_response.code != 0)
                            {
                                _response.status = $"Failure - body statusCode:({_bodystatuscode})";

                                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                                _model_pubsub.type = $"{_response.type} End [{_apicode}]CallBackAPI.ExecuteAsync";
                                _model_pubsub.url = _uri;
                                _model_pubsub.responsedata = _response;
                                await _pubsubService.PublishMessagesAsync(_model_pubsub);

                                return _response;
                            }

                            //Todo:成功記錄普羅米修斯

                            _response.code = 0;
                            _response.status = "Successful";
                            _response.result = JsonSerializer.Deserialize<dynamic>(_data.result);
                            _response.additional = new { currency = _bodybalancescurrencycode, balance = _bodybalancesamount };
                        }
                        else if (_apicode == "vm")
                        {
                            _uri = _uri.Replace("{user_token}", _model.data.usertoken);
                            _uri = _uri.Replace("{session_token}", _model.data.sessiontoken);

                            var _request = new
                            {
                                roundID = _model.data.roundid,
                                Currency = _model.data.currency,
                                BetAmount = _model.data.betamount,
                                WinAmount = _model.data.winamount,
                                End = _model.data.end,
                                Jackpot = _model.data.jackpot,
                                External = _model.data.external
                            };

                            #region 使用HttpClient呼叫API
                            var starttime = DateTime.Now;
                            var _data = await _callback.ExecuteAsync(_request, HttpMethod.Post, _uri, null, null);
                            //var _data = _callback.Execute(_request, HttpMethod.Post, _uri, null, null);
                            var endtime = DateTime.Now;
                            var apiresponsetime = (endtime - starttime).TotalMilliseconds / 1000;
                            #endregion

                            if (_data.code != 200)
                            {
                                _response.code = _data.code;
                                _response.status = $"Failure - statusCode not 200({_data.code.ToString()})";

                                //Todo:失敗則記錄普羅米修斯

                                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                                _model_pubsub.type = $"{_response.type} End [{_apicode}]CallBackAPI.ExecuteAsync";
                                _model_pubsub.url = _uri;
                                _model_pubsub.responsedata = _response;
                                await _pubsubService.PublishMessagesAsync(_model_pubsub);
                            }
                            if (_response.code != 0) return _response;

                            //Todo:成功記錄普羅米修斯

                            _response.code = 0;
                            _response.status = "Successful";
                            _response.result = JsonSerializer.Deserialize<dynamic>(_data.result);
                        }
                        else
                        {
                            _response.code = 0;
                            _response.status = "Successful - external";
                        }

                        break;
                    case 1:
                        //呼叫SP
                        var _paras = new object[] { _model.data.usertoken, _model.data.winamount, _model.data.transactionid, _model.data.roundid };
                        var _sp_response = await _mysql.CallSP<Model.TestMode_SettleAsyncResponse>("Membership.SP_MEMBERSHIP_BALANCE_DEPOSIT_UPD", _paras);

                        _response.code = _sp_response.code;
                        _response.status = _sp_response.status;

                        if (_response.code == 0)
                        {
                            Model.TestMode_SettleAsyncResponse _model_testmode_result = _sp_response.result[0];
                            switch (_model_testmode_result.Code)
                            {
                                case 1001:
                                    _response.status = "Token not exist";
                                    break;
                                case 1004:
                                    _response.status = "Transaction not exist";
                                    break;
                                case 1005:
                                    _response.status = "RoundId not exist";
                                    break;
                                case 1006:
                                    _response.status = "Round and Transaction are settle already";
                                    break;
                                case 1007:
                                    _response.status = "Round and Transaction are cancelled";
                                    break;
                                case 0:
                                    _response.status = "Success";
                                    break;
                            }

                            _response.result = new { balance = _model_testmode_result.OldBalance, renew_balance = _model_testmode_result.Balance };
                        }
                        else
                        {
                            _response.result = new { balance = 0, renew_balance = 0 };
                        }
                        break;
                }

                //記錄LOG:API 呼叫記錄寫入 Pub/Sub(End)
                #region 記錄LOG:API 呼叫記錄寫入 Pub/Sub(End)
                _model_pubsub.type = $"{_response.type} End";
                _model_pubsub.url = _uri;
                _model_pubsub.responsedata = _response;
                await _pubsubService.PublishMessagesAsync(_model_pubsub);
                #endregion
            }
            catch (Exception ex)
            {
                _response.code = 9999;
                _response.status = ex.Message;

                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                _model_pubsub.type = $"{_response.type} Catch Exception";
                _model_pubsub.responsedata = _response;
                await _pubsubService.PublishMessagesAsync(_model_pubsub);
            }

            return _response;
        }

        /// <summary>
        /// 取消押注
        /// </summary>
        /// <param name="_model">Model.Vendor.CancelRequest</param>
        /// <returns></returns>
        [HttpPost, Route("BetCancel")]
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public async Task<Model.DefaultResponse> Cancel(Model.Vendor.CancelRequest _model)
        {
            Model.DefaultResponse _response = new();
            Model.PubSubRequest _model_pubsub = new();
            _response.type = "Cancel";
            //設定記錄Pub/Sub相關參數
            _model_pubsub.merchantid = _model.data.merchantid;
            _model_pubsub.vcode = _model.data.vcode;
            _model_pubsub.gameid = _model.data.gameid;
            _model_pubsub.usertoken = _model.data.usertoken;
            _model_pubsub.sessiontoken = _model.data.sessiontoken;
            _model_pubsub.roundid = _model.data.roundid;
            _model_pubsub.currency = _model.data.currency;
            _model_pubsub.betamount = _model.data.betamount.ToString();
            _model_pubsub.winamount = _model.data.winamount.ToString();
            _model_pubsub.userid = _model.data.userid.ToString();
            _model_pubsub.transactionid = _model.data.transactionid;

            try
            {
                #region 驗證相關欄位並取得相關Table資料
                //設定驗證欄位
                var _verifyfields = "merchantid,vcode,usertoken";
                //取得相關Table資料(資料已Redis)
                var _vendordataresponse = await _vendorService.GetVendorData<Model.Vendor.CancelRequest, Model.Vendor.CancelRequestParams>(_model, _model.data, _verifyfields, _response, _model_pubsub);
                _response = _vendordataresponse.DefaultResponse;
                if (_response.code != 0) return _response;
                #endregion

                //取得相關Table資料
                var _vendoroperatoraccountmapping = _vendordataresponse.Redis_VendorOperatorAccountMapping;
                var _operatorimplementinfo = _vendordataresponse.Redis_OperatorImplementInfo;
                var _operatorimplementinfosecretkey = _operatorimplementinfo.SecretKey;
                var _apicode = _vendordataresponse.ApiCode;
                string _uri = _operatorimplementinfo.UrlBetCancel;
                string _newgameid = _vendordataresponse.NewGameID;
                _model_pubsub.url = _uri;

                switch (_vendoroperatoraccountmapping.TestMode)
                {
                    case 0:
                        Services.External.CallBackService _callback = new Services.External.CallBackService(_httpContextAccessor);

                        if (_apicode == "08online")
                        {
                            var _uid = StringHelper.makeTransactionId(16);
                            var _currenttime = DateTime.Now.ToString("yyyy/MM/dd HH:MM:ss");

                            var _formdata = new
                            {
                                reqid = _uid,
                                token = _model.data.usertoken,
                                currency = _model.data.currency,
                                gameid = _newgameid,
                                transactionid = _model.data.transactionid,
                                roundid = _model.data.roundid,
                                bettime = _currenttime,
                                betamount = _model.data.betamount,
                                winloseamount = _model.data.winamount
                            };
                            var _formhash = Utility.Encryptions.MD5_Generate(JsonSerializer.Serialize(_formdata) + _operatorimplementinfosecretkey);

                            var _request = new { data = _formdata, hash = _formhash };

                            #region 使用HttpClient呼叫API
                            var starttime = DateTime.Now;
                            var _data = await _callback.ExecuteAsync(_request, HttpMethod.Post, _uri, null, null);
                            //var _data = _callback.Execute(_request, HttpMethod.Post, _uri, null, null);
                            var endtime = DateTime.Now;
                            var apiresponsetime = (endtime - starttime).TotalMilliseconds / 1000;
                            #endregion

                            //取得API回傳result內各屬性的值
                            var dynamicObject = Newtonsoft.Json.JsonConvert.DeserializeObject<dynamic>(_data.result)!;
                            var _bodycode = dynamicObject.code.Value;
                            var _bodymessage = dynamicObject.message.Value;
                            var _bodyresult = Newtonsoft.Json.JsonConvert.SerializeObject(dynamicObject.result);

                            if (_data.code != 200)
                            {
                                _response.code = _data.code;
                                _response.status = $"Failure - statusCode not 200({_data.code.ToString()})";

                                //Todo:失敗則記錄普羅米修斯

                                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                                _model_pubsub.type = $"{_response.type} End [{_apicode}]CallBackAPI.ExecuteAsync";
                                _model_pubsub.url = _uri;
                                _model_pubsub.responsedata = _response;
                                await _pubsubService.PublishMessagesAsync(_model_pubsub);
                            }
                            if (_response.code != 0) return _response;

                            if (_bodyresult == null)
                            {
                                _response.code = _data.code;
                                _response.status = "Failure - body is null";

                                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                                _model_pubsub.type = $"{_response.type} End [{_apicode}]CallBackAPI.ExecuteAsync";
                                _model_pubsub.url = _uri;
                                _model_pubsub.responsedata = _response;
                                await _pubsubService.PublishMessagesAsync(_model_pubsub);
                            }
                            if (_response.code != 0) return _response;

                            //Todo:成功記錄普羅米修斯

                            _response.code = 0;
                            _response.status = "Successful";
                            if (_bodycode != 0)
                            {
                                _response.code = (int)_bodycode;
                                _response.status = _bodymessage;
                            }
                            _response.result = JsonSerializer.Deserialize<dynamic>(_bodyresult);
                        }
                        else if (_apicode == "aceonline")
                        {
                            string[] headers = { "x-api-key" };
                            string[] values = { "e495964cb27748859d1060f53a2d3ba2" };

                            var _tags = new { operationType = "WagerLifecycleOperation", id = _model.data.roundid, action = "cancel" };

                            var _request = new
                            {
                                wagerId = _model.data.transactionid,
                                transactionId = $"CANCEL-{_model.data.transactionid}",
                                userId = _model.data.userid,
                                gameId = _newgameid,
                                accountToken = _model.data.usertoken,
                                operations = _tags
                            };

                            #region 使用HttpClient呼叫API
                            var starttime = DateTime.Now;
                            var _data = await _callback.ExecuteAsync(_request, HttpMethod.Post, _uri, headers, values);
                            //var _data = _callback.Execute(_request, HttpMethod.Post, _uri, headers, values);
                            var endtime = DateTime.Now;
                            var apiresponsetime = (endtime - starttime).TotalMilliseconds / 1000;
                            #endregion

                            //取得API回傳result內各屬性的值
                            var dynamicObject = Newtonsoft.Json.JsonConvert.DeserializeObject<dynamic>(_data.result)!;
                            var _bodystatuscode = dynamicObject.statusCode.Value;
                            var _bodybalancescurrencycode = dynamicObject.balances[0].currencyCode.Value;
                            var _bodybalancesamount = dynamicObject.balances[0].amount.Value;

                            if (_data.code != 200)
                            {
                                _response.code = _data.code;
                                _response.status = $"Failure - statusCode not 200({_data.code.ToString()})";

                                //Todo:失敗則記錄普羅米修斯

                                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                                _model_pubsub.type = $"{_response.type} End [{_apicode}]CallBackAPI.ExecuteAsync";
                                _model_pubsub.url = _uri;
                                _model_pubsub.responsedata = _response;
                                await _pubsubService.PublishMessagesAsync(_model_pubsub);
                            }
                            if (_response.code != 0) return _response;

                            if (_bodystatuscode == "RS_ERROR_SYSTEM_IN_MAINTAIN")
                            {
                                _response.code = 9998;
                            }
                            else if (_bodystatuscode == "RS_ERROR_INVALID_USER_TOKEN" || _bodystatuscode == "RS_ERROR_INVALID_ACCOUNT_TOKEN")
                            {
                                _response.code = 9997;
                            }
                            if (_response.code != 0)
                            {
                                _response.status = $"Failure - body statusCode:({_bodystatuscode})";

                                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                                _model_pubsub.type = $"{_response.type} End [{_apicode}]CallBackAPI.ExecuteAsync";
                                _model_pubsub.url = _uri;
                                _model_pubsub.responsedata = _response;
                                await _pubsubService.PublishMessagesAsync(_model_pubsub);

                                return _response;
                            }

                            //Todo:成功記錄普羅米修斯

                            _response.code = 0;
                            _response.status = "Successful";
                            _response.result = JsonSerializer.Deserialize<dynamic>(_data.result);
                            _response.additional = new { currency = _bodybalancescurrencycode, balance = _bodybalancesamount };
                        }
                        else if (_apicode == "vm")
                        {
                            _response.code = 9999;
                            _response.status = "This Operator does not support this function";

                            //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                            _model_pubsub.type = $"{_response.type} End [{_apicode}]CallBackAPI.ExecuteAsync";
                            _model_pubsub.url = _uri;
                            _model_pubsub.responsedata = _response;
                            await _pubsubService.PublishMessagesAsync(_model_pubsub);

                            return _response;
                        }
                        else
                        {
                            _response.code = 0;
                            _response.status = "Successful - external";
                        }

                        break;
                    case 1:
                        //呼叫SP
                        var _paras = new object[] { _model.data.usertoken, _model.data.transactionid, _model.data.roundid };
                        var _sp_response = await _mysql.CallSP<Model.TestMode_CancelAsyncResponse>("Membership.SP_MEMBERSHIP_DEDUCTION_POINT_UPD", _paras);

                        _response.code = _sp_response.code;
                        _response.status = _sp_response.status;

                        if (_response.code == 0)
                        {
                            Model.TestMode_CancelAsyncResponse _model_testmode_result = _sp_response.result[0];
                            switch (_model_testmode_result.Code)
                            {
                                case 1001:
                                    _response.status = "Token not exist";
                                    break;
                                case 1004:
                                    _response.status = "Transaction not exist";
                                    break;
                                case 1005:
                                    _response.status = "RoundId not exist";
                                    break;
                                case 1006:
                                    _response.status = "Round and Transaction are settle already";
                                    break;
                                case 0:
                                    _response.status = "Success";
                                    break;
                            }

                            _response.result = new { balance = _model_testmode_result.OldBalance, renew_balance = _model_testmode_result.Balance };
                        }
                        else
                        {
                            _response.result = new { balance = 0, renew_balance = 0 };
                        }
                        break;
                }

                //記錄LOG:API 呼叫記錄寫入 Pub/Sub(End)
                #region 記錄LOG:API 呼叫記錄寫入 Pub/Sub(End)
                _model_pubsub.type = $"{_response.type} End";
                _model_pubsub.url = _uri;
                _model_pubsub.responsedata = _response;
                await _pubsubService.PublishMessagesAsync(_model_pubsub);
                #endregion
            }
            catch (Exception ex)
            {
                _response.code = 9999;
                _response.status = ex.Message;

                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                _model_pubsub.type = $"{_response.type} Catch Exception";
                _model_pubsub.responsedata = _response;
                await _pubsubService.PublishMessagesAsync(_model_pubsub);
            }

            return _response;
        }

        /// <summary>
        /// 活動專用:老子有錢專用
        /// </summary>
        /// <param name="_model">Model.Vendor.EventRequest</param>
        /// <returns></returns>
        [HttpPost, Route("Event")]
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public async Task<Model.DefaultResponse> Event(Model.Vendor.EventRequest _model)
        {
            Model.DefaultResponse _response = new();
            Model.PubSubRequest _model_pubsub = new();
            _response.type = "Event";
            //設定記錄Pub/Sub相關參數
            _model_pubsub.merchantid = _model.data.merchantid;
            _model_pubsub.vcode = _model.data.vcode;
            _model_pubsub.gameid = _model.data.gameid;
            _model_pubsub.usertoken = _model.data.usertoken;
            _model_pubsub.sessiontoken = _model.data.sessiontoken;

            try
            {
                #region 驗證相關欄位並取得相關Table資料
                //設定驗證欄位
                var _verifyfields = "merchantid,vcode,gameid,usertoken";
                //取得相關Table資料(資料已Redis)
                var _vendordataresponse = await _vendorService.GetVendorData<Model.Vendor.EventRequest, Model.Vendor.EventRequestParams>(_model, _model.data, _verifyfields, _response, _model_pubsub);
                _response = _vendordataresponse.DefaultResponse;
                if (_response.code != 0) return _response;
                #endregion

                //取得相關Table資料
                var _vendoroperatoraccountmapping = _vendordataresponse.Redis_VendorOperatorAccountMapping;
                var _operatorimplementinfo = _vendordataresponse.Redis_OperatorImplementInfo;
                var _apicode = _vendordataresponse.ApiCode;
                var _operatorimplementinfosecretkey = _operatorimplementinfo.SecretKey;
                var _idoperator = _operatorimplementinfo.IdOperator;
                var _idvendor = _vendoroperatoraccountmapping.IdVendor;
                string _uri = _operatorimplementinfo.UrlEvent;
                string _newgameid = _vendordataresponse.NewGameID;
                _model_pubsub.url = _uri;

                switch (_vendoroperatoraccountmapping.TestMode)
                {
                    case 0:
                        Services.External.CallBackService _callback = new Services.External.CallBackService(_httpContextAccessor);

                        if (_apicode == "08online")
                        {
                            var _uid = StringHelper.makeTransactionId(16);
                            var _currenttime = DateTime.Now.ToString("yyyy/MM/dd HH:MM:ss");

                            var _formdata = new
                            {
                                reqid = _uid,
                                token = _model.data.usertoken,
                                eventId = 1
                            };
                            var _formhash = Utility.Encryptions.MD5_Generate(JsonSerializer.Serialize(_formdata) + _operatorimplementinfosecretkey);

                            var _request = new { data = _formdata, hash = _formhash };

                            #region 使用HttpClient呼叫API
                            var starttime = DateTime.Now;
                            var _data = await _callback.ExecuteAsync(_request, HttpMethod.Post, _uri, null, null);
                            //var _data = _callback.Execute(_request, HttpMethod.Get, _uri, null, null);
                            var endtime = DateTime.Now;
                            var apiresponsetime = (endtime - starttime).TotalMilliseconds / 1000;
                            #endregion

                            //取得API回傳result內各屬性的值
                            var dynamicObject = Newtonsoft.Json.JsonConvert.DeserializeObject<dynamic>(_data.result)!;
                            var _bodycode = dynamicObject.code.Value;
                            var _bodymessage = dynamicObject.message.Value;
                            var _bodyresultusername = dynamicObject.result.username.Value;
                            var _bodyresult = Newtonsoft.Json.JsonConvert.SerializeObject(dynamicObject.result);
                            var _balance = (_bodycode != 0) ? (int)_bodycode : 0;

                            if (_data.code != 200)
                            {
                                _response.code = _data.code;
                                _response.status = $"Failure - statusCode not 200({_data.code.ToString()})";

                                //Todo:失敗則記錄普羅米修斯

                                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                                _model_pubsub.type = $"{_response.type} End [{_apicode}]CallBackAPI.ExecuteAsync";
                                _model_pubsub.url = _uri;
                                _model_pubsub.responsedata = _response;
                                await _pubsubService.PublishMessagesAsync(_model_pubsub);
                            }
                            if (_response.code != 0) return _response;

                            //Todo:成功則記錄普羅米修斯

                            //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                            dynamic _dynamicrequest = new { idoperator = _idoperator, idvendor = _idvendor, username = _bodyresultusername };
                            await _pubsubService.PublishMessagesAsync(_dynamicrequest);

                            _response.code = 0;
                            _response.status = "Successful";
                            if (_bodycode != 0)
                            {
                                _response.code = (int)_bodycode;
                                _response.status = _bodymessage;
                            }
                            //_response.result = JsonSerializer.Deserialize<dynamic>(_bodyresult);
                            _response.result = _bodymessage;
                            _response.additional = new { balance = _balance };
                        }
                        else if (_apicode == "aceonline")
                        {
                            _response.code = 9999;
                            _response.status = "This Operator does not support this function";

                            //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                            _model_pubsub.type = $"{_response.type} End [{_apicode}]CallBackAPI.ExecuteAsync";
                            _model_pubsub.url = _uri;
                            _model_pubsub.responsedata = _response;
                            await _pubsubService.PublishMessagesAsync(_model_pubsub);

                            return _response;
                        }
                        else if (_apicode == "vm")
                        {
                            _response.code = 9999;
                            _response.status = "This Operator does not support this function";

                            //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                            _model_pubsub.type = $"{_response.type} End [{_apicode}]CallBackAPI.ExecuteAsync";
                            _model_pubsub.url = _uri;
                            _model_pubsub.responsedata = _response;
                            await _pubsubService.PublishMessagesAsync(_model_pubsub);

                            return _response;
                        }
                        else
                        {
                            _response.code = 0;
                            _response.status = "Successful - external";
                        }
                        break;
                    case 1:
                        //Node.js版本無TestMode
                        _response.code = 0;
                        _response.status = "Successful - test mode";
                        break;
                }

                //記錄LOG:API 呼叫記錄寫入 Pub/Sub(End)
                #region 記錄LOG:API 呼叫記錄寫入 Pub/Sub(End)
                _model_pubsub.type = $"{_response.type} End";
                _model_pubsub.url = _uri;
                _model_pubsub.responsedata = _response;
                await _pubsubService.PublishMessagesAsync(_model_pubsub);
                #endregion
            }
            catch (Exception ex)
            {
                _response.code = 9999;
                _response.status = ex.Message;

                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                _model_pubsub.type = $"{_response.type} End Catch Exception";
                _model_pubsub.responsedata = _response;
                await _pubsubService.PublishMessagesAsync(_model_pubsub);
            }

            return _response;
        }

        /// <summary>
        /// 取得遊戲帳號目前餘額
        /// </summary>
        /// <param name="_model">Model.Vendor.BalanceRequest</param>
        /// <returns></returns>
        [HttpPost, Route("Balance")]
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public async Task<Model.DefaultResponse> Balance(Model.Vendor.BalanceRequest _model)
        {
            Model.DefaultResponse _response = new();
            Model.PubSubRequest _model_pubsub = new();
            _response.type = "getBalance";
            //設定記錄Pub/Sub相關參數
            _model_pubsub.merchantid = _model.data.merchantid;
            _model_pubsub.vcode = _model.data.vcode;
            _model_pubsub.usertoken = _model.data.usertoken;
            _model_pubsub.sessiontoken = _model.data.sessiontoken;
            _model_pubsub.userid = _model.data.userid;

            try
            {
                #region 驗證相關欄位並取得相關Table資料
                //設定驗證欄位
                var _verifyfields = "merchantid,vcode,usertoken";
                //取得相關Table資料(資料已Redis)
                var _vendordataresponse = await _vendorService.GetVendorData<Model.Vendor.BalanceRequest, Model.Vendor.BalanceRequestParams>(_model, _model.data, _verifyfields, _response, _model_pubsub);
                _response = _vendordataresponse.DefaultResponse;
                if (_response.code != 0) return _response;
                #endregion

                //取得相關Table資料
                var _vendoroperatoraccountmapping = _vendordataresponse.Redis_VendorOperatorAccountMapping;
                var _operatorimplementinfo = _vendordataresponse.Redis_OperatorImplementInfo;
                var _operatorimplementinfosecretkey = _operatorimplementinfo.SecretKey;
                var _apicode = _vendordataresponse.ApiCode;
                string _uri = _operatorimplementinfo.UrlBalance;
                string _newgameid = _vendordataresponse.NewGameID;
                _model_pubsub.url = _uri;

                switch (_vendoroperatoraccountmapping.TestMode)
                {
                    case 0:
                        Services.External.CallBackService _callback = new Services.External.CallBackService(_httpContextAccessor);

                        if (_apicode == "08online" || _apicode == "08online-exp")
                        {
                            var _uid = StringHelper.makeTransactionId(16);

                            var _formdata = new
                            {
                                reqid = _uid,
                                token = _model.data.usertoken,
                                eventid = _model.data.eventid
                            };
                            var _formhash = Utility.Encryptions.MD5_Generate(JsonSerializer.Serialize(_formdata) + _operatorimplementinfosecretkey);

                            var _request = new { data = _formdata, hash = _formhash };

                            #region 使用HttpClient呼叫API
                            var starttime = DateTime.Now;
                            var _data = await _callback.ExecuteAsync(_request, HttpMethod.Post, _uri, null, null);
                            //var _data = _callback.Execute(_request, HttpMethod.Post, _uri, null, null);
                            var endtime = DateTime.Now;
                            var apiresponsetime = (endtime - starttime).TotalMilliseconds / 1000;
                            #endregion

                            //取得API回傳result內各屬性的值
                            var dynamicObject = Newtonsoft.Json.JsonConvert.DeserializeObject<dynamic>(_data.result)!;
                            var _bodycode = dynamicObject.code.Value;
                            var _bodymessage = dynamicObject.message.Value;
                            var _bodyresult = Newtonsoft.Json.JsonConvert.SerializeObject(dynamicObject.result);

                            if (_data.code != 200)
                            {
                                _response.code = _data.code;
                                _response.status = $"Failure - statusCode not 200({_bodycode.ToString()})";

                                //Todo:失敗則記錄普羅米修斯

                                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                                _model_pubsub.type = $"{_response.type} End [{_apicode}]CallBackAPI.ExecuteAsync";
                                _model_pubsub.url = _uri;
                                _model_pubsub.responsedata = _response;
                                await _pubsubService.PublishMessagesAsync(_model_pubsub);
                            }
                            if (_response.code != 0) return _response;

                            //Todo:成功記錄普羅米修斯

                            _response.code = 0;
                            _response.status = "Successful";
                            if (_bodycode != 0)
                            {
                                _response.code = (int)_bodycode;
                                _response.status = _bodymessage;
                            }
                            _response.result = JsonSerializer.Deserialize<dynamic>(_bodyresult);
                        }
                        else if (_apicode == "aceonline")
                        {
                            string[] headers = { "x-api-key" };
                            string[] values = { "e495964cb27748859d1060f53a2d3ba2" };

                            var _request = new
                            {
                                userId = _model.data.userid,
                                accountToken = _model.data.usertoken
                            };

                            #region 使用HttpClient呼叫API
                            var starttime = DateTime.Now;
                            var _data = await _callback.ExecuteAsync(_request, HttpMethod.Post, _uri, headers, values);
                            //var _data = _callback.Execute(_request, HttpMethod.Post, _uri, headers, values);
                            var endtime = DateTime.Now;
                            var apiresponsetime = (endtime - starttime).TotalMilliseconds / 1000;
                            #endregion

                            //取得API回傳result內各屬性的值
                            var dynamicObject = Newtonsoft.Json.JsonConvert.DeserializeObject<dynamic>(_data.result)!;
                            var _bodystatuscode = dynamicObject.statusCode.Value;
                            var _bodyaccounttoken = dynamicObject.accountToken.Value;
                            var _bodybalancescurrencycode = dynamicObject.balances[0].currencyCode.Value;
                            var _bodybalancesamount = dynamicObject.balances[0].amount.Value;

                            if (_data.code != 200)
                            {
                                _response.code = _data.code;
                                _response.status = $"Failure - statusCode not 200({_bodystatuscode.ToString()})";

                                //Todo:失敗則記錄普羅米修斯

                                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                                _model_pubsub.type = $"{_response.type} End [{_apicode}]CallBackAPI.ExecuteAsync";
                                _model_pubsub.url = _uri;
                                _model_pubsub.responsedata = _response;
                                await _pubsubService.PublishMessagesAsync(_model_pubsub);
                            }
                            if (_response.code != 0) return _response;

                            if (_bodystatuscode == "RS_ERROR_SYSTEM_IN_MAINTAIN")
                            {
                                _response.code = 9998;
                            }
                            else if (_bodystatuscode == "RS_ERROR_INVALID_USER_TOKEN" || _bodystatuscode == "RS_ERROR_INVALID_ACCOUNT_TOKEN")
                            {
                                _response.code = 9997;
                            }
                            if (_response.code != 0)
                            {
                                _response.status = $"Failure - body statusCode:({_bodystatuscode})";

                                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                                _model_pubsub.type = $"{_response.type} End [{_apicode}]CallBackAPI.ExecuteAsync";
                                _model_pubsub.url = _uri;
                                _model_pubsub.responsedata = _response;
                                await _pubsubService.PublishMessagesAsync(_model_pubsub);

                                return _response;
                            }

                            //Todo:成功記錄普羅米修斯

                            _response.code = 0;
                            _response.status = "Successful";
                            _response.result = JsonSerializer.Deserialize<dynamic>(_data.result);
                            _response.additional = new { currency = _bodybalancescurrencycode, balance = _bodybalancesamount };
                        }
                        else if (_apicode == "vm")
                        {
                            _uri = _uri.Replace("{user_token}", _model.data.usertoken);
                            _uri = _uri.Replace("{session_token}", _model.data.sessiontoken);

                            var _request = new { };

                            #region 使用HttpClient呼叫API
                            var starttime = DateTime.Now;
                            var _data = await _callback.ExecuteAsync(_request, HttpMethod.Get, _uri, null, null);
                            //var _data = _callback.Execute(_request, HttpMethod.Post, _uri, null, null);
                            var endtime = DateTime.Now;
                            var apiresponsetime = (endtime - starttime).TotalMilliseconds / 1000;
                            #endregion

                            //取得API回傳result內各屬性的值
                            var dynamicObject = Newtonsoft.Json.JsonConvert.DeserializeObject<dynamic>(_data.result)!;
                            var _bodysessiontoken = dynamicObject.SessionToken.Value;

                            if (_data.code != 200)
                            {
                                _response.code = _data.code;
                                _response.status = $"Failure - statusCode not 200({_data.code.ToString()})";

                                //Todo:失敗則記錄普羅米修斯

                                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                                _model_pubsub.type = $"{_response.type} End [{_apicode}]CallBackAPI.ExecuteAsync";
                                _model_pubsub.url = _uri;
                                _model_pubsub.responsedata = _response;
                                await _pubsubService.PublishMessagesAsync(_model_pubsub);
                            }
                            if (_response.code != 0) return _response;

                            //Todo:成功記錄普羅米修斯

                            _response.code = 0;
                            _response.status = "Successful";
                            _response.result = JsonSerializer.Deserialize<dynamic>(_data.result);
                        }
                        else
                        {
                            _response.code = 0;
                            _response.status = "Successful - external";
                        }

                        break;
                    case 1:
                        //呼叫SP
                        var _paras = new object[] { _model.data.usertoken };
                        var _sp_response = await _mysql.CallSP<Model.TestMode_GetBalanceAsyncResponse>("Membership.SP_MEMBERSHIP_BALANCE_GET", _paras);

                        _response.code = _sp_response.code;
                        _response.status = _sp_response.status;

                        if (_response.code == 0)
                        {
                            Model.TestMode_GetBalanceAsyncResponse _model_testmode_result = _sp_response.result[0];

                            _response.result = new { balance = _model_testmode_result.Balance };
                        }
                        else
                        {
                            _response.result = new { balance = 0 };
                        }
                        break;
                }

                //記錄LOG:API 呼叫記錄寫入 Pub/Sub(End)
                #region 記錄LOG:API 呼叫記錄寫入 Pub/Sub(End)
                _model_pubsub.type = $"{_response.type} End";
                _model_pubsub.url = _uri;
                _model_pubsub.responsedata = _response;
                await _pubsubService.PublishMessagesAsync(_model_pubsub);
                #endregion
            }
            catch (Exception ex)
            {
                _response.code = 9999;
                _response.status = ex.Message;

                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                _model_pubsub.type = $"{_response.type} End Catch Exception";
                _model_pubsub.responsedata = _response;
                await _pubsubService.PublishMessagesAsync(_model_pubsub);
            }

            return _response;
        }

        /// <summary>
        /// 通知平台商端目前玩家是否持續在線 - 支援之平台商端請參考 API 文件說明
        /// </summary>
        /// <param name="_model">Model.Vendor.KeepAliveRequest</param>
        /// <returns></returns>
        [HttpPost, Route("KeepAlive")]
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public async Task<Model.DefaultResponse> KeepAlive(Model.Vendor.KeepAliveRequest _model)
        {
            Model.DefaultResponse _response = new();
            Model.PubSubRequest _model_pubsub = new();
            _response.type = "KeepAlive";
            //設定記錄Pub/Sub相關參數
            _model_pubsub.merchantid = _model.data.merchantid;
            _model_pubsub.vcode = _model.data.vcode;
            _model_pubsub.usertoken = _model.data.usertoken;
            _model_pubsub.sessiontoken = _model.data.sessiontoken;

            try
            {
                #region 驗證相關欄位並取得相關Table資料
                //設定驗證欄位
                var _verifyfields = "merchantid,vcode,usertoken";
                //取得相關Table資料(資料已Redis)
                var _vendordataresponse = await _vendorService.GetVendorData<Model.Vendor.KeepAliveRequest, Model.Vendor.KeepAliveRequestParams>(_model, _model.data, _verifyfields, _response, _model_pubsub);
                _response = _vendordataresponse.DefaultResponse;
                if (_response.code != 0) return _response;
                #endregion

                //取得相關Table資料
                var _vendoroperatoraccountmapping = _vendordataresponse.Redis_VendorOperatorAccountMapping;
                var _operatorimplementinfo = _vendordataresponse.Redis_OperatorImplementInfo;
                var _operatorimplementinfosecretkey = _operatorimplementinfo.SecretKey;
                var _apicode = _vendordataresponse.ApiCode;
                string _uri = _operatorimplementinfo.UrlKeepAlive;
                string _newgameid = _vendordataresponse.NewGameID;
                _model_pubsub.url = _uri;

                switch (_vendoroperatoraccountmapping.TestMode)
                {
                    case 0:
                        Services.External.CallBackService _callback = new Services.External.CallBackService(_httpContextAccessor);

                        if (_apicode == "08online" || _apicode == "08online-exp")
                        {
                            _response.code = 9999;
                            _response.status = "This Operator does not support this function";

                            //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                            _model_pubsub.type = $"{_response.type} End [{_apicode}]CallBackAPI.ExecuteAsync";
                            _model_pubsub.url = _uri;
                            _model_pubsub.responsedata = _response;
                            await _pubsubService.PublishMessagesAsync(_model_pubsub);

                            return _response;
                        }
                        else if (_apicode == "aceonline")
                        {
                            _response.code = 9999;
                            _response.status = "This Operator does not support this function";

                            //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                            _model_pubsub.type = $"{_response.type} End [{_apicode}]CallBackAPI.ExecuteAsync";
                            _model_pubsub.url = _uri;
                            _model_pubsub.responsedata = _response;
                            await _pubsubService.PublishMessagesAsync(_model_pubsub);

                            return _response;
                        }
                        else if (_apicode == "vm")
                        {
                            _uri = _uri.Replace("{user_token}", _model.data.usertoken);
                            _uri = _uri.Replace("{session_token}", _model.data.sessiontoken);

                            var _request = new { };

                            #region 使用HttpClient呼叫API
                            var starttime = DateTime.Now;
                            var _data = await _callback.ExecuteAsync(_request, HttpMethod.Get, _uri, null, null);
                            //var _data = _callback.Execute(_request, HttpMethod.Post, _uri, null, null);
                            var endtime = DateTime.Now;
                            var apiresponsetime = (endtime - starttime).TotalMilliseconds / 1000;
                            #endregion

                            //取得API回傳result內各屬性的值
                            //var dynamicObject = Newtonsoft.Json.JsonConvert.DeserializeObject<dynamic>(_data.result)!;
                            //var _bodysessiontoken = dynamicObject.SessionToken.Value;

                            if (_data.code != 200)
                            {
                                _response.code = _data.code;
                                _response.status = $"Failure - statusCode not 200({_data.code.ToString()})";

                                //Todo:失敗則記錄普羅米修斯

                                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                                _model_pubsub.type = $"{_response.type} End [{_apicode}]CallBackAPI.ExecuteAsync";
                                _model_pubsub.url = _uri;
                                _model_pubsub.responsedata = _response;
                                await _pubsubService.PublishMessagesAsync(_model_pubsub);
                            }
                            if (_response.code != 0) return _response;

                            //Todo:成功記錄普羅米修斯

                            _response.code = 0;
                            _response.status = "Successful";
                            _response.result = JsonSerializer.Deserialize<dynamic>(_data.result);
                        }
                        else
                        {
                            _response.code = 0;
                            _response.status = "Successful - external";
                        }

                        break;
                    case 1:
                        //Node.js版本無TestMode
                        _response.code = 0;
                        _response.status = "Successful - test mode";
                        break;
                }

                //記錄LOG:API 呼叫記錄寫入 Pub/Sub(End)
                #region 記錄LOG:API 呼叫記錄寫入 Pub/Sub(End)
                _model_pubsub.type = $"{_response.type} End";
                _model_pubsub.url = _uri;
                _model_pubsub.responsedata = _response;
                await _pubsubService.PublishMessagesAsync(_model_pubsub);
                #endregion
            }
            catch (Exception ex)
            {
                _response.code = 9999;
                _response.status = ex.Message;

                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                _model_pubsub.type = $"{_response.type} End Catch Exception";
                _model_pubsub.responsedata = _response;
                await _pubsubService.PublishMessagesAsync(_model_pubsub);
            }

            return _response;
        }

        /// <summary>
        /// 登出
        /// </summary>
        /// <param name="_model">Model.Vendor.LogoutRequest</param>
        /// <returns></returns>
        [HttpPost, Route("Logout")]
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public async Task<Model.DefaultResponse> Logout(Model.Vendor.LogoutRequest _model)
        {
            Model.DefaultResponse _response = new();
            Model.PubSubRequest _model_pubsub = new();
            _response.type = "Logout";
            //設定記錄Pub/Sub相關參數
            _model_pubsub.merchantid = _model.data.merchantid;
            _model_pubsub.vcode = _model.data.vcode;
            _model_pubsub.usertoken = _model.data.usertoken;
            _model_pubsub.sessiontoken = _model.data.sessiontoken;

            try
            {
                #region 驗證相關欄位並取得相關Table資料
                //設定驗證欄位
                var _verifyfields = "merchantid,vcode,usertoken";
                //取得相關Table資料(資料已Redis)
                var _vendordataresponse = await _vendorService.GetVendorData<Model.Vendor.LogoutRequest, Model.Vendor.LogoutRequestParams>(_model, _model.data, _verifyfields, _response, _model_pubsub);
                _response = _vendordataresponse.DefaultResponse;
                if (_response.code != 0) return _response;
                #endregion

                //取得相關Table資料
                var _vendoroperatoraccountmapping = _vendordataresponse.Redis_VendorOperatorAccountMapping;
                var _operatorimplementinfo = _vendordataresponse.Redis_OperatorImplementInfo;
                var _operatorimplementinfosecretkey = _operatorimplementinfo.SecretKey;
                var _apicode = _vendordataresponse.ApiCode;
                string _uri = _operatorimplementinfo.UrlLogout;
                string _newgameid = _vendordataresponse.NewGameID;
                _model_pubsub.url = _uri;

                switch (_vendoroperatoraccountmapping.TestMode)
                {
                    case 0:
                        Services.External.CallBackService _callback = new Services.External.CallBackService(_httpContextAccessor);

                        if (_apicode == "08online")
                        {
                            _response.code = 9999;
                            _response.status = "This Operator does not support this function";

                            //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                            _model_pubsub.type = $"{_response.type} End [{_apicode}]CallBackAPI.ExecuteAsync";
                            _model_pubsub.url = _uri;
                            _model_pubsub.responsedata = _response;
                            await _pubsubService.PublishMessagesAsync(_model_pubsub);

                            return _response;
                        }
                        else if (_apicode == "aceonline")
                        {
                            _response.code = 9999;
                            _response.status = "This Operator does not support this function";

                            //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                            _model_pubsub.type = $"{_response.type} End [{_apicode}]CallBackAPI.ExecuteAsync";
                            _model_pubsub.url = _uri;
                            _model_pubsub.responsedata = _response;
                            await _pubsubService.PublishMessagesAsync(_model_pubsub);

                            return _response;
                        }
                        else if (_apicode == "vm")
                        {
                            _uri = _uri.Replace("{user_token}", _model.data.usertoken);
                            _uri = _uri.Replace("{session_token}", _model.data.sessiontoken);

                            var _request = new { };

                            #region 使用HttpClient呼叫API
                            var starttime = DateTime.Now;
                            var _data = await _callback.ExecuteAsync(_request, HttpMethod.Post, _uri, null, null);
                            //var _data = _callback.Execute(_request, HttpMethod.Post, _uri, null, null);
                            var endtime = DateTime.Now;
                            var apiresponsetime = (endtime - starttime).TotalMilliseconds / 1000;
                            #endregion

                            //取得API回傳result內各屬性的值
                            var dynamicObject = Newtonsoft.Json.JsonConvert.DeserializeObject<dynamic>(_data.result)!;
                            var _bodyusertoken = dynamicObject.UserToken.Value;
                            var _bodysessiontoken = dynamicObject.SessionToken.Value;
                            var _bodygameidentity = dynamicObject.GameIdentity.Value;
                            var _bodylanguage = dynamicObject.Language.Value;
                            var _bodyplayer = dynamicObject.Player.Value;

                            if (_data.code != 200)
                            {
                                _response.code = _data.code;
                                _response.status = $"Failure - statusCode not 200({_data.code.ToString()})";

                                //Todo:失敗則記錄普羅米修斯

                                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                                _model_pubsub.type = $"{_response.type} End [{_apicode}]CallBackAPI.ExecuteAsync";
                                _model_pubsub.url = _uri;
                                _model_pubsub.responsedata = _response;
                                await _pubsubService.PublishMessagesAsync(_model_pubsub);
                            }
                            if (_response.code != 0) return _response;

                            //Todo:成功記錄普羅米修斯

                            _response.code = 0;
                            _response.status = "Successful";
                            _response.result = JsonSerializer.Deserialize<dynamic>(_data.result);
                            _response.additional = new { UserTOken = _bodyusertoken, SessionToken = _bodysessiontoken, GameId = _bodygameidentity, Language = _bodylanguage, Player = _bodyplayer };
                        }
                        else
                        {
                            _response.code = 0;
                            _response.status = "Successful - external";
                        }

                        break;
                    case 1:
                        //Node.js版本無TestMode
                        _response.code = 0;
                        _response.status = "Successful - test mode";
                        break;
                }

                //記錄LOG:API 呼叫記錄寫入 Pub/Sub(End)
                #region 記錄LOG:API 呼叫記錄寫入 Pub/Sub(End)
                _model_pubsub.type = $"{_response.type} End";
                _model_pubsub.url = _uri;
                _model_pubsub.responsedata = _response;
                await _pubsubService.PublishMessagesAsync(_model_pubsub);
                #endregion
            }
            catch (Exception ex)
            {
                _response.code = 9999;
                _response.status = ex.Message;

                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                _model_pubsub.type = $"{_response.type} End Catch Exception";
                _model_pubsub.responsedata = _response;
                await _pubsubService.PublishMessagesAsync(_model_pubsub);
            }

            return _response;
        }

        #endregion

        #region Health Check

        /// <summary>
        /// DB health check
        /// </summary>
        /// <param name="_model">Model.Vendor.DBHealthzRequest</param>
        /// <returns></returns>
        [HttpPost, Route("dbhealthz")]
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public async Task<Model.DefaultResponse> DBHealthz(Model.Vendor.DBHealthzRequest _model)
        {
            Model.DefaultResponse _response = new Model.DefaultResponse();
            string _secretkey = _configuration["ConnectionSecretKey"];

            try
            {
                //驗證Request的值(_model)
                _response = VerifyReqParams<Model.Vendor.DBHealthzRequest>.verifyReqParams(_response, _model, "guid,hash");
                if (_response.code != 0) return _response;

                //判斷Hash是否正確
                string _realhash = Utility.Encryptions.MD5_Generate(_model.guid + _secretkey);
                if (_model.hash != _realhash)
                {
                    _response.code = 1006;
                    _response.status = "Hash Error:" + _realhash;
                    return _response;
                }

                //判斷DB連線是否正常
                if (await _manufacturercmscontext.Database.CanConnectAsync())
                {
                    _response.code = 0;
                    _response.status = "ok!";
                }
                else
                {
                    _response.code = 9999;
                    _response.status = "DBhealthzPromise rejected!";
                }
            }
            catch (Exception ex)
            {
                _response.code = 9999;
                _response.status = ex.Message;
            }

            return _response;
        }

        /// <summary>
        /// Health check
        /// </summary>
        /// <returns></returns>
        [HttpPost, Route("healthz")]
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public Model.DefaultResponse Healthz()
        {
            Model.DefaultResponse _response = new Model.DefaultResponse();

            _response.code = 0;
            _response.status = "ok!";

            return _response;
        }

        #endregion
    }
}
