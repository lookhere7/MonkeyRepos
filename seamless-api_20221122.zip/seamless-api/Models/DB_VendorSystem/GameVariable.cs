﻿using System;
using System.Collections.Generic;

namespace Seamless.Core.API.Models.DB_VendorSystem
{
    public partial class GameVariable
    {
        public int Id { get; set; }
        public int? GameId { get; set; }
        public string ParameterName { get; set; }
        public string ParameterValue { get; set; }
        public sbyte? Status { get; set; }
    }
}
