﻿using System;
using System.Collections.Generic;

namespace Seamless.Core.API.Models.DB_VendorSystem
{
    public partial class ConfigOfBetDetail
    {
        public int Id { get; set; }
        /// <summary>
        /// 遊戲商 ID
        /// </summary>
        public bool? VendorId { get; set; }
        /// <summary>
        /// 遊戲 ID
        /// </summary>
        public int? GameId { get; set; }
        /// <summary>
        /// VendorSystem.GameTypes 對應遊戲的 TypeName
        /// </summary>
        public string TypeName { get; set; }
        /// <summary>
        /// 原始資料的主 key
        /// </summary>
        public string Key { get; set; }
        /// <summary>
        /// 主 Key 下的屬性 1
        /// </summary>
        public string MainPath { get; set; }
        /// <summary>
        /// 主 Key 下的屬性 2
        /// </summary>
        public string SubPath { get; set; }
        /// <summary>
        /// 是否啟用
        /// </summary>
        public bool? Active { get; set; }
    }
}
