﻿using System;
using System.Collections.Generic;

namespace Seamless.Core.API.Models.DB_VendorSystem
{
    public partial class GameType
    {
        public int Id { get; set; }
        /// <summary>
        /// 遊戲商系統編號
        /// </summary>
        public int? IdVendor { get; set; }
        /// <summary>
        /// 類別系統名稱
        /// </summary>
        public string TypeName { get; set; }
        /// <summary>
        /// 類別值
        /// </summary>
        public string TypeValue { get; set; }
        /// <summary>
        /// 說明
        /// </summary>
        public string Description { get; set; }
        /// <summary>
        /// 是否啟用
        /// </summary>
        public sbyte? Active { get; set; }
    }
}
