﻿using System;
using System.Collections.Generic;

namespace Seamless.Core.API.Models.DB_VendorSystem
{
    public partial class VendorVariable
    {
        public int Id { get; set; }
        public int? VendorId { get; set; }
        public int? OperatorId { get; set; }
        public string ParameterName { get; set; }
        public string ParameterValue { get; set; }
        public sbyte? Status { get; set; }
        public DateTime? LatestModifyDateTime { get; set; }
        public DateTime? CreateDate { get; set; }
    }
}
