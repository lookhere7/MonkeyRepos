﻿using System;
using System.Collections.Generic;

namespace Seamless.Core.API.Models.DB_VendorSystem
{
    public partial class SeamlessLog
    {
        public long IdLogs { get; set; }
        public string Type { get; set; }
        public string Url { get; set; }
        public string MerchantId { get; set; }
        public string Vcode { get; set; }
        public string UserToken { get; set; }
        public string SessionToken { get; set; }
        public string UserId { get; set; }
        public string Wallet { get; set; }
        public string Amount { get; set; }
        public string GameId { get; set; }
        public string RoundId { get; set; }
        public string Currency { get; set; }
        public string BetAmount { get; set; }
        public string WinAmount { get; set; }
        public string End { get; set; }
        public string TransactionId { get; set; }
        public string BetTime { get; set; }
        public string Transfer { get; set; }
        public string External { get; set; }
        public string Balance { get; set; }
        public string Offlinetagamount { get; set; }
        public string Detail { get; set; }
        public string ResponseData { get; set; }
        public DateTime? CreateDate { get; set; }
    }
}
