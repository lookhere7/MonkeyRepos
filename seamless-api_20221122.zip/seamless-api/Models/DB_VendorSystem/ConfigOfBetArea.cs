﻿using System;
using System.Collections.Generic;

namespace Seamless.Core.API.Models.DB_VendorSystem
{
    public partial class ConfigOfBetArea
    {
        public int Id { get; set; }
        /// <summary>
        /// 遊戲商ID
        /// </summary>
        public string IdVendor { get; set; }
        /// <summary>
        /// 遊戲代碼
        /// </summary>
        public string GameCode { get; set; }
        /// <summary>
        /// 等於GameTypes的描述內容
        /// </summary>
        public string Description { get; set; }
        /// <summary>
        /// 遊戲熱門度群組名稱
        /// </summary>
        public string GroupName { get; set; }
        /// <summary>
        /// 群組 Index
        /// </summary>
        public int? TypeIndex { get; set; }
        public int? Active { get; set; }
    }
}
