﻿using System;
using System.Collections.Generic;

namespace Seamless.Core.API.Models.DB_VendorSystem
{
    public partial class DescriptionMapping
    {
        public int Id { get; set; }
        public string Description1 { get; set; }
        public string Description2 { get; set; }
    }
}
