﻿using System;
using System.Collections.Generic;

namespace Seamless.Core.API.Models.DB_VendorSystem
{
    public partial class SeamlessLoginLog
    {
        public long Id { get; set; }
        public string MerchantId { get; set; }
        public string UserToken { get; set; }
        public string SessionToken { get; set; }
        public string LicenseeId { get; set; }
        public string Vcode { get; set; }
        public string GameId { get; set; }
        public string ConfigurationId { get; set; }
        public string Language { get; set; }
        public string LaunchFrom { get; set; }
        public string BundleSdk { get; set; }
        public string Vip { get; set; }
        public string Currency { get; set; }
        public DateTime? CreateDate { get; set; }
    }
}
