﻿using System;
using System.Collections.Generic;

namespace Seamless.Core.API.Models.DB_VendorSystem
{
    public partial class OpenApiDoc
    {
        public int Id { get; set; }
        /// <summary>
        /// 0:共用;
        /// 1:遊戲商;
        /// 2:平台商;
        /// </summary>
        public int? Provider { get; set; }
        /// <summary>
        /// api route
        /// </summary>
        public string Path { get; set; }
        /// <summary>
        /// http method
        /// </summary>
        public string Method { get; set; }
        /// <summary>
        /// api 概述
        /// </summary>
        public string Summary { get; set; }
        /// <summary>
        /// api 類別
        /// </summary>
        public string Tags { get; set; }
        /// <summary>
        /// api 描述
        /// </summary>
        public string Description { get; set; }
        /// <summary>
        /// open api document 輸入格式
        /// </summary>
        public string Request { get; set; }
        /// <summary>
        /// open api document 輸出格式
        /// </summary>
        public string Response { get; set; }
        /// <summary>
        /// api 是否 jwt 驗證
        /// </summary>
        public int? Bearer { get; set; }
        public int? Active { get; set; }
    }
}
