﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.Extensions.Configuration;
using System.IO;
using System.Linq;

namespace Seamless.Core.API.Models.DB_VendorSystem
{
    public partial class VendorSystemContext : DbContext
    {
        public VendorSystemContext()
        {
        }

        public VendorSystemContext(DbContextOptions<VendorSystemContext> options)
            : base(options)
        {
        }

        public virtual DbSet<CardType> CardTypes { get; set; }
        public virtual DbSet<ConfigOfBetArea> ConfigOfBetAreas { get; set; }
        public virtual DbSet<ConfigOfBetAreaAndSuperNumber> ConfigOfBetAreaAndSuperNumbers { get; set; }
        public virtual DbSet<ConfigOfBetDetail> ConfigOfBetDetails { get; set; }
        public virtual DbSet<DescriptionMapping> DescriptionMappings { get; set; }
        public virtual DbSet<GameType> GameTypes { get; set; }
        public virtual DbSet<GameVariable> GameVariables { get; set; }
        public virtual DbSet<OpenApiDoc> OpenApiDocs { get; set; }
        public virtual DbSet<SeamlessExecuteLog> SeamlessExecuteLogs { get; set; }
        public virtual DbSet<SeamlessLog> SeamlessLogs { get; set; }
        public virtual DbSet<SeamlessLoginLog> SeamlessLoginLogs { get; set; }
        public virtual DbSet<SuperNumber> SuperNumbers { get; set; }
        public virtual DbSet<VendorVariable> VendorVariables { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                var builder = new ConfigurationBuilder()
                                  .SetBasePath(Directory.GetCurrentDirectory())
                                  .AddJsonFile("appsettings.json");
                var config = builder.Build();

                optionsBuilder.UseMySql(config.GetConnectionString("Connection_VendorSystem"), Microsoft.EntityFrameworkCore.ServerVersion.Parse("5.7.36-mysql"));
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.UseCollation("utf8_general_ci")
                .HasCharSet("utf8");

            modelBuilder.Entity<CardType>(entity =>
            {
                entity.Property(e => e.Id).HasColumnType("int(11)");

                entity.Property(e => e.Description).HasMaxLength(50);

                entity.Property(e => e.GameId)
                    .HasColumnType("int(11)")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.IdVendor)
                    .HasColumnType("int(11)")
                    .HasColumnName("Id_Vendor")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.Key).HasMaxLength(30);

                entity.Property(e => e.Key1).HasMaxLength(30);

                entity.Property(e => e.Key2).HasMaxLength(30);

                entity.Property(e => e.Status)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.Value).HasMaxLength(30);

                entity.Property(e => e.Value1).HasMaxLength(30);

                entity.Property(e => e.Value2).HasMaxLength(30);
            });

            modelBuilder.Entity<ConfigOfBetArea>(entity =>
            {
                entity.ToTable("ConfigOfBetArea");

                entity.Property(e => e.Id).HasColumnType("int(11)");

                entity.Property(e => e.Active).HasColumnType("int(11)");

                entity.Property(e => e.Description)
                    .HasMaxLength(45)
                    .HasComment("等於GameTypes的描述內容");

                entity.Property(e => e.GameCode)
                    .HasMaxLength(45)
                    .HasComment("遊戲代碼");

                entity.Property(e => e.GroupName)
                    .HasMaxLength(45)
                    .HasComment("遊戲熱門度群組名稱");

                entity.Property(e => e.IdVendor)
                    .HasMaxLength(45)
                    .HasColumnName("Id_Vendor")
                    .HasComment("遊戲商ID");

                entity.Property(e => e.TypeIndex)
                    .HasColumnType("int(11)")
                    .HasComment("群組 Index");
            });

            modelBuilder.Entity<ConfigOfBetAreaAndSuperNumber>(entity =>
            {
                entity.ToTable("ConfigOfBetAreaAndSuperNumber");

                entity.Property(e => e.Id).HasColumnType("int(11)");

                entity.Property(e => e.Active).HasDefaultValueSql("'1'");

                entity.Property(e => e.Description)
                    .HasMaxLength(45)
                    .HasComment("等於GameTypes的描述內容");

                entity.Property(e => e.GameCode)
                    .HasMaxLength(45)
                    .HasComment("遊戲代碼");

                entity.Property(e => e.GroupName)
                    .HasMaxLength(45)
                    .HasComment("遊戲熱門度群組名稱");

                entity.Property(e => e.IdVendor)
                    .HasMaxLength(45)
                    .HasColumnName("Id_Vendor")
                    .HasComment("遊戲商ID");

                entity.Property(e => e.IsSuperNumber)
                    .HasMaxLength(3)
                    .HasComment("是超級號碼嗎？");

                entity.Property(e => e.LanguageId).HasDefaultValueSql("'0'");

                entity.Property(e => e.TypeIndex)
                    .HasColumnType("tinyint(2)")
                    .HasComment("群組 Index");
            });

            modelBuilder.Entity<ConfigOfBetDetail>(entity =>
            {
                entity.ToTable("ConfigOfBetDetail");

                entity.Property(e => e.Id).HasColumnType("int(11)");

                entity.Property(e => e.Active)
                    .HasDefaultValueSql("'1'")
                    .HasComment("是否啟用");

                entity.Property(e => e.GameId)
                    .HasColumnType("int(11)")
                    .HasComment("遊戲 ID");

                entity.Property(e => e.Key)
                    .HasMaxLength(45)
                    .HasColumnName("_Key")
                    .HasComment("原始資料的主 key");

                entity.Property(e => e.MainPath)
                    .HasMaxLength(20)
                    .HasComment("主 Key 下的屬性 1");

                entity.Property(e => e.SubPath)
                    .HasMaxLength(100)
                    .HasComment("主 Key 下的屬性 2");

                entity.Property(e => e.TypeName)
                    .HasMaxLength(45)
                    .HasComment("VendorSystem.GameTypes 對應遊戲的 TypeName");

                entity.Property(e => e.VendorId).HasComment("遊戲商 ID");
            });

            modelBuilder.Entity<DescriptionMapping>(entity =>
            {
                entity.ToTable("DescriptionMapping");

                entity.Property(e => e.Id).HasColumnType("int(11)");

                entity.Property(e => e.Description1).HasMaxLength(45);

                entity.Property(e => e.Description2).HasMaxLength(45);
            });

            modelBuilder.Entity<GameType>(entity =>
            {
                entity.Property(e => e.Id).HasColumnType("int(11)");

                entity.Property(e => e.Active)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'0'")
                    .HasComment("是否啟用");

                entity.Property(e => e.Description)
                    .HasMaxLength(100)
                    .HasComment("說明");

                entity.Property(e => e.IdVendor)
                    .HasColumnType("int(11)")
                    .HasColumnName("Id_Vendor")
                    .HasDefaultValueSql("'0'")
                    .HasComment("遊戲商系統編號");

                entity.Property(e => e.TypeName)
                    .HasMaxLength(45)
                    .HasComment("類別系統名稱");

                entity.Property(e => e.TypeValue)
                    .HasMaxLength(45)
                    .HasComment("類別值");
            });

            modelBuilder.Entity<GameVariable>(entity =>
            {
                entity.Property(e => e.Id).HasColumnType("int(11)");

                entity.Property(e => e.GameId)
                    .HasColumnType("int(11)")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.ParameterName).HasMaxLength(45);

                entity.Property(e => e.ParameterValue).HasMaxLength(100);

                entity.Property(e => e.Status)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'0'");
            });

            modelBuilder.Entity<OpenApiDoc>(entity =>
            {
                entity.ToTable("OpenApiDoc");

                entity.HasIndex(e => e.Path, "Path_UNIQUE")
                    .IsUnique();

                entity.Property(e => e.Id)
                    .HasColumnType("int(11)")
                    .HasColumnName("id");

                entity.Property(e => e.Active)
                    .HasColumnType("int(1)")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.Bearer)
                    .HasColumnType("int(1)")
                    .HasDefaultValueSql("'1'")
                    .HasComment("api 是否 jwt 驗證");

                entity.Property(e => e.Description)
                    .HasMaxLength(500)
                    .HasDefaultValueSql("'無'")
                    .HasComment("api 描述");

                entity.Property(e => e.Method)
                    .HasMaxLength(45)
                    .HasDefaultValueSql("'post'")
                    .HasComment("http method");

                entity.Property(e => e.Path)
                    .HasMaxLength(45)
                    .HasComment("api route");

                entity.Property(e => e.Provider)
                    .HasColumnType("int(1)")
                    .HasDefaultValueSql("'0'")
                    .HasComment("0:共用;\n1:遊戲商;\n2:平台商;");

                entity.Property(e => e.Request)
                    .HasMaxLength(3000)
                    .HasComment("open api document 輸入格式");

                entity.Property(e => e.Response)
                    .HasMaxLength(3000)
                    .HasComment("open api document 輸出格式");

                entity.Property(e => e.Summary)
                    .HasMaxLength(45)
                    .HasComment("api 概述");

                entity.Property(e => e.Tags)
                    .HasMaxLength(45)
                    .HasDefaultValueSql("'Unfinished'")
                    .HasComment("api 類別");
            });

            modelBuilder.Entity<SeamlessExecuteLog>(entity =>
            {
                entity.HasKey(e => new { e.Id, e.MerchantId, e.Vcode, e.GameId, e.TransactionId, e.RoundId, e.Type, e.CreateDate })
                    .HasName("PRIMARY")
                    .HasAnnotation("MySql:IndexPrefixLength", new[] { 0, 0, 0, 0, 0, 0, 0, 0 });

                entity.ToTable("SeamlessExecuteLog");

                entity.HasIndex(e => new { e.MerchantId, e.Vcode, e.BetTime, e.GameId, e.TransactionId, e.RoundId, e.UserId }, "IDX_QUERY");

                entity.Property(e => e.Id)
                    .HasColumnType("bigint(20)")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.MerchantId).HasMaxLength(50);

                entity.Property(e => e.Vcode).HasMaxLength(50);

                entity.Property(e => e.GameId).HasMaxLength(30);

                entity.Property(e => e.TransactionId).HasMaxLength(50);

                entity.Property(e => e.RoundId).HasMaxLength(50);

                entity.Property(e => e.Type).HasMaxLength(50);

                entity.Property(e => e.CreateDate)
                    .HasColumnType("datetime(3)")
                    .HasDefaultValueSql("CURRENT_TIMESTAMP(3)");

                entity.Property(e => e.BetTime).HasColumnType("datetime(3)");

                entity.Property(e => e.Currency).HasMaxLength(30);

                entity.Property(e => e.End).HasColumnType("tinyint(4)");

                entity.Property(e => e.External).HasColumnType("text");

                entity.Property(e => e.Offlinetagamount).HasColumnType("bigint(20)");

                entity.Property(e => e.ResponseData).HasColumnType("text");

                entity.Property(e => e.SessionToken).HasMaxLength(1500);

                entity.Property(e => e.Transfer).HasColumnType("tinyint(4)");

                entity.Property(e => e.Url).HasMaxLength(150);

                entity.Property(e => e.UserId).HasMaxLength(50);

                entity.Property(e => e.UserToken).HasMaxLength(1500);

                entity.Property(e => e.Wallet).HasMaxLength(45);
            });

            modelBuilder.Entity<SeamlessLog>(entity =>
            {
                entity.HasKey(e => e.IdLogs)
                    .HasName("PRIMARY");

                entity.HasIndex(e => new { e.CreateDate, e.MerchantId, e.Vcode }, "IDX_QUERY");

                entity.Property(e => e.IdLogs)
                    .HasColumnType("bigint(80)")
                    .HasColumnName("Id_logs");

                entity.Property(e => e.Amount).HasColumnType("text");

                entity.Property(e => e.Balance).HasColumnType("text");

                entity.Property(e => e.BetAmount).HasColumnType("text");

                entity.Property(e => e.BetTime).HasColumnType("text");

                entity.Property(e => e.CreateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("CURRENT_TIMESTAMP");

                entity.Property(e => e.Currency).HasColumnType("text");

                entity.Property(e => e.Detail).HasColumnType("text");

                entity.Property(e => e.End).HasColumnType("text");

                entity.Property(e => e.External).HasColumnType("text");

                entity.Property(e => e.GameId).HasColumnType("text");

                entity.Property(e => e.MerchantId).HasMaxLength(50);

                entity.Property(e => e.Offlinetagamount).HasColumnType("text");

                entity.Property(e => e.ResponseData).HasColumnType("text");

                entity.Property(e => e.RoundId).HasColumnType("text");

                entity.Property(e => e.SessionToken).HasColumnType("text");

                entity.Property(e => e.TransactionId).HasMaxLength(80);

                entity.Property(e => e.Transfer).HasColumnType("text");

                entity.Property(e => e.Type).HasColumnType("text");

                entity.Property(e => e.Url).HasColumnType("text");

                entity.Property(e => e.UserId).HasColumnType("text");

                entity.Property(e => e.UserToken).HasMaxLength(1000);

                entity.Property(e => e.Vcode).HasMaxLength(50);

                entity.Property(e => e.Wallet).HasColumnType("text");

                entity.Property(e => e.WinAmount).HasColumnType("text");
            });

            modelBuilder.Entity<SeamlessLoginLog>(entity =>
            {
                entity.HasIndex(e => new { e.CreateDate, e.MerchantId, e.Vcode }, "IDX_QUERY");

                entity.Property(e => e.Id).HasColumnType("bigint(80)");

                entity.Property(e => e.BundleSdk)
                    .HasColumnType("text")
                    .HasColumnName("BundleSDK");

                entity.Property(e => e.ConfigurationId).HasColumnType("text");

                entity.Property(e => e.CreateDate)
                    .HasColumnType("datetime(3)")
                    .HasDefaultValueSql("CURRENT_TIMESTAMP(3)");

                entity.Property(e => e.Currency).HasColumnType("text");

                entity.Property(e => e.GameId).HasColumnType("text");

                entity.Property(e => e.Language).HasColumnType("text");

                entity.Property(e => e.LaunchFrom).HasColumnType("text");

                entity.Property(e => e.LicenseeId).HasColumnType("text");

                entity.Property(e => e.MerchantId).HasMaxLength(50);

                entity.Property(e => e.SessionToken).HasColumnType("text");

                entity.Property(e => e.UserToken).HasColumnType("text");

                entity.Property(e => e.Vcode).HasMaxLength(50);

                entity.Property(e => e.Vip)
                    .HasColumnType("text")
                    .HasColumnName("VIP");
            });

            modelBuilder.Entity<SuperNumber>(entity =>
            {
                entity.Property(e => e.Id).HasColumnType("int(11)");

                entity.Property(e => e.Description).HasMaxLength(50);

                entity.Property(e => e.GameId)
                    .HasColumnType("int(11)")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.IdVendor)
                    .HasColumnType("int(11)")
                    .HasColumnName("Id_Vendor")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.Key).HasMaxLength(100);

                entity.Property(e => e.Key1).HasMaxLength(30);

                entity.Property(e => e.Key2).HasMaxLength(30);

                entity.Property(e => e.Status)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.Value).HasMaxLength(30);

                entity.Property(e => e.Value1).HasMaxLength(30);

                entity.Property(e => e.Value2).HasMaxLength(30);
            });

            modelBuilder.Entity<VendorVariable>(entity =>
            {
                entity.Property(e => e.Id).HasColumnType("int(11)");

                entity.Property(e => e.CreateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("CURRENT_TIMESTAMP");

                entity.Property(e => e.LatestModifyDateTime)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("CURRENT_TIMESTAMP");

                entity.Property(e => e.OperatorId)
                    .HasColumnType("int(11)")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.ParameterName).HasMaxLength(45);

                entity.Property(e => e.ParameterValue).HasMaxLength(3000);

                entity.Property(e => e.Status)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.VendorId)
                    .HasColumnType("int(11)")
                    .HasDefaultValueSql("'0'");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
