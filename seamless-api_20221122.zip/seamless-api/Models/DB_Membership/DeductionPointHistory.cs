﻿using System;
using System.Collections.Generic;

namespace Seamless.Core.API.Models.DB_Membership
{
    public partial class DeductionPointHistory
    {
        public int Id { get; set; }
        /// <summary>
        /// 遊戲商系統編號
        /// </summary>
        public int? IdVendor { get; set; }
        /// <summary>
        /// 平台商系統編號
        /// </summary>
        public int? IdOperator { get; set; }
        /// <summary>
        /// 遊戲帳號系統編號
        /// </summary>
        public int? IdPlayers { get; set; }
        /// <summary>
        /// 交易訂單編號
        /// </summary>
        public string OrderNo { get; set; }
        /// <summary>
        /// 遊戲商交易編號
        /// </summary>
        public string StepNo { get; set; }
        /// <summary>
        /// 遊戲代碼
        /// </summary>
        public string GameId { get; set; }
        /// <summary>
        /// 金額
        /// </summary>
        public decimal? Point { get; set; }
        public decimal? WinPoint { get; set; }
        /// <summary>
        /// 創建日期
        /// </summary>
        public DateTime? CreateDate { get; set; }
        /// <summary>
        /// 1: 扣點, 2:結算 3:取消
        /// </summary>
        public int? Type { get; set; }
        /// <summary>
        /// 是否取消
        /// </summary>
        public sbyte? Cancel { get; set; }
    }
}
