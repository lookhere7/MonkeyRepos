﻿using System;
using System.Collections.Generic;

namespace Seamless.Core.API.Models.DB_Membership
{
    public partial class PlayersAccessToken
    {
        public int Id { get; set; }
        /// <summary>
        /// 遊戲帳號系統編號
        /// </summary>
        public int? IdPlayers { get; set; }
        /// <summary>
        /// 登入金鑰
        /// </summary>
        public string Token { get; set; }
        /// <summary>
        /// 創建日期
        /// </summary>
        public DateTime? CreateDate { get; set; }
        /// <summary>
        /// 金鑰過期日期
        /// </summary>
        public DateTime? ExpireDate { get; set; }
    }
}
