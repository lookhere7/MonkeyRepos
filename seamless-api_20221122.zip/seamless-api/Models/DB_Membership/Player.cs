﻿using System;
using System.Collections.Generic;

namespace Seamless.Core.API.Models.DB_Membership
{
    public partial class Player
    {
        public int Id { get; set; }
        /// <summary>
        /// 平台商系統編號
        /// </summary>
        public int? IdOperator { get; set; }
        /// <summary>
        /// 遊戲帳號
        /// </summary>
        public string Username { get; set; }
        /// <summary>
        /// 暱稱
        /// </summary>
        public string Nickname { get; set; }
        /// <summary>
        /// 密碼
        /// </summary>
        public string Password { get; set; }
        /// <summary>
        /// 餘額
        /// </summary>
        public decimal? Balance { get; set; }
        /// <summary>
        /// 等級
        /// </summary>
        public int? Level { get; set; }
        /// <summary>
        /// 是否在線
        /// </summary>
        public sbyte? IsOnline { get; set; }
        /// <summary>
        /// 啟用狀態
        /// </summary>
        public sbyte? Enable { get; set; }
        /// <summary>
        /// 創建日期
        /// </summary>
        public DateTime? CreateDate { get; set; }
    }
}
