﻿using System;
using System.Collections.Generic;

namespace Seamless.Core.API.Models.DB_Membership
{
    public partial class Account
    {
        public int Id { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public decimal? Balance { get; set; }
        public string Nickname { get; set; }
        public string Token { get; set; }
        public DateTime? CreateDate { get; set; }
        public DateTime? ModifyDate { get; set; }
        public sbyte? Enable { get; set; }
    }
}
