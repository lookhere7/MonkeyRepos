﻿using System;
using System.Collections.Generic;

namespace Seamless.Core.API.Models.DB_Membership
{
    public partial class TansactionHistory
    {
        public int Id { get; set; }
        /// <summary>
        /// 營運商系統編號
        /// </summary>
        public int? IdOperator { get; set; }
        /// <summary>
        /// 玩家系統編號
        /// </summary>
        public int? IdPlayers { get; set; }
        /// <summary>
        /// 1: 轉入, 2:轉出, 3: 開帳號時塞入
        /// </summary>
        public int? Type { get; set; }
        /// <summary>
        /// 點數
        /// </summary>
        public decimal? Point { get; set; }
        /// <summary>
        /// 交易時間
        /// </summary>
        public DateTime? CreateDate { get; set; }
    }
}
