﻿using System;
using System.Collections.Generic;

namespace Seamless.Core.API.Models.DB_Membership
{
    public partial class Order
    {
        public int Id { get; set; }
        public int? IdOperator { get; set; }
        public int? IdVendor { get; set; }
        public int? IdPlayers { get; set; }
        public string GameId { get; set; }
        public string OrderNo { get; set; }
        public sbyte? Complete { get; set; }
        public DateTime? CreateDate { get; set; }
    }
}
