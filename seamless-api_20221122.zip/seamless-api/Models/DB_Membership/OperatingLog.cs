﻿using System;
using System.Collections.Generic;

namespace Seamless.Core.API.Models.DB_Membership
{
    public partial class OperatingLog
    {
        public int Id { get; set; }
        /// <summary>
        /// 平台商系統編號
        /// </summary>
        public int? IdOperator { get; set; }
        /// <summary>
        /// 遊戲商系統編號
        /// </summary>
        public int? IdVendor { get; set; }
        /// <summary>
        /// 遊戲帳號系統編號
        /// </summary>
        public int? IdPlayers { get; set; }
        /// <summary>
        /// Request 內容
        /// </summary>
        public string Request { get; set; }
        /// <summary>
        /// Response 內容
        /// </summary>
        public string Response { get; set; }
        /// <summary>
        /// 創建日期
        /// </summary>
        public DateTime? CreateDate { get; set; }
    }
}
