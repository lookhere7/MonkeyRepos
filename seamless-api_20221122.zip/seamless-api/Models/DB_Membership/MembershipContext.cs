﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.Extensions.Configuration;
using System.IO;
using System.Linq;

namespace Seamless.Core.API.Models.DB_Membership
{
    public partial class MembershipContext : DbContext
    {
        public MembershipContext()
        {
        }

        public MembershipContext(DbContextOptions<MembershipContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Account> Accounts { get; set; }
        public virtual DbSet<DeductionPointHistory> DeductionPointHistories { get; set; }
        public virtual DbSet<OperatingLog> OperatingLogs { get; set; }
        public virtual DbSet<Order> Orders { get; set; }
        public virtual DbSet<Player> Players { get; set; }
        public virtual DbSet<PlayersAccessToken> PlayersAccessTokens { get; set; }
        public virtual DbSet<TansactionHistory> TansactionHistories { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                var builder = new ConfigurationBuilder()
                                                  .SetBasePath(Directory.GetCurrentDirectory())
                                                  .AddJsonFile("appsettings.json");
                var config = builder.Build();

                optionsBuilder.UseMySql(config.GetConnectionString("Connection_Membership"), Microsoft.EntityFrameworkCore.ServerVersion.Parse("5.7.36-mysql"));
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.UseCollation("utf8_general_ci")
                .HasCharSet("utf8");

            modelBuilder.Entity<Account>(entity =>
            {
                entity.Property(e => e.Id).HasColumnType("int(11)");

                entity.Property(e => e.Balance).HasPrecision(18, 2);

                entity.Property(e => e.CreateDate).HasColumnType("datetime");

                entity.Property(e => e.Enable)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.ModifyDate).HasColumnType("datetime");

                entity.Property(e => e.Nickname).HasMaxLength(100);

                entity.Property(e => e.Password).HasMaxLength(45);

                entity.Property(e => e.Token).HasMaxLength(50);

                entity.Property(e => e.Username).HasMaxLength(45);
            });

            modelBuilder.Entity<DeductionPointHistory>(entity =>
            {
                entity.ToTable("DeductionPointHistory");

                entity.HasIndex(e => new { e.OrderNo, e.StepNo, e.GameId }, "index2");

                entity.Property(e => e.Id).HasColumnType("int(11)");

                entity.Property(e => e.Cancel)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'0'")
                    .HasComment("是否取消");

                entity.Property(e => e.CreateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("CURRENT_TIMESTAMP")
                    .HasComment("創建日期");

                entity.Property(e => e.GameId)
                    .IsRequired()
                    .HasMaxLength(45)
                    .HasComment("遊戲代碼");

                entity.Property(e => e.IdOperator)
                    .HasColumnType("int(11)")
                    .HasColumnName("Id_Operator")
                    .HasDefaultValueSql("'0'")
                    .HasComment("平台商系統編號");

                entity.Property(e => e.IdPlayers)
                    .HasColumnType("int(11)")
                    .HasColumnName("Id_Players")
                    .HasDefaultValueSql("'0'")
                    .HasComment("遊戲帳號系統編號");

                entity.Property(e => e.IdVendor)
                    .HasColumnType("int(11)")
                    .HasColumnName("Id_Vendor")
                    .HasDefaultValueSql("'0'")
                    .HasComment("遊戲商系統編號");

                entity.Property(e => e.OrderNo)
                    .IsRequired()
                    .HasMaxLength(60)
                    .HasComment("交易訂單編號");

                entity.Property(e => e.Point)
                    .HasPrecision(18, 2)
                    .HasDefaultValueSql("'0.00'")
                    .HasComment("金額");

                entity.Property(e => e.StepNo)
                    .IsRequired()
                    .HasMaxLength(60)
                    .HasComment("遊戲商交易編號");

                entity.Property(e => e.Type)
                    .HasColumnType("int(11)")
                    .HasDefaultValueSql("'0'")
                    .HasComment("1: 扣點, 2:結算 3:取消");

                entity.Property(e => e.WinPoint)
                    .HasPrecision(18, 2)
                    .HasDefaultValueSql("'0.00'");
            });

            modelBuilder.Entity<OperatingLog>(entity =>
            {
                entity.ToTable("OperatingLog");

                entity.Property(e => e.Id).HasColumnType("int(11)");

                entity.Property(e => e.CreateDate)
                    .HasColumnType("datetime")
                    .HasComment("創建日期");

                entity.Property(e => e.IdOperator)
                    .HasColumnType("int(11)")
                    .HasColumnName("Id_Operator")
                    .HasDefaultValueSql("'0'")
                    .HasComment("平台商系統編號");

                entity.Property(e => e.IdPlayers)
                    .HasColumnType("int(11)")
                    .HasColumnName("Id_Players")
                    .HasComment("遊戲帳號系統編號");

                entity.Property(e => e.IdVendor)
                    .HasColumnType("int(11)")
                    .HasColumnName("Id_Vendor")
                    .HasDefaultValueSql("'0'")
                    .HasComment("遊戲商系統編號");

                entity.Property(e => e.Request)
                    .HasMaxLength(200)
                    .HasComment("Request 內容");

                entity.Property(e => e.Response)
                    .HasMaxLength(200)
                    .HasComment("Response 內容");
            });

            modelBuilder.Entity<Order>(entity =>
            {
                entity.Property(e => e.Id).HasColumnType("int(11)");

                entity.Property(e => e.Complete)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.CreateDate).HasColumnType("datetime");

                entity.Property(e => e.GameId).HasMaxLength(45);

                entity.Property(e => e.IdOperator)
                    .HasColumnType("int(11)")
                    .HasColumnName("Id_Operator");

                entity.Property(e => e.IdPlayers)
                    .HasColumnType("int(11)")
                    .HasColumnName("Id_Players");

                entity.Property(e => e.IdVendor)
                    .HasColumnType("int(11)")
                    .HasColumnName("Id_Vendor");

                entity.Property(e => e.OrderNo).HasMaxLength(60);
            });

            modelBuilder.Entity<Player>(entity =>
            {
                entity.Property(e => e.Id).HasColumnType("int(11)");

                entity.Property(e => e.Balance)
                    .HasPrecision(18, 2)
                    .HasDefaultValueSql("'0.00'")
                    .HasComment("餘額");

                entity.Property(e => e.CreateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("CURRENT_TIMESTAMP")
                    .HasComment("創建日期");

                entity.Property(e => e.Enable)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'0'")
                    .HasComment("啟用狀態");

                entity.Property(e => e.IdOperator)
                    .HasColumnType("int(11)")
                    .HasColumnName("Id_Operator")
                    .HasDefaultValueSql("'0'")
                    .HasComment("平台商系統編號");

                entity.Property(e => e.IsOnline)
                    .HasColumnType("tinyint(4)")
                    .HasColumnName("isOnline")
                    .HasDefaultValueSql("'0'")
                    .HasComment("是否在線");

                entity.Property(e => e.Level)
                    .HasColumnType("int(11)")
                    .HasDefaultValueSql("'0'")
                    .HasComment("等級");

                entity.Property(e => e.Nickname)
                    .HasMaxLength(50)
                    .HasComment("暱稱");

                entity.Property(e => e.Password)
                    .HasMaxLength(100)
                    .HasComment("密碼");

                entity.Property(e => e.Username)
                    .HasMaxLength(45)
                    .HasComment("遊戲帳號");
            });

            modelBuilder.Entity<PlayersAccessToken>(entity =>
            {
                entity.ToTable("Players_AccessToken");

                entity.Property(e => e.Id).HasColumnType("int(11)");

                entity.Property(e => e.CreateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("CURRENT_TIMESTAMP")
                    .HasComment("創建日期");

                entity.Property(e => e.ExpireDate)
                    .HasColumnType("datetime")
                    .HasComment("金鑰過期日期");

                entity.Property(e => e.IdPlayers)
                    .HasColumnType("int(11)")
                    .HasColumnName("Id_Players")
                    .HasDefaultValueSql("'0'")
                    .HasComment("遊戲帳號系統編號");

                entity.Property(e => e.Token)
                    .HasMaxLength(50)
                    .HasComment("登入金鑰");
            });

            modelBuilder.Entity<TansactionHistory>(entity =>
            {
                entity.ToTable("TansactionHistory");

                entity.Property(e => e.Id).HasColumnType("int(11)");

                entity.Property(e => e.CreateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("CURRENT_TIMESTAMP")
                    .HasComment("交易時間");

                entity.Property(e => e.IdOperator)
                    .HasColumnType("int(11)")
                    .HasColumnName("Id_Operator")
                    .HasDefaultValueSql("'0'")
                    .HasComment("營運商系統編號");

                entity.Property(e => e.IdPlayers)
                    .HasColumnType("int(11)")
                    .HasColumnName("Id_Players")
                    .HasDefaultValueSql("'0'")
                    .HasComment("玩家系統編號");

                entity.Property(e => e.Point)
                    .HasPrecision(18, 2)
                    .HasDefaultValueSql("'0.00'")
                    .HasComment("點數");

                entity.Property(e => e.Type)
                    .HasColumnType("int(11)")
                    .HasDefaultValueSql("'0'")
                    .HasComment("1: 轉入, 2:轉出, 3: 開帳號時塞入");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
