﻿using System;
using System.Collections.Generic;

namespace Seamless.Core.API.Models.DB_ManufacturerCMS
{
    public partial class OperatorMerchantMapping
    {
        public int Id { get; set; }
        public int? IdOperator { get; set; }
        public string MerchantId { get; set; }
        public sbyte? Active { get; set; }
    }
}
