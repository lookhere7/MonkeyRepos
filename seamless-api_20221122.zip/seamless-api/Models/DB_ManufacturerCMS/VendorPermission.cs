﻿using System;
using System.Collections.Generic;

namespace Seamless.Core.API.Models.DB_ManufacturerCMS
{
    public partial class VendorPermission
    {
        /// <summary>
        /// 權限系統編號
        /// </summary>
        public int Id { get; set; }
        /// <summary>
        /// 使用者系統編號
        /// </summary>
        public int? IdVendor { get; set; }
        /// <summary>
        /// 選單系統編號
        /// </summary>
        public int? IdMenu { get; set; }
        public sbyte? IsMain { get; set; }
        /// <summary>
        /// 啟用狀態
        /// </summary>
        public sbyte? Active { get; set; }
    }
}
