﻿using System;
using System.Collections.Generic;

namespace Seamless.Core.API.Models.DB_ManufacturerCMS
{
    public partial class VendorSubAccountRole
    {
        /// <summary>
        /// 群組系統編號
        /// </summary>
        public int Id { get; set; }
        /// <summary>
        /// 遊戲商系統編號
        /// </summary>
        public int? IdVendor { get; set; }
        /// <summary>
        /// 群組名稱
        /// </summary>
        public string RoleName { get; set; }
        /// <summary>
        /// 啟用狀態
        /// </summary>
        public sbyte? Active { get; set; }
        /// <summary>
        /// 是否移除
        /// </summary>
        public sbyte? Visible { get; set; }
        /// <summary>
        /// 建立時間
        /// </summary>
        public DateTime? CreateDate { get; set; }
    }
}
