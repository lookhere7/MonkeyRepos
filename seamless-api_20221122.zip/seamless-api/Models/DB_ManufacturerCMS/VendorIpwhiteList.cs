﻿using System;
using System.Collections.Generic;

namespace Seamless.Core.API.Models.DB_ManufacturerCMS
{
    public partial class VendorIpwhiteList
    {
        public int Id { get; set; }
        public int? IdVendor { get; set; }
        public string Ipaddress { get; set; }
        public sbyte? Active { get; set; }
        public DateTime? CreateDate { get; set; }
    }
}
