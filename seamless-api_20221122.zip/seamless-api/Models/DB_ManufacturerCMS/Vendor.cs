﻿using System;
using System.Collections.Generic;

namespace Seamless.Core.API.Models.DB_ManufacturerCMS
{
    public partial class Vendor
    {
        /// <summary>
        /// 遊戲商系統編號
        /// </summary>
        public int Id { get; set; }
        /// <summary>
        /// 遊戲商代碼
        /// </summary>
        public string Code { get; set; }
        /// <summary>
        /// 遊戲商名稱
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// 時區
        /// </summary>
        public string TimeZone { get; set; }
        /// <summary>
        /// 金鑰
        /// </summary>
        public string HashKey { get; set; }
        /// <summary>
        /// 啟用狀態
        /// </summary>
        public sbyte? Active { get; set; }
        /// <summary>
        /// 創建日期
        /// </summary>
        public DateTime? CreateDate { get; set; }
    }
}
