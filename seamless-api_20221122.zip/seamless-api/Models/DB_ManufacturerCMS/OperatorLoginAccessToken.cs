﻿using System;
using System.Collections.Generic;

namespace Seamless.Core.API.Models.DB_ManufacturerCMS
{
    public partial class OperatorLoginAccessToken
    {
        /// <summary>
        /// 營運商系統編號
        /// </summary>
        public int IdOperator { get; set; }
        /// <summary>
        /// Token
        /// </summary>
        public string Token { get; set; }
        /// <summary>
        /// 創建日期
        /// </summary>
        public DateTime? CreateDate { get; set; }
        /// <summary>
        /// 失效日期
        /// </summary>
        public DateTime? ExpireDate { get; set; }
    }
}
