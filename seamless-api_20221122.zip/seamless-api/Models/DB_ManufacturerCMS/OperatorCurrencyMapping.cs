﻿using System;
using System.Collections.Generic;

namespace Seamless.Core.API.Models.DB_ManufacturerCMS
{
    public partial class OperatorCurrencyMapping
    {
        /// <summary>
        /// 系統編號
        /// </summary>
        public int Id { get; set; }
        /// <summary>
        /// 貨幣系統編號
        /// </summary>
        public int? IdCurrency { get; set; }
        /// <summary>
        /// 營運商系統編號
        /// </summary>
        public int? IdOperator { get; set; }
        /// <summary>
        /// 啟用狀態
        /// </summary>
        public sbyte? Active { get; set; }
    }
}
