﻿using System;
using System.Collections.Generic;

namespace Seamless.Core.API.Models.DB_ManufacturerCMS
{
    public partial class OperatorSubAccountRole
    {
        /// <summary>
        /// 群組系統編號
        /// </summary>
        public int Id { get; set; }
        public int? IdOperator { get; set; }
        /// <summary>
        /// 群組名稱
        /// </summary>
        public string RoleName { get; set; }
        /// <summary>
        /// 啟用狀態
        /// </summary>
        public sbyte? Active { get; set; }
        public sbyte? Visible { get; set; }
        public DateTime? CreateDate { get; set; }
    }
}
