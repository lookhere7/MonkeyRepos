﻿using System;
using System.Collections.Generic;

namespace Seamless.Core.API.Models.DB_ManufacturerCMS
{
    public partial class OperatorImplementInfo
    {
        /// <summary>
        /// 系統編號
        /// </summary>
        public int Id { get; set; }
        /// <summary>
        /// 營運商系統編號
        /// </summary>
        public int? IdOperator { get; set; }
        /// <summary>
        /// 1. MerchantID
        /// 2. 串接營運商系統時使用
        /// 
        /// </summary>
        public string MerchantId { get; set; }
        /// <summary>
        /// 1. 密碼
        /// 2. 串接營運商系統時使用
        /// 
        /// </summary>
        public string Password { get; set; }
        /// <summary>
        /// 1. 金鑰
        /// 2. 串接營運商系統時使用
        /// 
        /// </summary>
        public string SecretKey { get; set; }
        /// <summary>
        /// 創建日期
        /// </summary>
        public DateTime? CreateDate { get; set; }
        /// <summary>
        /// 過期日期
        /// </summary>
        public DateTime? ExpireDate { get; set; }
        /// <summary>
        /// 1. IV
        /// 2. 串接營運商系統時使用
        /// 
        /// </summary>
        public string Iv { get; set; }
        /// <summary>
        /// 1. KEY
        /// 2. 串接營運商系統時使用
        /// 
        /// </summary>
        public string Key { get; set; }
        /// <summary>
        /// 1. API - 登入網址
        /// 2. 串接營運商系統時使用
        /// 
        /// </summary>
        public string UrlLogin { get; set; }
        /// <summary>
        /// 1. API - 建立遊戲帳號
        /// 2. 串接營運商系統時使用
        /// 
        /// </summary>
        public string UrlRegister { get; set; }
        /// <summary>
        /// 1. API - 點數轉入
        /// 2. 串接營運商系統時使用
        /// 
        /// </summary>
        public string UrlDeposit { get; set; }
        /// <summary>
        /// 1. API - 點數轉出
        /// 2. 串接營運商系統時使用
        /// 
        /// </summary>
        public string UrlWithdraw { get; set; }
        /// <summary>
        /// 1. API - 投注資料
        /// 2. 串接營運商系統時使用
        /// 
        /// </summary>
        public string UrlBetLog { get; set; }
        /// <summary>
        /// 1. API - 建立代理
        /// 2. 串接營運商系統時使用
        /// 
        /// </summary>
        public string UrlAddVendor { get; set; }
        /// <summary>
        /// 1. API - 玩家是否在線
        /// 2. 串接營運商系統時使用
        /// 
        /// </summary>
        public string UrlOnline { get; set; }
        /// <summary>
        /// 1. API - 登出
        /// 2. 串接營運商系統時使用
        /// 
        /// </summary>
        public string UrlLogout { get; set; }
        /// <summary>
        /// 1. API - 封鎖遊戲帳號
        /// 2. 串接營運商系統時使用
        /// 
        /// </summary>
        public string UrlBlock { get; set; }
        /// <summary>
        /// 1. API - 修改遊戲資料
        /// 2. 串接營運商系統時使用
        /// 
        /// </summary>
        public string UrlModifyPlayer { get; set; }
        /// <summary>
        /// 1. API - 取得遊戲帳號餘額
        /// 2. 串接營運商系統時使用
        /// 
        /// </summary>
        public string UrlBalance { get; set; }
        /// <summary>
        /// 1. API - 取得遊戲帳號資料
        /// 2. 串接營運商系統時使用
        /// 
        /// </summary>
        public string UrlGetPlayer { get; set; }
        /// <summary>
        /// 1. API - 取得遊戲清單
        /// 2. 串接營運商系統時使用
        /// 
        /// </summary>
        public string UrlGameList { get; set; }
        /// <summary>
        /// 1. API - 認證
        /// 2. 串接營運商系統時使用
        /// 
        /// </summary>
        public string UrlAuthenticateUser { get; set; }
        /// <summary>
        /// 1. API - 投注 (包含結算)
        /// 2. 串接營運商系統時使用
        /// 
        /// </summary>
        public string UrlBet { get; set; }
        /// <summary>
        /// 1. API - 取消投注
        /// 2. 串接營運商系統時使用
        /// 
        /// </summary>
        public string UrlBetCancel { get; set; }
        /// <summary>
        /// 1. API - 持續激活通知未斷線
        /// 2. 串接營運商系統時使用
        /// 
        /// </summary>
        public string UrlKeepAlive { get; set; }
        /// <summary>
        /// 1. 進入遊戲URL
        /// 2. 串接營運商系統時使用
        /// </summary>
        public string UrlPlay { get; set; }
        public string UrlCreateToken { get; set; }
        public string UrlRoundSettle { get; set; }
        public string UrlEvent { get; set; }
        public string UrlDeduction { get; set; }
        public string UrlDeductionRefund { get; set; }
        public string UrlDeductionSettle { get; set; }
    }
}
