﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.Extensions.Configuration;
using System.IO;
using System.Linq;

namespace Seamless.Core.API.Models.DB_ManufacturerCMS
{
    public partial class ManufacturerCMSContext : DbContext
    {
        public ManufacturerCMSContext()
        {
        }

        public ManufacturerCMSContext(DbContextOptions<ManufacturerCMSContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Country> Countries { get; set; }
        public virtual DbSet<Currency> Currencies { get; set; }
        public virtual DbSet<Game> Games { get; set; }
        public virtual DbSet<GameType> GameTypes { get; set; }
        public virtual DbSet<Language> Languages { get; set; }
        public virtual DbSet<LocaleStringResource> LocaleStringResources { get; set; }
        public virtual DbSet<LogApi> LogApis { get; set; }
        public virtual DbSet<LogOperatorExecute> LogOperatorExecutes { get; set; }
        public virtual DbSet<LogVendorExecute> LogVendorExecutes { get; set; }
        public virtual DbSet<Maintenance> Maintenances { get; set; }
        public virtual DbSet<Membership> Memberships { get; set; }
        public virtual DbSet<MenuSubMenu> MenuSubMenus { get; set; }
        public virtual DbSet<Operator> Operators { get; set; }
        public virtual DbSet<OperatorAccessToken> OperatorAccessTokens { get; set; }
        public virtual DbSet<OperatorCondition> OperatorConditions { get; set; }
        public virtual DbSet<OperatorCurrencyMapping> OperatorCurrencyMappings { get; set; }
        public virtual DbSet<OperatorImplementInfo> OperatorImplementInfos { get; set; }
        public virtual DbSet<OperatorLoginAccessToken> OperatorLoginAccessTokens { get; set; }
        public virtual DbSet<OperatorMenu> OperatorMenus { get; set; }
        public virtual DbSet<OperatorMerchantMapping> OperatorMerchantMappings { get; set; }
        public virtual DbSet<OperatorPermission> OperatorPermissions { get; set; }
        public virtual DbSet<OperatorSubAccount> OperatorSubAccounts { get; set; }
        public virtual DbSet<OperatorSubAccountRole> OperatorSubAccountRoles { get; set; }
        public virtual DbSet<OperatorSubAccountRolePermission> OperatorSubAccountRolePermissions { get; set; }
        public virtual DbSet<Role> Roles { get; set; }
        public virtual DbSet<User> Users { get; set; }
        public virtual DbSet<Vendor> Vendors { get; set; }
        public virtual DbSet<VendorBundleMapping> VendorBundleMappings { get; set; }
        public virtual DbSet<VendorImplementField> VendorImplementFields { get; set; }
        public virtual DbSet<VendorImplementInfo> VendorImplementInfos { get; set; }
        public virtual DbSet<VendorIpwhiteList> VendorIpwhiteLists { get; set; }
        public virtual DbSet<VendorLoginAccessToken> VendorLoginAccessTokens { get; set; }
        public virtual DbSet<VendorMenu> VendorMenus { get; set; }
        public virtual DbSet<VendorOperatorAccountMapping> VendorOperatorAccountMappings { get; set; }
        public virtual DbSet<VendorPermission> VendorPermissions { get; set; }
        public virtual DbSet<VendorSubAccount> VendorSubAccounts { get; set; }
        public virtual DbSet<VendorSubAccountPermission> VendorSubAccountPermissions { get; set; }
        public virtual DbSet<VendorSubAccountRole> VendorSubAccountRoles { get; set; }
        public virtual DbSet<VendorSubAccountRolePermission> VendorSubAccountRolePermissions { get; set; }
        public virtual DbSet<VendorTestAccount> VendorTestAccounts { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                var builder = new ConfigurationBuilder()
                                  .SetBasePath(Directory.GetCurrentDirectory())
                                  .AddJsonFile("appsettings.json");
                var config = builder.Build();

                optionsBuilder.UseMySql(config.GetConnectionString("Connection_ManufacturerCMS"), Microsoft.EntityFrameworkCore.ServerVersion.Parse("5.7.36-mysql"));
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.UseCollation("utf8_general_ci")
                .HasCharSet("utf8");

            modelBuilder.Entity<Country>(entity =>
            {
                entity.ToTable("Country");

                entity.HasCharSet("latin1")
                    .UseCollation("latin1_swedish_ci");

                entity.Property(e => e.Id)
                    .HasColumnType("int(11)")
                    .HasComment("國家系統編號");

                entity.Property(e => e.Active)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'0'")
                    .HasComment("啟用狀態");

                entity.Property(e => e.Code)
                    .HasMaxLength(30)
                    .HasComment("國家代碼");

                entity.Property(e => e.CountryName)
                    .HasMaxLength(50)
                    .HasComment("國家名稱")
                    .UseCollation("utf8_general_ci")
                    .HasCharSet("utf8");
            });

            modelBuilder.Entity<Currency>(entity =>
            {
                entity.ToTable("Currency");

                entity.HasCharSet("latin1")
                    .UseCollation("latin1_swedish_ci");

                entity.Property(e => e.Id)
                    .HasColumnType("int(11)")
                    .HasComment("貨幣系統編號");

                entity.Property(e => e.Active)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'0'")
                    .HasComment("啟用狀態");

                entity.Property(e => e.Code)
                    .HasMaxLength(30)
                    .HasComment("貨幣代碼");

                entity.Property(e => e.CurrencyName)
                    .HasMaxLength(50)
                    .HasComment("貨幣名稱")
                    .UseCollation("utf8_general_ci")
                    .HasCharSet("utf8");
            });

            modelBuilder.Entity<Game>(entity =>
            {
                entity.ToTable("Game");

                entity.HasCharSet("latin1")
                    .UseCollation("latin1_swedish_ci");

                entity.Property(e => e.Id)
                    .HasColumnType("int(11)")
                    .HasComment("遊戲系統編號");

                entity.Property(e => e.Active)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'1'")
                    .HasComment("啟用狀態");

                entity.Property(e => e.Code)
                    .HasMaxLength(30)
                    .HasComment("遊戲代碼");

                entity.Property(e => e.GameName)
                    .HasMaxLength(80)
                    .HasComment("遊戲名稱")
                    .UseCollation("utf8_general_ci")
                    .HasCharSet("utf8");

                entity.Property(e => e.IdGameType)
                    .HasColumnType("int(11)")
                    .HasColumnName("Id_GameType")
                    .HasComment("遊戲類型系統編號");

                entity.Property(e => e.IdVendor)
                    .HasColumnType("int(11)")
                    .HasColumnName("Id_Vendor")
                    .HasDefaultValueSql("'0'")
                    .HasComment("遊戲商系統編號");

                entity.Property(e => e.IsH5)
                    .HasColumnType("tinyint(4)")
                    .HasColumnName("isH5")
                    .HasDefaultValueSql("'1'")
                    .HasComment("是否支援H5");

                entity.Property(e => e.LLogo)
                    .HasMaxLength(45)
                    .HasColumnName("l_Logo")
                    .HasComment("遊戲 Logo (大)");

                entity.Property(e => e.LaunchTime)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("CURRENT_TIMESTAMP")
                    .HasComment("上市時間");

                entity.Property(e => e.Rtp)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'96'");

                entity.Property(e => e.SLogo)
                    .HasMaxLength(45)
                    .HasColumnName("s_Logo")
                    .HasComment("遊戲 Logo (小)");
            });

            modelBuilder.Entity<GameType>(entity =>
            {
                entity.ToTable("GameType");

                entity.HasCharSet("latin1")
                    .UseCollation("latin1_swedish_ci");

                entity.Property(e => e.Id)
                    .HasColumnType("int(11)")
                    .HasComment("遊戲類型系統編號");

                entity.Property(e => e.Active)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'0'")
                    .HasComment("啟用狀態");

                entity.Property(e => e.Code)
                    .HasMaxLength(45)
                    .HasComment("遊戲類型代碼");

                entity.Property(e => e.Name)
                    .HasMaxLength(50)
                    .HasComment("遊戲類型名稱")
                    .UseCollation("utf8_general_ci")
                    .HasCharSet("utf8");
            });

            modelBuilder.Entity<Language>(entity =>
            {
                entity.ToTable("Language");

                entity.HasCharSet("latin1")
                    .UseCollation("latin1_swedish_ci");

                entity.Property(e => e.Id)
                    .HasColumnType("int(11)")
                    .HasComment("語系系統編號");

                entity.Property(e => e.Active)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'0'")
                    .HasComment("啟用狀態");

                entity.Property(e => e.Code)
                    .HasMaxLength(30)
                    .HasComment("語系代碼");

                entity.Property(e => e.LanguageName)
                    .HasMaxLength(50)
                    .HasComment("語系名稱")
                    .UseCollation("utf8_general_ci")
                    .HasCharSet("utf8");
            });

            modelBuilder.Entity<LocaleStringResource>(entity =>
            {
                entity.ToTable("LocaleStringResource");

                entity.Property(e => e.Id)
                    .HasColumnType("int(11)")
                    .HasComment("系統編號");

                entity.Property(e => e.EntityId)
                    .HasColumnType("int(11)")
                    .HasComment("來源 Table 中系統編號");

                entity.Property(e => e.IdLanguage)
                    .HasColumnType("int(11)")
                    .HasColumnName("Id_Language")
                    .HasComment("語系系統編號");

                entity.Property(e => e.ResourceName)
                    .HasMaxLength(45)
                    .HasComment("來源 Table 中欄位名稱");

                entity.Property(e => e.ResourceValue)
                    .HasMaxLength(200)
                    .HasComment("來源 Table 中欄位對應值");

                entity.Property(e => e.SourceDb)
                    .HasMaxLength(45)
                    .HasColumnName("SourceDB");

                entity.Property(e => e.SourceTable)
                    .HasMaxLength(45)
                    .HasComment("對照來源 Table Name");
            });

            modelBuilder.Entity<LogApi>(entity =>
            {
                entity.ToTable("Log_API");

                entity.Property(e => e.Id)
                    .HasColumnType("int(11)")
                    .HasComment("系統編號");

                entity.Property(e => e.CreateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("CURRENT_TIMESTAMP");

                entity.Property(e => e.Request)
                    .HasColumnType("text")
                    .HasComment("Request Data");

                entity.Property(e => e.Response)
                    .HasColumnType("text")
                    .HasComment("呼叫 API 回應內容");

                entity.Property(e => e.Url)
                    .HasMaxLength(3000)
                    .HasColumnName("URL")
                    .HasComment("Request URL");
            });

            modelBuilder.Entity<LogOperatorExecute>(entity =>
            {
                entity.ToTable("Log_OperatorExecute");

                entity.HasIndex(e => new { e.CreateDate, e.IdAccount }, "IDX_QUERY");

                entity.Property(e => e.Id)
                    .HasColumnType("int(11)")
                    .HasComment("系統編號");

                entity.Property(e => e.Action).HasMaxLength(15);

                entity.Property(e => e.CreateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("CURRENT_TIMESTAMP")
                    .HasComment("操作時間");

                entity.Property(e => e.IdAccount)
                    .HasColumnType("int(11)")
                    .HasColumnName("Id_Account")
                    .HasComment("營運商系統編號");

                entity.Property(e => e.IdMenu)
                    .HasColumnType("int(11)")
                    .HasColumnName("Id_Menu")
                    .HasComment("功能選單系統編號");

                entity.Property(e => e.IdSubMenu)
                    .HasColumnType("int(11)")
                    .HasColumnName("Id_SubMenu")
                    .HasComment("子功能選單系統編號");

                entity.Property(e => e.Request).HasComment("操作要求內容");

                entity.Property(e => e.Response).HasComment("操作回應內容");

                entity.Property(e => e.Route)
                    .HasMaxLength(50)
                    .HasComment("API Route");
            });

            modelBuilder.Entity<LogVendorExecute>(entity =>
            {
                entity.ToTable("Log_VendorExecute");

                entity.HasIndex(e => new { e.CreateDate, e.IdAccount }, "IDX_QUERY");

                entity.Property(e => e.Id)
                    .HasColumnType("int(11)")
                    .HasComment("系統編號");

                entity.Property(e => e.Action)
                    .HasMaxLength(15)
                    .HasComment("操作描述");

                entity.Property(e => e.CreateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("CURRENT_TIMESTAMP")
                    .HasComment("操作時間");

                entity.Property(e => e.IdAccount)
                    .HasColumnType("int(11)")
                    .HasColumnName("Id_Account")
                    .HasComment("遊戲商系統編號");

                entity.Property(e => e.IdMenu)
                    .HasColumnType("int(11)")
                    .HasColumnName("Id_Menu")
                    .HasComment("功能選單系統編號");

                entity.Property(e => e.IdSubMenu)
                    .HasColumnType("int(11)")
                    .HasColumnName("Id_SubMenu")
                    .HasComment("子功能選單系統編號");

                entity.Property(e => e.Request).HasComment("操作要求內容");

                entity.Property(e => e.Response).HasComment("操作回應內容");

                entity.Property(e => e.Route)
                    .HasMaxLength(50)
                    .HasComment("API 路徑");
            });

            modelBuilder.Entity<Maintenance>(entity =>
            {
                entity.ToTable("Maintenance");

                entity.Property(e => e.Id).HasColumnType("int(11)");

                entity.Property(e => e.Active).HasColumnType("tinyint(4)");

                entity.Property(e => e.CreateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("CURRENT_TIMESTAMP");

                entity.Property(e => e.EndTime).HasColumnType("datetime");

                entity.Property(e => e.IdVendor)
                    .HasColumnType("int(11)")
                    .HasColumnName("Id_Vendor")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.Path).HasMaxLength(45);

                entity.Property(e => e.StartTime).HasColumnType("datetime");
            });

            modelBuilder.Entity<Membership>(entity =>
            {
                entity.ToTable("Membership");

                entity.HasIndex(e => new { e.IdOperator, e.IdVendor, e.Username }, "index2");

                entity.Property(e => e.Id).HasColumnType("int(11)");

                entity.Property(e => e.CreateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("CURRENT_TIMESTAMP");

                entity.Property(e => e.IdOperator)
                    .HasColumnType("int(11)")
                    .HasColumnName("Id_Operator")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.IdVendor)
                    .HasColumnType("int(11)")
                    .HasColumnName("Id_Vendor")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.LastLoginDate).HasColumnType("datetime");

                entity.Property(e => e.Username).HasMaxLength(100);
            });

            modelBuilder.Entity<MenuSubMenu>(entity =>
            {
                entity.ToTable("Menu_SubMenu");

                entity.Property(e => e.Id)
                    .HasColumnType("int(11)")
                    .HasComment("系統編號");

                entity.Property(e => e.HyperLink)
                    .HasMaxLength(100)
                    .HasComment("子選單超連結");

                entity.Property(e => e.IdMenu)
                    .HasColumnType("int(11)")
                    .HasColumnName("Id_Menu")
                    .HasComment("母選單系統編號");

                entity.Property(e => e.Name)
                    .HasMaxLength(50)
                    .HasComment("子選單名稱");
            });

            modelBuilder.Entity<Operator>(entity =>
            {
                entity.ToTable("Operator");

                entity.HasCharSet("latin1")
                    .UseCollation("latin1_swedish_ci");

                entity.Property(e => e.Id)
                    .HasColumnType("int(11)")
                    .HasComment("營運商系統編號");

                entity.Property(e => e.Active)
                    .HasColumnType("int(11)")
                    .HasDefaultValueSql("'0'")
                    .HasComment("1: 啟用, 2:欠費: 3停用");

                entity.Property(e => e.ApiCode).HasMaxLength(45);

                entity.Property(e => e.Balance)
                    .HasPrecision(12, 2)
                    .HasComment("營運商餘額");

                entity.Property(e => e.BillMail)
                    .HasMaxLength(60)
                    .HasComment("帳務聯絡人電子郵件");

                entity.Property(e => e.BillName)
                    .HasMaxLength(40)
                    .HasComment("帳務聯絡人名稱")
                    .UseCollation("utf8_general_ci")
                    .HasCharSet("utf8");

                entity.Property(e => e.BillScale)
                    .HasColumnType("int(11)")
                    .HasDefaultValueSql("'1'")
                    .HasComment("帳務比例");

                entity.Property(e => e.BillType)
                    .HasColumnType("int(11)")
                    .HasDefaultValueSql("'1'")
                    .HasComment("1: 現金制, 2:信用制");

                entity.Property(e => e.ConvertRate).HasDefaultValueSql("'1'");

                entity.Property(e => e.CreateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("CURRENT_TIMESTAMP")
                    .HasComment("創建日期");

                entity.Property(e => e.IdRole)
                    .HasColumnType("int(11)")
                    .HasColumnName("Id_Role")
                    .HasDefaultValueSql("'0'")
                    .HasComment("角色系統編號");

                entity.Property(e => e.OperatorName)
                    .HasMaxLength(50)
                    .HasComment("營運商名稱")
                    .UseCollation("utf8_general_ci")
                    .HasCharSet("utf8");

                entity.Property(e => e.Password)
                    .HasMaxLength(50)
                    .HasComment("後台登入用密碼");

                entity.Property(e => e.SecretKey)
                    .HasMaxLength(45)
                    .HasComment("加密金鑰");

                entity.Property(e => e.TechMail)
                    .HasMaxLength(60)
                    .HasComment("技術窗口聯絡人電子郵件");

                entity.Property(e => e.TechName)
                    .HasMaxLength(40)
                    .HasComment("技術窗口聯絡人名稱")
                    .UseCollation("utf8_general_ci")
                    .HasCharSet("utf8");

                entity.Property(e => e.TimeZone)
                    .HasMaxLength(10)
                    .HasComment("時區");

                entity.Property(e => e.Username)
                    .HasMaxLength(50)
                    .HasComment("後台登入用帳號");
            });

            modelBuilder.Entity<OperatorAccessToken>(entity =>
            {
                entity.ToTable("Operator_AccessToken");

                entity.HasCharSet("latin1")
                    .UseCollation("latin1_swedish_ci");

                entity.Property(e => e.Id)
                    .HasColumnType("int(11)")
                    .HasComment("系統編號");

                entity.Property(e => e.CreateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("CURRENT_TIMESTAMP")
                    .HasComment("創建日期");

                entity.Property(e => e.ExpireDate)
                    .HasColumnType("datetime")
                    .HasComment("Token 過期日期");

                entity.Property(e => e.IdOperator)
                    .HasColumnType("int(11)")
                    .HasColumnName("Id_Operator")
                    .HasDefaultValueSql("'0'")
                    .HasComment("營運商系統編號");

                entity.Property(e => e.Token)
                    .HasMaxLength(200)
                    .HasComment("登入後 Token");
            });

            modelBuilder.Entity<OperatorCondition>(entity =>
            {
                entity.ToTable("Operator_Conditions");

                entity.HasCharSet("latin1")
                    .UseCollation("latin1_swedish_ci");

                entity.Property(e => e.Id)
                    .HasColumnType("int(11)")
                    .HasComment("系統編號");

                entity.Property(e => e.IdGame)
                    .HasColumnType("int(11)")
                    .HasColumnName("Id_Game")
                    .HasDefaultValueSql("'0'")
                    .HasComment("遊戲系統編號");

                entity.Property(e => e.IdOperator)
                    .HasColumnType("int(11)")
                    .HasColumnName("Id_Operator")
                    .HasDefaultValueSql("'0'")
                    .HasComment("營運商系統編號");

                entity.Property(e => e.Ratio)
                    .HasPrecision(18, 2)
                    .HasDefaultValueSql("'0.00'")
                    .HasComment("拆帳比%");
            });

            modelBuilder.Entity<OperatorCurrencyMapping>(entity =>
            {
                entity.ToTable("Operator_Currency_Mapping");

                entity.Property(e => e.Id)
                    .HasColumnType("int(11)")
                    .HasComment("系統編號");

                entity.Property(e => e.Active)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'0'")
                    .HasComment("啟用狀態");

                entity.Property(e => e.IdCurrency)
                    .HasColumnType("int(11)")
                    .HasColumnName("Id_Currency")
                    .HasDefaultValueSql("'0'")
                    .HasComment("貨幣系統編號");

                entity.Property(e => e.IdOperator)
                    .HasColumnType("int(11)")
                    .HasColumnName("Id_Operator")
                    .HasDefaultValueSql("'0'")
                    .HasComment("營運商系統編號");
            });

            modelBuilder.Entity<OperatorImplementInfo>(entity =>
            {
                entity.ToTable("Operator_Implement_Info");

                entity.HasCharSet("latin1")
                    .UseCollation("latin1_swedish_ci");

                entity.Property(e => e.Id)
                    .HasColumnType("int(11)")
                    .HasComment("系統編號");

                entity.Property(e => e.CreateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("CURRENT_TIMESTAMP")
                    .HasComment("創建日期");

                entity.Property(e => e.ExpireDate)
                    .HasColumnType("datetime")
                    .HasComment("過期日期");

                entity.Property(e => e.IdOperator)
                    .HasColumnType("int(11)")
                    .HasColumnName("Id_Operator")
                    .HasDefaultValueSql("'0'")
                    .HasComment("營運商系統編號");

                entity.Property(e => e.Iv)
                    .HasMaxLength(45)
                    .HasColumnName("IV")
                    .HasComment("1. IV\n2. 串接營運商系統時使用\n");

                entity.Property(e => e.Key)
                    .HasMaxLength(45)
                    .HasColumnName("KEY")
                    .HasComment("1. KEY\n2. 串接營運商系統時使用\n");

                entity.Property(e => e.MerchantId)
                    .HasMaxLength(50)
                    .HasColumnName("MerchantID")
                    .HasComment("1. MerchantID\n2. 串接營運商系統時使用\n");

                entity.Property(e => e.Password)
                    .HasMaxLength(50)
                    .HasComment("1. 密碼\n2. 串接營運商系統時使用\n");

                entity.Property(e => e.SecretKey)
                    .HasMaxLength(50)
                    .HasComment("1. 金鑰\n2. 串接營運商系統時使用\n");

                entity.Property(e => e.UrlAddVendor)
                    .HasMaxLength(100)
                    .HasColumnName("URL_AddVendor")
                    .HasComment("1. API - 建立代理\n2. 串接營運商系統時使用\n");

                entity.Property(e => e.UrlAuthenticateUser)
                    .HasMaxLength(100)
                    .HasColumnName("URL_AuthenticateUser")
                    .HasComment("1. API - 認證\n2. 串接營運商系統時使用\n");

                entity.Property(e => e.UrlBalance)
                    .HasMaxLength(100)
                    .HasColumnName("URL_Balance")
                    .HasComment("1. API - 取得遊戲帳號餘額\n2. 串接營運商系統時使用\n");

                entity.Property(e => e.UrlBet)
                    .HasMaxLength(100)
                    .HasColumnName("URL_Bet")
                    .HasComment("1. API - 投注 (包含結算)\n2. 串接營運商系統時使用\n");

                entity.Property(e => e.UrlBetCancel)
                    .HasMaxLength(100)
                    .HasColumnName("URL_BetCancel")
                    .HasComment("1. API - 取消投注\n2. 串接營運商系統時使用\n");

                entity.Property(e => e.UrlBetLog)
                    .HasMaxLength(100)
                    .HasColumnName("URL_BetLog")
                    .HasComment("1. API - 投注資料\n2. 串接營運商系統時使用\n");

                entity.Property(e => e.UrlBlock)
                    .HasMaxLength(45)
                    .HasColumnName("URL_Block")
                    .HasComment("1. API - 封鎖遊戲帳號\n2. 串接營運商系統時使用\n");

                entity.Property(e => e.UrlCreateToken)
                    .HasMaxLength(300)
                    .HasColumnName("URL_CreateToken");

                entity.Property(e => e.UrlDeduction)
                    .HasMaxLength(300)
                    .HasColumnName("URL_Deduction");

                entity.Property(e => e.UrlDeductionRefund)
                    .HasMaxLength(300)
                    .HasColumnName("URL_DeductionRefund");

                entity.Property(e => e.UrlDeductionSettle)
                    .HasMaxLength(300)
                    .HasColumnName("URL_DeductionSettle");

                entity.Property(e => e.UrlDeposit)
                    .HasMaxLength(100)
                    .HasColumnName("URL_Deposit")
                    .HasComment("1. API - 點數轉入\n2. 串接營運商系統時使用\n");

                entity.Property(e => e.UrlEvent)
                    .HasMaxLength(300)
                    .HasColumnName("URL_Event");

                entity.Property(e => e.UrlGameList)
                    .HasMaxLength(100)
                    .HasColumnName("URL_GameList")
                    .HasComment("1. API - 取得遊戲清單\n2. 串接營運商系統時使用\n");

                entity.Property(e => e.UrlGetPlayer)
                    .HasMaxLength(100)
                    .HasColumnName("URL_GetPlayer")
                    .HasComment("1. API - 取得遊戲帳號資料\n2. 串接營運商系統時使用\n");

                entity.Property(e => e.UrlKeepAlive)
                    .HasMaxLength(100)
                    .HasColumnName("URL_KeepAlive")
                    .HasComment("1. API - 持續激活通知未斷線\n2. 串接營運商系統時使用\n");

                entity.Property(e => e.UrlLogin)
                    .HasMaxLength(200)
                    .HasColumnName("URL_Login")
                    .HasComment("1. API - 登入網址\n2. 串接營運商系統時使用\n");

                entity.Property(e => e.UrlLogout)
                    .HasMaxLength(100)
                    .HasColumnName("URL_Logout")
                    .HasComment("1. API - 登出\n2. 串接營運商系統時使用\n");

                entity.Property(e => e.UrlModifyPlayer)
                    .HasMaxLength(100)
                    .HasColumnName("URL_ModifyPlayer")
                    .HasComment("1. API - 修改遊戲資料\n2. 串接營運商系統時使用\n");

                entity.Property(e => e.UrlOnline)
                    .HasMaxLength(100)
                    .HasColumnName("URL_Online")
                    .HasComment("1. API - 玩家是否在線\n2. 串接營運商系統時使用\n");

                entity.Property(e => e.UrlPlay)
                    .HasMaxLength(300)
                    .HasColumnName("URL_Play")
                    .HasComment("1. 進入遊戲URL\n2. 串接營運商系統時使用");

                entity.Property(e => e.UrlRegister)
                    .HasMaxLength(100)
                    .HasColumnName("URL_Register")
                    .HasComment("1. API - 建立遊戲帳號\n2. 串接營運商系統時使用\n");

                entity.Property(e => e.UrlRoundSettle)
                    .HasMaxLength(300)
                    .HasColumnName("URL_RoundSettle");

                entity.Property(e => e.UrlWithdraw)
                    .HasMaxLength(100)
                    .HasColumnName("URL_Withdraw")
                    .HasComment("1. API - 點數轉出\n2. 串接營運商系統時使用\n");
            });

            modelBuilder.Entity<OperatorLoginAccessToken>(entity =>
            {
                entity.HasKey(e => e.IdOperator)
                    .HasName("PRIMARY");

                entity.ToTable("Operator_LoginAccessToken");

                entity.Property(e => e.IdOperator)
                    .HasColumnType("int(11)")
                    .ValueGeneratedNever()
                    .HasColumnName("Id_Operator")
                    .HasComment("營運商系統編號");

                entity.Property(e => e.CreateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("CURRENT_TIMESTAMP")
                    .HasComment("創建日期");

                entity.Property(e => e.ExpireDate)
                    .HasColumnType("datetime")
                    .HasComment("失效日期");

                entity.Property(e => e.Token)
                    .HasMaxLength(200)
                    .HasComment("Token");
            });

            modelBuilder.Entity<OperatorMenu>(entity =>
            {
                entity.ToTable("Operator_Menu");

                entity.HasCharSet("latin1")
                    .UseCollation("latin1_swedish_ci");

                entity.Property(e => e.Id)
                    .HasColumnType("int(11)")
                    .ValueGeneratedNever()
                    .HasComment("系統編號");

                entity.Property(e => e.Active)
                    .HasColumnType("tinyint(4)")
                    .HasComment("啟用狀態");

                entity.Property(e => e.Code)
                    .HasMaxLength(10)
                    .HasComment("選單代碼");

                entity.Property(e => e.Depth)
                    .HasColumnType("int(11)")
                    .HasDefaultValueSql("'0'")
                    .HasComment("選單層級");

                entity.Property(e => e.HyperLink)
                    .HasMaxLength(100)
                    .HasComment("超連結");

                entity.Property(e => e.Icon)
                    .HasMaxLength(30)
                    .HasComment("選單圖示");

                entity.Property(e => e.MenuName)
                    .HasMaxLength(50)
                    .HasComment("選單名稱");

                entity.Property(e => e.Parent)
                    .HasMaxLength(10)
                    .HasComment("上層選單編號");
            });

            modelBuilder.Entity<OperatorMerchantMapping>(entity =>
            {
                entity.ToTable("Operator_Merchant_Mapping");

                entity.Property(e => e.Id).HasColumnType("int(11)");

                entity.Property(e => e.Active).HasColumnType("tinyint(4)");

                entity.Property(e => e.IdOperator)
                    .HasColumnType("int(11)")
                    .HasColumnName("Id_Operator");

                entity.Property(e => e.MerchantId).HasMaxLength(45);
            });

            modelBuilder.Entity<OperatorPermission>(entity =>
            {
                entity.ToTable("Operator_Permission");

                entity.HasCharSet("latin1")
                    .UseCollation("latin1_swedish_ci");

                entity.Property(e => e.Id)
                    .HasColumnType("int(11)")
                    .HasComment("系統編號");

                entity.Property(e => e.Active)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'0'")
                    .HasComment("啟用狀態");

                entity.Property(e => e.IdMenu)
                    .HasColumnType("int(11)")
                    .HasColumnName("Id_Menu")
                    .HasDefaultValueSql("'0'")
                    .HasComment("選單系統編號");

                entity.Property(e => e.IdOperator)
                    .HasColumnType("int(11)")
                    .HasColumnName("Id_Operator")
                    .HasDefaultValueSql("'0'")
                    .HasComment("使用者系統編號");

                entity.Property(e => e.IsMain)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'0'")
                    .HasComment("是否為主帳號權限");
            });

            modelBuilder.Entity<OperatorSubAccount>(entity =>
            {
                entity.ToTable("Operator_SubAccount");

                entity.Property(e => e.Id)
                    .HasColumnType("int(11)")
                    .HasComment("營運商子帳號系統編號");

                entity.Property(e => e.Account)
                    .HasMaxLength(50)
                    .HasComment("子帳號");

                entity.Property(e => e.Active)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'0'")
                    .HasComment("啟用狀態");

                entity.Property(e => e.CreateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("CURRENT_TIMESTAMP")
                    .HasComment("創建日期");

                entity.Property(e => e.IdOperator)
                    .HasColumnType("int(11)")
                    .HasColumnName("Id_Operator")
                    .HasDefaultValueSql("'0'")
                    .HasComment("營運商系統編號");

                entity.Property(e => e.IdRole)
                    .HasColumnType("int(11)")
                    .HasColumnName("Id_Role")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.Password)
                    .HasMaxLength(50)
                    .HasComment("子帳號密碼");

                entity.Property(e => e.SecretKey)
                    .HasMaxLength(45)
                    .HasComment("加密金鑰");

                entity.Property(e => e.Username).HasMaxLength(50);
            });

            modelBuilder.Entity<OperatorSubAccountRole>(entity =>
            {
                entity.ToTable("Operator_SubAccount_Role");

                entity.HasCharSet("latin1")
                    .UseCollation("latin1_swedish_ci");

                entity.Property(e => e.Id)
                    .HasColumnType("int(11)")
                    .HasComment("群組系統編號");

                entity.Property(e => e.Active)
                    .HasColumnType("tinyint(4)")
                    .HasComment("啟用狀態");

                entity.Property(e => e.CreateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("CURRENT_TIMESTAMP");

                entity.Property(e => e.IdOperator)
                    .HasColumnType("int(11)")
                    .HasColumnName("Id_Operator");

                entity.Property(e => e.RoleName)
                    .HasMaxLength(50)
                    .HasComment("群組名稱")
                    .UseCollation("utf8_general_ci")
                    .HasCharSet("utf8");

                entity.Property(e => e.Visible)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'1'");
            });

            modelBuilder.Entity<OperatorSubAccountRolePermission>(entity =>
            {
                entity.ToTable("Operator_SubAccount_Role_Permission");

                entity.Property(e => e.Id)
                    .HasColumnType("int(11)")
                    .HasComment("群組權限系統編號");

                entity.Property(e => e.IdMenu)
                    .HasColumnType("int(11)")
                    .HasColumnName("Id_Menu")
                    .HasDefaultValueSql("'0'")
                    .HasComment("母選單系統編號");

                entity.Property(e => e.IdRole)
                    .HasColumnType("int(11)")
                    .HasColumnName("Id_Role")
                    .HasDefaultValueSql("'0'")
                    .HasComment("群組系統編號");
            });

            modelBuilder.Entity<Role>(entity =>
            {
                entity.ToTable("Role");

                entity.HasCharSet("latin1")
                    .UseCollation("latin1_swedish_ci");

                entity.Property(e => e.Id)
                    .HasColumnType("int(11)")
                    .HasComment("群組系統編號");

                entity.Property(e => e.Active)
                    .HasColumnType("tinyint(4)")
                    .HasComment("啟用狀態");

                entity.Property(e => e.RoleName)
                    .HasMaxLength(50)
                    .HasComment("群組名稱")
                    .UseCollation("utf8_general_ci")
                    .HasCharSet("utf8");
            });

            modelBuilder.Entity<User>(entity =>
            {
                entity.ToTable("users");

                entity.Property(e => e.Id)
                    .HasColumnType("int(11)")
                    .HasColumnName("id");

                entity.Property(e => e.FirstName)
                    .IsRequired()
                    .HasMaxLength(255)
                    .HasColumnName("firstName");

                entity.Property(e => e.IsActive)
                    .HasColumnType("tinyint(4)")
                    .HasColumnName("isActive")
                    .HasDefaultValueSql("'1'");

                entity.Property(e => e.LastName)
                    .IsRequired()
                    .HasMaxLength(255)
                    .HasColumnName("lastName");
            });

            modelBuilder.Entity<Vendor>(entity =>
            {
                entity.ToTable("Vendor");

                entity.HasCharSet("latin1")
                    .UseCollation("latin1_swedish_ci");

                entity.Property(e => e.Id)
                    .HasColumnType("int(11)")
                    .HasComment("遊戲商系統編號");

                entity.Property(e => e.Active)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'0'")
                    .HasComment("啟用狀態");

                entity.Property(e => e.Code)
                    .HasMaxLength(30)
                    .HasComment("遊戲商代碼");

                entity.Property(e => e.CreateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("CURRENT_TIMESTAMP")
                    .HasComment("創建日期");

                entity.Property(e => e.HashKey)
                    .HasMaxLength(45)
                    .HasComment("金鑰");

                entity.Property(e => e.Name)
                    .HasMaxLength(50)
                    .HasComment("遊戲商名稱")
                    .UseCollation("utf8_general_ci")
                    .HasCharSet("utf8");

                entity.Property(e => e.TimeZone)
                    .HasMaxLength(5)
                    .HasDefaultValueSql("'+0'")
                    .HasComment("時區");
            });

            modelBuilder.Entity<VendorBundleMapping>(entity =>
            {
                entity.ToTable("Vendor_BundleMapping");

                entity.Property(e => e.Id).HasColumnType("int(11)");

                entity.Property(e => e.BundleName).HasMaxLength(45);

                entity.Property(e => e.IdGame)
                    .HasColumnType("int(11)")
                    .HasColumnName("Id_Game")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.IdOperator)
                    .HasColumnType("int(11)")
                    .HasColumnName("Id_Operator")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.IdVendor)
                    .HasColumnType("int(11)")
                    .HasColumnName("Id_Vendor")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.PackageName).HasMaxLength(45);

                entity.Property(e => e.Status)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'0'");
            });

            modelBuilder.Entity<VendorImplementField>(entity =>
            {
                entity.ToTable("Vendor_Implement_Fields");

                entity.HasCharSet("latin1")
                    .UseCollation("latin1_swedish_ci");

                entity.Property(e => e.Id).HasColumnType("int(11)");

                entity.Property(e => e.FieldName).HasMaxLength(50);

                entity.Property(e => e.HashSort)
                    .HasColumnType("int(11)")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.IdVendorImplementInfo)
                    .HasColumnType("int(11)")
                    .HasColumnName("Id_Vendor_Implement_Info")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.IsHash)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.Type)
                    .HasColumnType("int(11)")
                    .HasDefaultValueSql("'0'")
                    .HasComment("1: Register\\\\n2: Login\\\\n3: TransferPoint\\\\n4: Play game\\n5:BetLog");
            });

            modelBuilder.Entity<VendorImplementInfo>(entity =>
            {
                entity.ToTable("Vendor_Implement_Info");

                entity.HasCharSet("latin1")
                    .UseCollation("latin1_swedish_ci");

                entity.Property(e => e.Id)
                    .HasColumnType("int(11)")
                    .HasComment("系統編號");

                entity.Property(e => e.BetRecordInterval)
                    .HasColumnType("int(11)")
                    .HasColumnName("BetRecord_Interval")
                    .HasDefaultValueSql("'15'")
                    .HasComment("1. 排程撈取遊戲商投注紀錄區間\n2. 每隔x分鐘");

                entity.Property(e => e.IdVendor)
                    .HasColumnType("int(11)")
                    .HasColumnName("Id_Vendor")
                    .HasDefaultValueSql("'0'")
                    .HasComment("遊戲商系統編號");

                entity.Property(e => e.ImplementCode)
                    .HasMaxLength(50)
                    .HasColumnName("Implement_Code")
                    .HasComment("1. 串接代碼\n2. 遊戲商呼叫中間層 API 時使用\n");

                entity.Property(e => e.ImplementIv)
                    .HasMaxLength(50)
                    .HasColumnName("Implement_IV")
                    .HasComment("1. 串接IV\n2. 遊戲商呼叫中間層 API 時使用\n");

                entity.Property(e => e.ImplementKey)
                    .HasMaxLength(50)
                    .HasColumnName("Implement_Key")
                    .HasComment("1. 串接Key\n2. 遊戲商呼叫中間層 API 時使用\n");

                entity.Property(e => e.Password)
                    .HasMaxLength(50)
                    .HasComment("1. 密碼\n2. 遊戲商呼叫中間層 API 時使用之 Password\n");

                entity.Property(e => e.Status)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'0'")
                    .HasComment("啟用狀態");

                entity.Property(e => e.SummaryRecordInterval)
                    .HasColumnType("int(11)")
                    .HasColumnName("SummaryRecord_Interval")
                    .HasDefaultValueSql("'0'")
                    .HasComment("1. 排程將投注紀錄轉換每小時輸贏紀錄\n2. 每隔x分鐘");

                entity.Property(e => e.UrlBetLog)
                    .HasMaxLength(100)
                    .HasColumnName("URL_BetLog")
                    .HasComment("1. 遊戲商投注紀錄 API URL\n2. 遊戲商呼叫中間層 API 時使用\n");

                entity.Property(e => e.UrlKick)
                    .HasMaxLength(300)
                    .HasColumnName("URL_Kick");

                entity.Property(e => e.UrlLogout)
                    .HasMaxLength(100)
                    .HasColumnName("URL_Logout")
                    .HasComment("1. 登出玩家 API URL\n2. 遊戲商呼叫中間層 API 時使用\n");

                entity.Property(e => e.UrlOnline)
                    .HasMaxLength(100)
                    .HasColumnName("URL_Online")
                    .HasComment("1. 取得玩家是否在線 API URL\n2. 遊戲商呼叫中間層 API 時使用\n");

                entity.Property(e => e.UrlPlay)
                    .HasMaxLength(300)
                    .HasColumnName("URL_Play")
                    .HasComment("1. 進入遊戲 URL\n2. 遊戲商呼叫中間層 API 時使用\n");

                entity.Property(e => e.VendorId)
                    .HasMaxLength(50)
                    .HasColumnName("VendorID")
                    .HasComment("1. 遊戲商-商戶號代碼  \\n2. 遊戲商呼叫中間層 API 時使用之 MerchantID");
            });

            modelBuilder.Entity<VendorIpwhiteList>(entity =>
            {
                entity.ToTable("Vendor_IPWhiteList");

                entity.Property(e => e.Id).HasColumnType("int(11)");

                entity.Property(e => e.Active)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.CreateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("CURRENT_TIMESTAMP");

                entity.Property(e => e.IdVendor)
                    .HasColumnType("int(11)")
                    .HasColumnName("Id_Vendor")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.Ipaddress)
                    .HasMaxLength(40)
                    .HasColumnName("IPAddress");
            });

            modelBuilder.Entity<VendorLoginAccessToken>(entity =>
            {
                entity.HasKey(e => e.IdVendor)
                    .HasName("PRIMARY");

                entity.ToTable("Vendor_LoginAccessToken");

                entity.Property(e => e.IdVendor)
                    .HasColumnType("int(11)")
                    .ValueGeneratedNever()
                    .HasColumnName("Id_Vendor")
                    .HasComment("遊戲商系統編號");

                entity.Property(e => e.CreateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("CURRENT_TIMESTAMP")
                    .HasComment("創建日期");

                entity.Property(e => e.ExpireDate)
                    .HasColumnType("datetime")
                    .HasComment("失效日期");

                entity.Property(e => e.IdSubAccount)
                    .HasColumnType("int(11)")
                    .HasColumnName("Id_SubAccount");

                entity.Property(e => e.Token)
                    .HasMaxLength(200)
                    .HasComment("Token");
            });

            modelBuilder.Entity<VendorMenu>(entity =>
            {
                entity.ToTable("Vendor_Menu");

                entity.HasCharSet("latin1")
                    .UseCollation("latin1_swedish_ci");

                entity.Property(e => e.Id)
                    .HasColumnType("int(11)")
                    .ValueGeneratedNever()
                    .HasComment("系統編號");

                entity.Property(e => e.Active)
                    .HasColumnType("tinyint(4)")
                    .HasComment("啟用狀態");

                entity.Property(e => e.Code)
                    .HasMaxLength(10)
                    .HasComment("選單代碼");

                entity.Property(e => e.Depth)
                    .HasColumnType("int(11)")
                    .HasDefaultValueSql("'0'")
                    .HasComment("選單層級");

                entity.Property(e => e.HyperLink)
                    .HasMaxLength(100)
                    .HasComment("超連結");

                entity.Property(e => e.Icon)
                    .HasMaxLength(30)
                    .HasComment("選單圖示");

                entity.Property(e => e.MenuName)
                    .HasMaxLength(50)
                    .HasComment("選單名稱");

                entity.Property(e => e.Parent)
                    .HasMaxLength(10)
                    .HasComment("上層選單編號");
            });

            modelBuilder.Entity<VendorOperatorAccountMapping>(entity =>
            {
                entity.ToTable("Vendor_Operator_Account_Mapping");

                entity.Property(e => e.Id)
                    .HasColumnType("int(11)")
                    .HasComment("系統編號");

                entity.Property(e => e.Active)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'1'")
                    .HasComment("是否啟用");

                entity.Property(e => e.CreateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("CURRENT_TIMESTAMP")
                    .HasComment("創建日期");

                entity.Property(e => e.GameId)
                    .HasColumnType("int(11)")
                    .HasDefaultValueSql("'0'")
                    .HasComment("遊戲系統代碼");

                entity.Property(e => e.IdOperator)
                    .HasColumnType("int(11)")
                    .HasColumnName("Id_Operator")
                    .HasDefaultValueSql("'0'")
                    .HasComment("營運商系統編號");

                entity.Property(e => e.IdVendor)
                    .HasColumnType("int(11)")
                    .HasColumnName("Id_Vendor")
                    .HasDefaultValueSql("'0'")
                    .HasComment("遊戲商系統編號");

                entity.Property(e => e.ImplementBillingCode)
                    .HasMaxLength(45)
                    .HasComment("帳務代碼 (用於建立及對應注單table名稱)");

                entity.Property(e => e.ImplementBillingGameCode)
                    .HasMaxLength(45)
                    .HasComment("遊戲代碼 (用於注單對應)");

                entity.Property(e => e.ImplementId)
                    .HasMaxLength(45)
                    .HasColumnName("ImplementID")
                    .HasComment("遊戲商串接 ID");

                entity.Property(e => e.ImplementVcode)
                    .HasMaxLength(45)
                    .HasColumnName("ImplementVCode")
                    .HasComment("遊戲商指定呼叫營運商代碼");

                entity.Property(e => e.OperatorGameId)
                    .HasMaxLength(45)
                    .HasColumnName("Operator_GameId")
                    .HasComment("1. 營運商提供之GameId\n2. 由遊戲商呼叫營運商時, 將遊戲商端 GameId 轉換成 營運商 GameId 送出\n");

                entity.Property(e => e.OperatorId)
                    .HasMaxLength(45)
                    .HasColumnName("Operator_Id")
                    .HasComment("營運商提供之Id");

                entity.Property(e => e.OperatorImplementId)
                    .HasMaxLength(45)
                    .HasColumnName("Operator_ImplementID")
                    .HasComment("營運商串接 ID");

                entity.Property(e => e.OperatorKey)
                    .HasMaxLength(45)
                    .HasColumnName("Operator_Key")
                    .HasComment("營運商提供之Key");

                entity.Property(e => e.Route)
                    .HasColumnType("int(11)")
                    .HasDefaultValueSql("'0'")
                    .HasComment("1. 指向\n2. 1為：營運商連至遊戲商\n3. 2為：遊戲商連至營運商");

                entity.Property(e => e.SummaryCode)
                    .HasMaxLength(45)
                    .HasComment("統計報表對應代碼");

                entity.Property(e => e.TestMode)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.UrlApilog)
                    .HasMaxLength(100)
                    .HasColumnName("URL_APILog");

                entity.Property(e => e.UrlApilogImplementKey)
                    .HasMaxLength(50)
                    .HasColumnName("URL_APILog_ImplementKey");

                entity.Property(e => e.UrlBetLog)
                    .HasMaxLength(100)
                    .HasColumnName("URL_BetLog")
                    .HasComment("1. 遊戲商投注紀錄 API URL\\n2. 遊戲商呼叫中間層 API 時使用\\n");

                entity.Property(e => e.UrlKick)
                    .HasMaxLength(300)
                    .HasColumnName("URL_Kick")
                    .HasComment("踢人");

                entity.Property(e => e.UrlLogout)
                    .HasMaxLength(100)
                    .HasColumnName("URL_Logout")
                    .HasComment("1. 登出玩家 API URL\\n2. 遊戲商呼叫中間層 API 時使用\\n");

                entity.Property(e => e.UrlOnline)
                    .HasMaxLength(100)
                    .HasColumnName("URL_Online")
                    .HasComment("1. 取得玩家是否在線 API URL\\n2. 遊戲商呼叫中間層 API 時使用\\n");

                entity.Property(e => e.UrlPlay)
                    .HasMaxLength(500)
                    .HasColumnName("URL_Play");

                entity.Property(e => e.UrlRoomRecord)
                    .HasMaxLength(300)
                    .HasColumnName("URL_RoomRecord")
                    .HasComment("房卡/開桌遊戲 - 拉取游戏记录的对局详情 API 網址");

                entity.Property(e => e.UrlRoomRecordImplementKey)
                    .HasMaxLength(50)
                    .HasColumnName("URL_RoomRecord_ImplementKey")
                    .HasComment("房卡/開桌遊戲 - 拉取游戏记录的对局详情 API 金鑰");

                entity.Property(e => e.UrlRoomReplay)
                    .HasMaxLength(300)
                    .HasColumnName("URL_RoomReplay")
                    .HasComment("房卡/開桌遊戲 - 回放 API 網址");

                entity.Property(e => e.UrlRoomReplayImplementKey)
                    .HasMaxLength(50)
                    .HasColumnName("URL_RoomReplay_ImplementKey")
                    .HasComment("房卡/開桌遊戲 - 回放 API 網址呼叫金鑰");

                entity.Property(e => e.UrlRoomUserRecord)
                    .HasMaxLength(300)
                    .HasColumnName("URL_RoomUserRecord")
                    .HasComment("房卡/開桌遊戲 - 拉取玩家游戏局记录 API 網址");

                entity.Property(e => e.UrlRoomUserRecordImplementKey)
                    .HasMaxLength(50)
                    .HasColumnName("URL_RoomUserRecord_ImplementKey")
                    .HasComment("房卡/開桌遊戲 - 拉取玩家游戏局记录 API 金鑰");

                entity.Property(e => e.UrlRound)
                    .HasMaxLength(300)
                    .HasColumnName("URL_Round");

                entity.Property(e => e.UrlStock)
                    .HasMaxLength(100)
                    .HasColumnName("URL_Stock");
            });

            modelBuilder.Entity<VendorPermission>(entity =>
            {
                entity.ToTable("Vendor_Permission");

                entity.HasCharSet("latin1")
                    .UseCollation("latin1_swedish_ci");

                entity.Property(e => e.Id)
                    .HasColumnType("int(11)")
                    .HasComment("權限系統編號");

                entity.Property(e => e.Active)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'0'")
                    .HasComment("啟用狀態");

                entity.Property(e => e.IdMenu)
                    .HasColumnType("int(11)")
                    .HasColumnName("Id_Menu")
                    .HasDefaultValueSql("'0'")
                    .HasComment("選單系統編號");

                entity.Property(e => e.IdVendor)
                    .HasColumnType("int(11)")
                    .HasColumnName("Id_Vendor")
                    .HasDefaultValueSql("'0'")
                    .HasComment("使用者系統編號");

                entity.Property(e => e.IsMain).HasColumnType("tinyint(4)");
            });

            modelBuilder.Entity<VendorSubAccount>(entity =>
            {
                entity.ToTable("Vendor_SubAccount");

                entity.Property(e => e.Id)
                    .HasColumnType("int(11)")
                    .HasComment("遊戲商子帳號系統編號");

                entity.Property(e => e.Account)
                    .HasMaxLength(50)
                    .HasComment("子帳號");

                entity.Property(e => e.Active)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'0'")
                    .HasComment("啟用狀態");

                entity.Property(e => e.CreateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("CURRENT_TIMESTAMP")
                    .HasComment("創建日期");

                entity.Property(e => e.IdRole)
                    .HasColumnType("int(11)")
                    .HasColumnName("Id_Role")
                    .HasDefaultValueSql("'0'")
                    .HasComment("角色系統編號");

                entity.Property(e => e.IdVendor)
                    .HasColumnType("int(11)")
                    .HasColumnName("Id_Vendor")
                    .HasDefaultValueSql("'0'")
                    .HasComment("遊戲商系統編號");

                entity.Property(e => e.Password)
                    .HasMaxLength(50)
                    .HasComment("子帳號密碼");

                entity.Property(e => e.SecretKey)
                    .HasMaxLength(45)
                    .HasComment("加密金鑰");

                entity.Property(e => e.Username)
                    .HasMaxLength(50)
                    .HasComment("子帳號名稱");
            });

            modelBuilder.Entity<VendorSubAccountPermission>(entity =>
            {
                entity.ToTable("Vendor_SubAccount_Permission");

                entity.Property(e => e.Id)
                    .HasColumnType("int(11)")
                    .HasComment("權限系統編號");

                entity.Property(e => e.IdMenu)
                    .HasColumnType("int(11)")
                    .HasColumnName("Id_Menu")
                    .HasComment("選單系統編號");

                entity.Property(e => e.IdSubAccount)
                    .HasColumnType("int(11)")
                    .HasColumnName("Id_SubAccount")
                    .HasComment("子帳號系統編號");
            });

            modelBuilder.Entity<VendorSubAccountRole>(entity =>
            {
                entity.ToTable("Vendor_SubAccount_Role");

                entity.HasCharSet("latin1")
                    .UseCollation("latin1_swedish_ci");

                entity.Property(e => e.Id)
                    .HasColumnType("int(11)")
                    .HasComment("群組系統編號");

                entity.Property(e => e.Active)
                    .HasColumnType("tinyint(4)")
                    .HasComment("啟用狀態");

                entity.Property(e => e.CreateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("CURRENT_TIMESTAMP")
                    .HasComment("建立時間");

                entity.Property(e => e.IdVendor)
                    .HasColumnType("int(11)")
                    .HasColumnName("Id_Vendor")
                    .HasComment("遊戲商系統編號");

                entity.Property(e => e.RoleName)
                    .HasMaxLength(50)
                    .HasComment("群組名稱")
                    .UseCollation("utf8_general_ci")
                    .HasCharSet("utf8");

                entity.Property(e => e.Visible)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'1'")
                    .HasComment("是否移除");
            });

            modelBuilder.Entity<VendorSubAccountRolePermission>(entity =>
            {
                entity.ToTable("Vendor_SubAccount_Role_Permission");

                entity.Property(e => e.Id)
                    .HasColumnType("int(11)")
                    .HasComment("群組權限系統編號");

                entity.Property(e => e.IdMenu)
                    .HasColumnType("int(11)")
                    .HasColumnName("Id_Menu")
                    .HasDefaultValueSql("'0'")
                    .HasComment("選單系統編號");

                entity.Property(e => e.IdRole)
                    .HasColumnType("int(11)")
                    .HasColumnName("Id_Role")
                    .HasDefaultValueSql("'0'")
                    .HasComment("群組系統編號");
            });

            modelBuilder.Entity<VendorTestAccount>(entity =>
            {
                entity.ToTable("Vendor_TestAccounts");

                entity.Property(e => e.Id).HasColumnType("int(11)");

                entity.Property(e => e.CreateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("CURRENT_TIMESTAMP");

                entity.Property(e => e.IdOperator)
                    .HasColumnType("int(11)")
                    .HasColumnName("Id_Operator");

                entity.Property(e => e.IdVendor)
                    .HasColumnType("int(11)")
                    .HasColumnName("Id_Vendor")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.Status)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.Username).HasMaxLength(50);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
