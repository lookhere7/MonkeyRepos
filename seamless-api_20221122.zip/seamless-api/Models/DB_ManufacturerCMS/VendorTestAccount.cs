﻿using System;
using System.Collections.Generic;

namespace Seamless.Core.API.Models.DB_ManufacturerCMS
{
    public partial class VendorTestAccount
    {
        public int Id { get; set; }
        public int? IdOperator { get; set; }
        public int? IdVendor { get; set; }
        public string Username { get; set; }
        public sbyte? Status { get; set; }
        public DateTime? CreateDate { get; set; }
    }
}
