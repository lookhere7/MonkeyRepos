﻿using System;
using System.Collections.Generic;

namespace Seamless.Core.API.Models.DB_ManufacturerCMS
{
    public partial class OperatorSubAccountRolePermission
    {
        /// <summary>
        /// 群組權限系統編號
        /// </summary>
        public int Id { get; set; }
        /// <summary>
        /// 群組系統編號
        /// </summary>
        public int? IdRole { get; set; }
        /// <summary>
        /// 母選單系統編號
        /// </summary>
        public int? IdMenu { get; set; }
    }
}
