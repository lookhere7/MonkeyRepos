﻿using System;
using System.Collections.Generic;

namespace Seamless.Core.API.Models.DB_ManufacturerCMS
{
    public partial class VendorLoginAccessToken
    {
        /// <summary>
        /// 遊戲商系統編號
        /// </summary>
        public int IdVendor { get; set; }
        public int? IdSubAccount { get; set; }
        /// <summary>
        /// Token
        /// </summary>
        public string Token { get; set; }
        /// <summary>
        /// 創建日期
        /// </summary>
        public DateTime? CreateDate { get; set; }
        /// <summary>
        /// 失效日期
        /// </summary>
        public DateTime? ExpireDate { get; set; }
    }
}
