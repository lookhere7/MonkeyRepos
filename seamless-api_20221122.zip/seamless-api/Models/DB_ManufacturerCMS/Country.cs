﻿using System;
using System.Collections.Generic;

namespace Seamless.Core.API.Models.DB_ManufacturerCMS
{
    public partial class Country
    {
        /// <summary>
        /// 國家系統編號
        /// </summary>
        public int Id { get; set; }
        /// <summary>
        /// 國家代碼
        /// </summary>
        public string Code { get; set; }
        /// <summary>
        /// 國家名稱
        /// </summary>
        public string CountryName { get; set; }
        /// <summary>
        /// 啟用狀態
        /// </summary>
        public sbyte? Active { get; set; }
    }
}
