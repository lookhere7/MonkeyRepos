﻿using Microsoft.EntityFrameworkCore;
using MySqlConnector;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

/// <summary>
/// MySQL Data
/// </summary>
namespace Seamless.Core.API.Data
{
    /// <summary>
    /// MySQL
    /// </summary>
    public class MySQL
    {
        private readonly Models.DB_ManufacturerCMS.ManufacturerCMSContext _manufacturercmscontext = new();
        private readonly Model.SP_MembershipContext _sp_membership_context = new();

        /// <summary>
        /// EF Add
        /// </summary>
        /// <typeparam name="int"></typeparam>
        public async Task<int> Add<T>(DbContext _context, T _model) where T : class
        {
            _context.Add<T>(_model);
            return await _context.SaveChangesAsync();
        }

        /// <summary>
        /// Get_VendorSeamless_Implement
        /// </summary>
        /// <param name="vendorid"></param>
        /// <param name="vcode"></param>
        /// <returns></returns>
        public Model.VendorSeamlessImplementResponse Get_VendorSeamless_Implement(string vendorid, string vcode)
        {
            Model.VendorSeamlessImplementResponse _response = new Model.VendorSeamlessImplementResponse();

            //    try
            //    {
            //        using (var conn = new MySqlConnection(Constants.ConnectionString))
            //        {
            //            conn.Open();
            //            using (var cmd = new MySqlCommand())
            //            {
            //                cmd.Connection = conn;
            //                cmd.CommandType = CommandType.StoredProcedure;
            //                cmd.CommandText = "SP_SEAMLESS_IMPLEMENT_GET";
            //                cmd.Parameters.AddWithValue("@theVendorID", vendorid);
            //                cmd.Parameters.AddWithValue("@theVCode", vcode);
            //                using(MySqlDataAdapter adapter=new MySqlDataAdapter(cmd))
            //                {
            //                    DataSet ds = new DataSet();
            //                    adapter.Fill(ds, "VendorImplementInfo");
            //                    if(ds.Tables.Count>0)
            //                    {
            //                        _response = ds.Tables[0].AsEnumerable().Select(x => new Model.VendorSeamlessImplementResponse()
            //                        {
            //                            CreateDate = x.Field<DateTime>("CreateDate"),
            //                            ExpireDate = x.Field<DateTime>("ExpireDate"),
            //                            MerchantID = x.Field<string>("MerchantID"),
            //                            Id = x.Field<int>("Id"),
            //                            IV = x.Field<string>("IV"),
            //                            KEY = x.Field<string>("KEY"),
            //                            Password = x.Field<string>("Password"),
            //                            SecretKey = x.Field<string>("SecretKey"),
            //                            Id_Operator = x.Field<int>("Id_Operator"),
            //                            VendorHashKey = x.Field<string>("VendorHashKey"),
            //                            ImplementSecretKey = x.Field<string>("ImplementSecretKey"),
            //                            URL_Deposit = x.Field<string>("URL_Deposit"),
            //                            URL_AddVendor = x.Field<string>("URL_AddVendor"),
            //                            URL_AuthenticateUser = x.Field<string>("URL_AuthenticateUser"),
            //                            URL_Balance = x.Field<string>("URL_Balance"),
            //                            URL_Bet = x.Field<string>("URL_Bet"),
            //                            URL_BetLog = x.Field<string>("URL_BetLog"),
            //                            URL_Block = x.Field<string>("URL_Block"),
            //                            URL_BetCancel = x.Field<string>("URL_BetCancel"),
            //                            URL_CreateToken = x.Field<string>("URL_CreateToken"),
            //                            URL_GameList = x.Field<string>("URL_GameList"),
            //                            URL_GetPlayer = x.Field<string>("URL_GetPlayer"),
            //                            URL_KeepAlive = x.Field<string>("URL_KeepAlive"),
            //                            URL_Login = x.Field<string>("URL_Login"),
            //                            URL_Logout = x.Field<string>("URL_Logout"),
            //                            URL_ModifyPlayer = x.Field<string>("URL_ModifyPlayer"),
            //                            URL_Online = x.Field<string>("URL_Online"),
            //                            URL_Play = x.Field<string>("URL_Play"),
            //                            URL_Register = x.Field<string>("URL_Register"),
            //                            URL_RoundSettle = x.Field<string>("URL_RoundSettle"),
            //                            URL_Withdraw = x.Field<string>("URL_Withdraw")                                    
            //                        }).ToList().FirstOrDefault();
            //                    }
            //                }                        
            //            }
            //            conn.Close();
            //            conn.Dispose();
            //        }
            //    }
            //    catch (Exception ex)
            //    {
            //        //Console.WriteLine($"ExecuteErrorLogs Exception: {ex.Message}");                
            //    }
            return _response;
        }

        /// <summary>
        /// Get_VendorSeamless_Implement2
        /// </summary>
        /// <param name="vendorid"></param>
        /// <param name="vcode"></param>
        /// <returns></returns>
        public List<Models.DB_ManufacturerCMS.VendorImplementInfo> Get_VendorSeamless_Implement2(string vendorid, string vcode)
        {
            Model.VendorSeamlessImplementResponse _response = new Model.VendorSeamlessImplementResponse();

            //查詢
            //var id = 1;
            //var post = _context.VendorImplementInfos.Find(vendorid);
            var posts = _manufacturercmscontext.VendorImplementInfos.Where(p => p.VendorId.Equals(vendorid)).OrderBy(p => p.Id).ToList();
            return posts;
            //新增
            // var post = new Post
            // {
            //     Url = "",
            //     Title = "EF Core",
            //     Read = 0
            // };

            // _context.Post.Add(post);
            // _context.SaveChanges();
        }

        /// <summary>
        /// EF Call SP
        /// </summary>
        /// <param name="_spname"></param>
        /// <param name="_paras"></param>
        /// <returns></returns>
        public async Task<Model.DefaultResponse> CallSP<T>(string _spname, object[] _paras) where T : class
        {
            Model.DefaultResponse _response = new();
            string _strparas = "";
            for (var i = 0; i < _paras.Length; i++)
            {
                _strparas += $"?p{i.ToString()},";
            }
            if (_strparas.Length > 0) _strparas = _strparas.Substring(0, _strparas.Length - 1);
            var _result = await _sp_membership_context.Set<T>().FromSqlRaw($"Call {_spname}({_strparas});", parameters: _paras).ToListAsync();

            _response.code = 0;
            _response.status = "Successful - test mode";
            _response.result = "";

            if (_response == null)
            {
                _response.code = 9997;
                _response.status = "Data not found";
            }
            else
            {
                if (_result.Count <= 0)
                {
                    _response.code = 9997;
                    _response.status = "Data not exist";
                }
                else
                {
                    _response.result = _result;
                }
            }

            return _response;
        }
    }
}