﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Seamless.Core.API.Interfaces;
using Seamless.Core.API.Utility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;

namespace Seamless.Core.API.Services
{
    /// <summary>
    /// 
    /// </summary>
    public class VendorService : IVendorService
    {
        /// <summary>
        /// 
        /// </summary>
        private readonly Models.DB_ManufacturerCMS.ManufacturerCMSContext _manufacturercmscontext = new();
        private readonly Models.DB_VendorSystem.VendorSystemContext _vendorsystemcontext = new();
        private readonly Model.SP_MembershipContext _sp_membership_context = new();
        private readonly ICacheService _cacheService;
        private readonly IOperatorService _operatorService;
        private readonly IPubSubService _pubsubService;
        private readonly int _rediscachetime;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="config"></param>
        /// <param name="cacheService"></param>
        /// <param name="operatorService"></param>
        /// <param name="pubsubService"></param>
        public VendorService(IConfiguration config, ICacheService cacheService, IOperatorService operatorService, IPubSubService pubsubService)
        {
            _rediscachetime = int.Parse(config["RedisCacheTime"]);
            _cacheService = cacheService;
            _operatorService = operatorService;
            _pubsubService = pubsubService;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="_defaultresponse"></param>
        /// <param name="_model_pubsub"></param>
        /// <param name="_id"></param>
        /// <returns></returns>
        public async Task<Model.DefaultResponse> GetVendor(Model.DefaultResponse _defaultresponse, Model.PubSubRequest _model_pubsub, int _id)
        {
            #region 取得Redis快取
            //取得Redis快取
            var _response = await _cacheService.GetFromCache<Models.DB_ManufacturerCMS.Vendor>($"Vendor_{_id.ToString()}");
            if (_response == null)
            {
                //若無快取，則重新撈取資料
                _response = await _manufacturercmscontext.Vendors.Where(x => x.Id == _id).FirstOrDefaultAsync();

                //新增Redis快取
                await _cacheService.SetCache<Models.DB_ManufacturerCMS.Vendor>($"Vendor_{_id.ToString()}", _response, _rediscachetime);
            }
            #endregion

            if (_response == null)
            {
                _defaultresponse.code = 9997;
                _defaultresponse.status = "Vendor mapping data not exist";
                _defaultresponse.result = null;
            }

            if (_defaultresponse.code == 0)
            {
                _defaultresponse.result = _response;
            }
            else
            {
                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                _model_pubsub.type = _defaultresponse.type + " GetVendorData.GetVendor";
                _model_pubsub.responsedata = _defaultresponse;
                await _pubsubService.PublishMessagesAsync(_model_pubsub);
            }

            return _defaultresponse;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="_defaultresponse"></param>
        /// <param name="_model_pubsub"></param>
        /// <param name="_implementvcode"></param>
        /// <returns></returns>
        public async Task<Model.DefaultResponse> GetVendor(Model.DefaultResponse _defaultresponse, Model.PubSubRequest _model_pubsub, string _implementvcode)
        {
            #region 取得Redis快取
            //取得Redis快取
            var _response = await _cacheService.GetFromCache<Models.DB_ManufacturerCMS.Vendor>($"Vendor_{_implementvcode}");
            if (_response == null)
            {
                //若無快取，則重新撈取資料
                _response = await _manufacturercmscontext.Vendors.Where(x => x.Code == _implementvcode).FirstOrDefaultAsync();

                //新增Redis快取
                await _cacheService.SetCache<Models.DB_ManufacturerCMS.Vendor>($"Vendor_{_implementvcode}", _response, _rediscachetime);
            }
            #endregion

            if (_response == null)
            {
                _defaultresponse.code = 9997;
                _defaultresponse.status = "Vendor mapping data not exist";
                _defaultresponse.result = null;
            }

            if (_defaultresponse.code == 0)
            {
                _defaultresponse.result = _response;
            }
            else
            {
                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                _model_pubsub.type = _defaultresponse.type + " GetVendorData.GetVendor";
                _model_pubsub.responsedata = _defaultresponse;
                await _pubsubService.PublishMessagesAsync(_model_pubsub);
            }

            return _defaultresponse;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="_defaultresponse"></param>
        /// <param name="_model_pubsub"></param>
        /// <param name="_vendorid"></param>
        /// <returns></returns>
        public async Task<Model.DefaultResponse> GetVendorImplementInfo(Model.DefaultResponse _defaultresponse, Model.PubSubRequest _model_pubsub, int _vendorid)
        {
            #region 取得Redis快取
            //取得Redis快取
            var _response = await _cacheService.GetFromCache<Models.DB_ManufacturerCMS.VendorImplementInfo>($"VendorImplementInfo_{_vendorid.ToString()}");
            if (_response == null)
            {
                //若無快取，則重新撈取資料
                _response = await _manufacturercmscontext.VendorImplementInfos.Where(x => x.IdVendor == _vendorid).FirstOrDefaultAsync();

                //新增Redis快取
                await _cacheService.SetCache<Models.DB_ManufacturerCMS.VendorImplementInfo>($"VendorImplementInfo_{_vendorid.ToString()}", _response, _rediscachetime);
            }
            #endregion

            if (_response == null)
            {
                _defaultresponse.code = 9997;
                _defaultresponse.status = "VendorImplementInfo mapping data not exist";
                _defaultresponse.result = null;
            }

            if (_defaultresponse.code == 0)
            {
                _defaultresponse.result = _response;
            }
            else
            {
                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                _model_pubsub.type = _defaultresponse.type + " GetVendorData.GetVendorImplementInfo";
                _model_pubsub.responsedata = _defaultresponse;
                await _pubsubService.PublishMessagesAsync(_model_pubsub);
            }

            return _defaultresponse;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="_defaultresponse"></param>
        /// <param name="_model_pubsub"></param>
        /// <param name="_vendorid"></param>
        /// <returns></returns>
        public async Task<Model.DefaultResponse> GetVendorImplementInfo(Model.DefaultResponse _defaultresponse, Model.PubSubRequest _model_pubsub, string _vendorid)
        {
            #region 取得Redis快取
            //取得Redis快取
            var _response = await _cacheService.GetFromCache<Models.DB_ManufacturerCMS.VendorImplementInfo>($"VendorImplementInfo_{_vendorid}");
            if (_response == null)
            {
                //若無快取，則重新撈取資料
                _response = await _manufacturercmscontext.VendorImplementInfos.Where(x => x.VendorId == _vendorid).FirstOrDefaultAsync();

                //新增Redis快取
                await _cacheService.SetCache<Models.DB_ManufacturerCMS.VendorImplementInfo>($"VendorImplementInfo_{_vendorid}", _response, _rediscachetime);
            }
            #endregion

            if (_response == null)
            {
                _defaultresponse.code = 9997;
                _defaultresponse.status = "VendorImplementInfo mapping data not exist";
                _defaultresponse.result = null;
            }

            if (_defaultresponse.code == 0)
            {
                _defaultresponse.result = _response;
            }
            else
            {
                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                _model_pubsub.type = _defaultresponse.type + " GetVendorData.GetVendorImplementInfo";
                _model_pubsub.responsedata = _defaultresponse;
                await _pubsubService.PublishMessagesAsync(_model_pubsub);
            }

            return _defaultresponse;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="_defaultresponse"></param>
        /// <param name="_model_pubsub"></param>
        /// <param name="_vendorid"></param>
        /// <param name="_operatorid"></param>
        /// <param name="_gameid"></param>
        /// <returns></returns>
        public async Task<Model.DefaultResponse> GetVendorOperatorAccountMapping(Model.DefaultResponse _defaultresponse, Model.PubSubRequest _model_pubsub, int _vendorid, int _operatorid, int _gameid)
        {
            #region 取得Redis快取
            //取得Redis快取
            var _response = await _cacheService.GetFromCache<List<Models.DB_ManufacturerCMS.VendorOperatorAccountMapping>>($"VendorOperatorAccountMapping_{_vendorid.ToString()}_{_operatorid.ToString()}_{_gameid.ToString()}");
            if (_response == null)
            {
                //若無快取，則重新撈取資料
                _response = await _manufacturercmscontext.VendorOperatorAccountMappings.Where(x => x.IdOperator == _operatorid && x.IdVendor == _vendorid && x.GameId == _gameid).ToListAsync();

                //新增Redis快取
                await _cacheService.SetCache<List<Models.DB_ManufacturerCMS.VendorOperatorAccountMapping>>($"VendorOperatorAccountMapping_{_vendorid.ToString()}_{_operatorid.ToString()}_{_gameid.ToString()}", _response, _rediscachetime);
            }
            #endregion

            if (_response == null)
            {
                _defaultresponse.code = 9997;
                _defaultresponse.status = "VendorOperatorAccountMapping mapping data not exist";
                _defaultresponse.result = null;
            }

            if (_defaultresponse.code == 0)
            {
                _defaultresponse.result = _response;
            }
            else
            {
                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                _model_pubsub.type = _defaultresponse.type + " GetVendorData.GetVendorOperatorAccountMapping";
                _model_pubsub.responsedata = _defaultresponse;
                await _pubsubService.PublishMessagesAsync(_model_pubsub);
            }

            return _defaultresponse;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="_defaultresponse"></param>
        /// <param name="_model_pubsub"></param>
        /// <param name="_vendorid"></param>
        /// <param name="_operatorid"></param>
        /// <param name="_gameid"></param>
        /// <param name="_route"></param>
        /// <returns></returns>
        public async Task<Model.DefaultResponse> GetVendorOperatorAccountMapping(Model.DefaultResponse _defaultresponse, Model.PubSubRequest _model_pubsub, int _vendorid, int _operatorid, int _gameid, int _route)
        {
            #region 取得Redis快取
            //取得Redis快取
            var _response = await _cacheService.GetFromCache<Models.DB_ManufacturerCMS.VendorOperatorAccountMapping>($"VendorOperatorAccountMapping_{_vendorid.ToString()}_{_operatorid.ToString()}_{_gameid.ToString()}");
            if (_response == null)
            {
                //若無快取，則重新撈取資料
                _response = await _manufacturercmscontext.VendorOperatorAccountMappings.Where(x => x.IdOperator == _operatorid && x.IdVendor == _vendorid && x.GameId == _gameid && x.Route == _route).FirstOrDefaultAsync();

                //新增Redis快取
                await _cacheService.SetCache<Models.DB_ManufacturerCMS.VendorOperatorAccountMapping>($"VendorOperatorAccountMapping_{_vendorid.ToString()}_{_operatorid.ToString()}_{_gameid.ToString()}", _response, _rediscachetime);
            }
            #endregion

            if (_response == null)
            {
                _defaultresponse.code = 9997;
                _defaultresponse.status = "VendorOperatorAccountMapping mapping data not exist";
                _defaultresponse.result = null;
            }

            if (_defaultresponse.code == 0)
            {
                _defaultresponse.result = _response;
            }
            else
            {
                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                _model_pubsub.type = _defaultresponse.type + " GetVendorData.GetVendorOperatorAccountMapping";
                _model_pubsub.responsedata = _defaultresponse;
                await _pubsubService.PublishMessagesAsync(_model_pubsub);
            }

            return _defaultresponse;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="_defaultresponse"></param>
        /// <param name="_model_pubsub"></param>
        /// <param name="_vendorid"></param>
        /// <param name="_operatorid"></param>
        /// <param name="_implementid"></param>
        /// <returns></returns>
        public async Task<Model.DefaultResponse> GetVendorOperatorAccountMapping(Model.DefaultResponse _defaultresponse, Model.PubSubRequest _model_pubsub, int _vendorid, int _operatorid, string _implementid)
        {
            #region 取得Redis快取
            //取得Redis快取
            var _response = await _cacheService.GetFromCache<List<Models.DB_ManufacturerCMS.VendorOperatorAccountMapping>>($"VendorOperatorAccountMapping_{_vendorid.ToString()}_{_operatorid.ToString()}_{_implementid}");
            if (_response == null)
            {
                //若無快取，則重新撈取資料
                _response = await _manufacturercmscontext.VendorOperatorAccountMappings.Where(x => x.IdOperator == _operatorid && x.IdVendor == _vendorid && x.ImplementId == _implementid).ToListAsync();

                //新增Redis快取
                await _cacheService.SetCache<List<Models.DB_ManufacturerCMS.VendorOperatorAccountMapping>>($"VendorOperatorAccountMapping_{_vendorid.ToString()}_{_operatorid.ToString()}_{_implementid}", _response, _rediscachetime);
            }
            #endregion

            if (_response == null)
            {
                _defaultresponse.code = 9997;
                _defaultresponse.status = "VendorOperatorAccountMapping mapping data not exist";
                _defaultresponse.result = null;
            }

            if (_defaultresponse.code == 0)
            {
                _defaultresponse.result = _response;
            }
            else
            {
                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                _model_pubsub.type = _defaultresponse.type + " GetVendorData.GetVendorOperatorAccountMapping";
                _model_pubsub.responsedata = _defaultresponse;
                await _pubsubService.PublishMessagesAsync(_model_pubsub);
            }

            return _defaultresponse;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="_defaultresponse"></param>
        /// <param name="_model_pubsub"></param>
        /// <param name="_vendorid"></param>
        /// <param name="_operatorid"></param>
        /// <param name="_implementid"></param>
        /// <param name="_route"></param>
        /// <returns></returns>
        public async Task<Model.DefaultResponse> GetVendorOperatorAccountMapping(Model.DefaultResponse _defaultresponse, Model.PubSubRequest _model_pubsub, int _vendorid, int _operatorid, string _implementid, int _route)
        {
            #region 取得Redis快取
            //取得Redis快取
            var _response = await _cacheService.GetFromCache<Models.DB_ManufacturerCMS.VendorOperatorAccountMapping>($"VendorOperatorAccountMapping_{_vendorid.ToString()}_{_operatorid.ToString()}_{_implementid}");
            if (_response == null)
            {
                //若無快取，則重新撈取資料
                _response = await _manufacturercmscontext.VendorOperatorAccountMappings.Where(x => x.IdOperator == _operatorid && x.IdVendor == _vendorid && x.ImplementId == _implementid && x.Route == _route).FirstOrDefaultAsync();

                //新增Redis快取
                await _cacheService.SetCache<Models.DB_ManufacturerCMS.VendorOperatorAccountMapping>($"VendorOperatorAccountMapping_{_vendorid.ToString()}_{_operatorid.ToString()}_{_implementid}", _response, _rediscachetime);
            }
            #endregion

            if (_response == null && _implementid != "")
            {
                _defaultresponse.code = 9997;
                _defaultresponse.status = "VendorOperatorAccountMapping1 mapping data not exist";
                _defaultresponse.result = null;
            }

            if (_defaultresponse.code == 0)
            {
                _defaultresponse.result = _response;
            }
            else
            {
                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                _model_pubsub.type = _defaultresponse.type + " GetVendorData.GetVendorOperatorAccountMapping1";
                _model_pubsub.responsedata = _defaultresponse;
                await _pubsubService.PublishMessagesAsync(_model_pubsub);
            }

            return _defaultresponse;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="_defaultresponse"></param>
        /// <param name="_model_pubsub"></param>
        /// <param name="_vendorid"></param>
        /// <param name="_implementvcode"></param>
        /// <param name="_route"></param>
        /// <returns></returns>
        public async Task<Model.DefaultResponse> GetVendorOperatorAccountMapping(Model.DefaultResponse _defaultresponse, Model.PubSubRequest _model_pubsub, int _vendorid, string _implementvcode, int _route)
        {
            #region 取得Redis快取
            //取得Redis快取
            var _response = await _cacheService.GetFromCache<Models.DB_ManufacturerCMS.VendorOperatorAccountMapping>($"VendorOperatorAccountMapping_{_vendorid.ToString()}_{_implementvcode}");
            if (_response == null)
            {
                //若無快取，則重新撈取資料
                _response = await _manufacturercmscontext.VendorOperatorAccountMappings.Where(x => x.IdVendor == _vendorid && x.ImplementVcode == _implementvcode && x.Route == _route).FirstOrDefaultAsync();

                //新增Redis快取
                await _cacheService.SetCache<Models.DB_ManufacturerCMS.VendorOperatorAccountMapping>($"VendorOperatorAccountMapping_{_vendorid.ToString()}_{_implementvcode}", _response, _rediscachetime);
            }
            #endregion

            if (_response == null)
            {
                _defaultresponse.code = 9997;
                _defaultresponse.status = "VendorOperatorAccountMapping mapping data not exist";
                _defaultresponse.result = null;
            }

            if (_defaultresponse.code == 0)
            {
                _defaultresponse.result = _response;
            }
            else
            {
                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                _model_pubsub.type = _defaultresponse.type + " GetVendorData.GetVendorOperatorAccountMapping";
                _model_pubsub.responsedata = _defaultresponse;
                await _pubsubService.PublishMessagesAsync(_model_pubsub);
            }

            return _defaultresponse;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="_defaultresponse"></param>
        /// <param name="_model_pubsub"></param>
        /// <param name="_vendorid"></param>
        /// <param name="_operatorid"></param>
        /// <param name="_parametername"></param>
        /// <returns></returns>
        public async Task<Model.DefaultResponse> GetVendorVariable(Model.DefaultResponse _defaultresponse, Model.PubSubRequest _model_pubsub, int _vendorid, int _operatorid, string _parametername)
        {
            #region 取得Redis快取
            //取得Redis快取
            var _response = await _cacheService.GetFromCache<Models.DB_VendorSystem.VendorVariable>($"VendorVariable_{_vendorid.ToString()}_{_operatorid.ToString()}_{_parametername}");
            if (_response == null)
            {
                //若無快取，則重新撈取資料
                _response = await _vendorsystemcontext.VendorVariables.Where(x => x.VendorId == _vendorid && x.OperatorId == _operatorid && x.Status == 1 && x.ParameterName == _parametername).FirstOrDefaultAsync();

                //新增Redis快取
                await _cacheService.SetCache<Models.DB_VendorSystem.VendorVariable>($"VendorVariable_{_vendorid.ToString()}_{_operatorid.ToString()}_{_parametername}", _response, _rediscachetime);
            }
            #endregion

            if (_response == null)
            {
                _defaultresponse.code = 9997;
                _defaultresponse.status = "VendorVariable mapping data not exist";
                _defaultresponse.result = null;
            }

            if (_defaultresponse.code == 0)
            {
                _defaultresponse.result = _response;
            }
            else
            {
                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                _model_pubsub.type = _defaultresponse.type + " GetVendorData.GetVendorVariable";
                _model_pubsub.responsedata = _defaultresponse;
                await _pubsubService.PublishMessagesAsync(_model_pubsub);
            }

            return _defaultresponse;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="_defaultresponse"></param>
        /// <param name="_model_pubsub"></param>
        /// <param name="_vendorid"></param>
        /// <param name="_operatorid"></param>
        /// <param name="_gameid"></param>
        /// <returns></returns>
        public async Task<Model.DefaultResponse> GetVendorBundleMapping(Model.DefaultResponse _defaultresponse, Model.PubSubRequest _model_pubsub, int _vendorid, int _operatorid, int _gameid)
        {
            #region 取得Redis快取
            //取得Redis快取
            var _response = await _cacheService.GetFromCache<Models.DB_ManufacturerCMS.VendorBundleMapping>($"VendorBundleMapping_{_vendorid.ToString()}_{_operatorid.ToString()}_{_gameid.ToString()}");
            if (_response == null)
            {
                //若無快取，則重新撈取資料
                _response = await _manufacturercmscontext.VendorBundleMappings.Where(x => x.IdVendor == _vendorid && x.IdOperator == _operatorid && x.IdGame == _gameid).FirstOrDefaultAsync();

                //新增Redis快取
                await _cacheService.SetCache<Models.DB_ManufacturerCMS.VendorBundleMapping>($"VendorBundleMapping_{_vendorid.ToString()}_{_operatorid.ToString()}_{_gameid.ToString()}", _response, _rediscachetime);
            }
            #endregion

            if (_response == null)
            {
                _defaultresponse.code = 9997;
                _defaultresponse.status = "VendorBundleMapping mapping data not exist";
                _defaultresponse.result = null;
            }

            if (_defaultresponse.code == 0)
            {
                _defaultresponse.result = _response;
            }
            else
            {
                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                _model_pubsub.type = _defaultresponse.type + " GetVendorData.GetVendorBundleMapping";
                _model_pubsub.responsedata = _defaultresponse;
                await _pubsubService.PublishMessagesAsync(_model_pubsub);
            }

            return _defaultresponse;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="_defaultresponse"></param>
        /// <param name="_model_pubsub"></param>
        /// <param name="_vendorid"></param>
        /// <returns></returns>
        public async Task<Model.DefaultResponse> GetMaintenance(Model.DefaultResponse _defaultresponse, Model.PubSubRequest _model_pubsub, int _vendorid)
        {
            #region 取得Redis快取
            //取得Redis快取
            var _response = await _cacheService.GetFromCache<Models.DB_ManufacturerCMS.Maintenance>($"Maintenance_{_vendorid.ToString()}");
            if (_response == null)
            {
                //若無快取，則重新撈取資料
                _response = await _manufacturercmscontext.Maintenances.Where(x => x.IdVendor == _vendorid && x.StartTime <= DateTime.Now && x.EndTime >= DateTime.Now && x.Active == 1).FirstOrDefaultAsync();
                //_response = await _manufacturercmscontext.Maintenances.Where(x => x.IdVendor == _vendorid && x.StartTime <= DateTime.Parse("2021/04/26 01:30:00") && x.EndTime >= DateTime.Parse("2021/04/26 01:30:00") && x.Active == 1).FirstOrDefaultAsync();

                //新增Redis快取
                await _cacheService.SetCache<Models.DB_ManufacturerCMS.Maintenance>($"Maintenance_{_vendorid.ToString()}", _response, _rediscachetime);
            }
            #endregion

            if (_response == null)
            {
                _defaultresponse.code = 9997;
                _defaultresponse.status = "Maintenance mapping data not exist";
                _defaultresponse.result = null;
            }

            if (_defaultresponse.code == 0)
            {
                _defaultresponse.result = _response;
            }
            else
            {
                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                _model_pubsub.type = _defaultresponse.type + " GetVendorData.GetMaintenance";
                _model_pubsub.responsedata = _defaultresponse;
                await _pubsubService.PublishMessagesAsync(_model_pubsub);
            }

            return _defaultresponse;
        }

        /// <summary>
        /// 驗證相關欄位並取得相關Table資料(資料已Redis)
        /// </summary>
        /// <param name="_model">Request第一層內容</param>
        /// <param name="_model_data">Request第二層內容</param>
        /// <param name="_verifyfields">驗證欄位</param>
        /// <param name="_response">傳入Response格式內容</param>
        /// <param name="_pubsubrequest">傳入Pub/Sub格式內容</param>
        /// <typeparam name="T1"></typeparam>
        /// <typeparam name="T2"></typeparam>
        /// <returns></returns>
        public async Task<Model.Vendor.VendorDataResponse> GetVendorData<T1, T2>(T1 _model, T2 _model_data, string _verifyfields, Model.DefaultResponse _response, Model.PubSubRequest _pubsubrequest)
        {
            Model.Vendor.VendorDataResponse _vendordata = new();

            string _merchantid = "";
            string _vcode = "";
            string _gameid = "";
            string _hash = "";

            #region 驗證傳入參數
            //驗證Request的值(_model)
            _response = VerifyReqParams<T1>.verifyReqParams(_response, _model, "data,hash");
            if (_response.code != 0)
            {
                _vendordata.DefaultResponse = _response;
                return _vendordata;
            }

            //驗證Request的值(_model.data)
            _response = VerifyReqParams<T2>.verifyReqParams(_response, _model_data, _verifyfields);
            if (_response.code != 0)
            {
                _vendordata.DefaultResponse = _response;
                return _vendordata;
            }
            #endregion

            foreach (var prop in _model.GetType().GetProperties())
            {
                //取得hash的值
                switch (prop.Name.ToLower())
                {
                    case "hash":
                        {
                            _hash = (prop.GetValue(_model) == null) ? "" : prop.GetValue(_model).ToString();
                            break;
                        }
                    default:
                        break;
                }
            }
            foreach (var prop in _model_data.GetType().GetProperties())
            {
                //取得data裡的值
                switch (prop.Name.ToLower())
                {
                    case "merchantid":
                        {
                            _merchantid = (prop.GetValue(_model_data) == null) ? "" : prop.GetValue(_model_data).ToString();
                            break;
                        }
                    case "vcode":
                        {
                            _vcode = (prop.GetValue(_model_data) == null) ? "" : prop.GetValue(_model_data).ToString();
                            break;
                        }
                    case "gameid":
                        {
                            _gameid = (prop.GetValue(_model_data) == null) ? "" : prop.GetValue(_model_data).ToString();
                            break;
                        }
                    default:
                        break;
                }
            }
            //var _data = _model.GetType().GetProperties()[0].GetValue(_model).ToString();
            //var _hash = _model.GetType().GetProperties()[1].GetValue(_model).ToString();
            //var _merchantid = _model_data.GetType().GetProperties()[0].GetValue(_model_data).ToString();
            //var _vcode = _model_data.GetType().GetProperties()[1].GetValue(_model_data).ToString();
            //var _gameid = _model_data.GetType().GetProperties()[2].GetValue(_model_data).ToString();

            //記錄LOG:API 呼叫記錄寫入 Pub/Sub
            #region 記錄LOG:API 呼叫記錄寫入 Pub/Sub(Start)
            Model.PubSubRequest _model_pubsub = _pubsubrequest;
            _model_pubsub.type = _response.type + " Start";
            _model_pubsub.merchantid = _merchantid;
            _model_pubsub.vcode = _vcode;
            _model_pubsub.gameid = _gameid;
            int _messagecount = await _pubsubService.PublishMessagesAsync(_model_pubsub);
            #endregion

            //取得VendorImplementInfo Redis快取資料
            var _vendorimplementinfo_defaultresponse = await GetVendorImplementInfo(_response, _model_pubsub, _merchantid);
            var _vendorimplementinfo = _vendorimplementinfo_defaultresponse.result;
            if (_vendorimplementinfo_defaultresponse.code != 0)
            {
                _vendordata.DefaultResponse = _vendorimplementinfo_defaultresponse;
                return _vendordata;
            }
            _vendordata.Redis_VendorImplementInfo = _vendorimplementinfo;

            //取得Vendor Redis快取資料
            var _vendor_defaultresponse = await GetVendor(_response, _model_pubsub, (int)_vendorimplementinfo.IdVendor);
            var _vendor = _vendor_defaultresponse.result;
            if (_vendor_defaultresponse.code != 0)
            {
                _vendordata.DefaultResponse = _vendor_defaultresponse;
                return _vendordata;
            }
            _vendordata.Redis_Vendor = _vendor;

            string _json = JsonSerializer.Serialize(_model_data);
            string _hashkey = _vendor.HashKey;
            string _realhash = Utility.Encryptions.MD5_Generate(_json + _hashkey);

            //判斷Hash是否正確
            if (_hash != _realhash)
            {
                _response.code = 1006;
                _response.status = "Hash Error:" + _realhash;
            }
            if (_response.code != 0)
            {
                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                _model_pubsub.type = _response.type + " GetVendorData.Hash Error";
                _model_pubsub.responsedata = _response;
                await _pubsubService.PublishMessagesAsync(_model_pubsub);

                _vendordata.DefaultResponse = _response;
                return _vendordata;
            }

            //取得VendorOperatorAccountMapping Redis快取資料
            var _vendoroperatoraccountmapping_defaultresponse = await GetVendorOperatorAccountMapping(_response, _model_pubsub, (int)_vendorimplementinfo.IdVendor, _vcode, 2);
            var _vendoroperatoraccountmapping = _vendoroperatoraccountmapping_defaultresponse.result;
            if (_vendoroperatoraccountmapping_defaultresponse.code != 0)
            {
                _vendordata.DefaultResponse = _vendoroperatoraccountmapping_defaultresponse;
                return _vendordata;
            }
            _vendordata.Redis_VendorOperatorAccountMapping = _vendoroperatoraccountmapping;

            //取得VendorOperatorAccountMapping Redis快取資料
            var _vendoroperatoraccountmapping1_defaultresponse = await GetVendorOperatorAccountMapping(_response, _model_pubsub, (int)_vendorimplementinfo.IdVendor, (int)_vendoroperatoraccountmapping.IdOperator, _gameid, 2);
            var _vendoroperatoraccountmapping1 = _vendoroperatoraccountmapping1_defaultresponse.result;
            if (_vendoroperatoraccountmapping1_defaultresponse.code != 0)
            {
                _vendordata.DefaultResponse = _vendoroperatoraccountmapping1_defaultresponse;
                return _vendordata;
            }
            _vendordata.Redis_VendorOperatorAccountMapping1 = _vendoroperatoraccountmapping1;

            int _operatorid = (int)_vendoroperatoraccountmapping.IdOperator;

            //取得Operator Redis快取資料
            var _operator_defaultresponse = await _operatorService.GetOperator(_response, _model_pubsub, _operatorid);
            var _operator = _operator_defaultresponse.result;
            if (_operator_defaultresponse.code != 0)
            {
                _vendordata.DefaultResponse = _operator_defaultresponse;
                return _vendordata;
            }
            _vendordata.Redis_Operator = _operator;

            string _apicode = _operator.ApiCode;

            //取得OperatorImplementInfo Redis快取資料
            var _operatorimplementinfo_defaultresponse = await _operatorService.GetOperatorImplementInfo(_response, _model_pubsub, _operatorid);
            var _operatorimplementinfo = _operatorimplementinfo_defaultresponse.result;
            if (_operatorimplementinfo_defaultresponse.code != 0)
            {
                _vendordata.DefaultResponse = _operatorimplementinfo_defaultresponse;
                return _vendordata;
            }
            _vendordata.Redis_OperatorImplementInfo = _operatorimplementinfo;

            //取得VendorVariables Redis快取資料
            var _vendorvariable_defaultresponse = await GetVendorVariable(_response, _model_pubsub, (int)_vendorimplementinfo.IdVendor, _operatorid, "startup");
            var _vendorvariable = _vendorvariable_defaultresponse.result;
            //因此Function為External與Seamless共用檢核及撈取資料，在External不需檢查VendorVariable的資料，故mark下列程式，若有要檢核在remark即可
            // if (_vendorvariable == null)
            // {
            //     _response.code = 9997;
            //     _response.status = "VendorVariable mapping data not exist";
            // }
            // if (_response.code != 0)
            // {
            //     //記錄LOG:API 呼叫記錄寫入 Pub/Sub
            //     _model_pubsub.type = _response.type + " GetVendorData.GetVendorVariable";
            //     _model_pubsub.responsedata = _response;
            //     await _pubsubService.PublishMessagesAsync(_model_pubsub);

            //     _vendordata.DefaultResponse = _response;
            //     return _vendordata;
            // }
            _vendordata.Redis_VendorVariable = _vendorvariable;

            //取得Vendor_BundleMapping Redis快取資料
            var _vendorbundlemapping_defaultresponse = await GetVendorBundleMapping(_response, _model_pubsub, (int)_vendorimplementinfo.IdVendor, _operatorid, (int)_vendoroperatoraccountmapping.GameId);
            var _vendorbundlemapping = _vendorbundlemapping_defaultresponse.result;
            //因此Function為External與Seamless共用檢核及撈取資料，在External不需檢查VendorBundleMapping的資料，故mark下列程式，若有要檢核在remark即可
            // if (_vendorbundlemapping == null)
            // {
            //     _response.code = 9997;
            //     _response.status = "VendorBundleMapping mapping data not exist";
            // }
            // if (_response.code != 0)
            // {
            //     //記錄LOG:API 呼叫記錄寫入 Pub/Sub
            //     _model_pubsub.type = _response.type + " GetVendorData.GetVendorBundleMapping";
            //     _model_pubsub.responsedata = _response;
            //     await _pubsubService.PublishMessagesAsync(_model_pubsub);

            //     _vendordata.DefaultResponse = _response;
            //     return _vendordata;
            // }
            _vendordata.Redis_VendorBundleMapping = _vendorbundlemapping;

            string _newgameid = (_vendoroperatoraccountmapping1 == null) ? "" : _vendoroperatoraccountmapping1.OperatorImplementId;

            _vendordata.ApiCode = _apicode;
            _vendordata.NewGameID = _newgameid;
            _vendordata.DefaultResponse = _response;

            return _vendordata;
        }
    }
}
