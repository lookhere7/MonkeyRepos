﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Seamless.Core.API.Interfaces;
using System.Linq;
using System.Threading.Tasks;

namespace Seamless.Core.API.Services
{
    /// <summary>
    /// 
    /// </summary>
    public class OperatorService : IOperatorService
    {
        /// <summary>
        /// 
        /// </summary>
        private readonly Models.DB_ManufacturerCMS.ManufacturerCMSContext _manufacturercmscontext = new();
        private readonly ICacheService _cacheService;
        private readonly IPubSubService _pubsubService;
        private readonly int _rediscachetime;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="config"></param>
        /// <param name="cacheService"></param>
        public OperatorService(IConfiguration config, ICacheService cacheService)
        {
            _rediscachetime = int.Parse(config["RedisCacheTime"]);
            _cacheService = cacheService;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="_defaultresponse"></param>
        /// <param name="_model_pubsub"></param>
        /// <param name="_username"></param>
        /// <returns></returns>
        public async Task<Model.DefaultResponse> GetOperator(Model.DefaultResponse _defaultresponse, Model.PubSubRequest _model_pubsub, string _username)
        {
            #region 取得Redis快取
            //取得Redis快取
            var _response = await _cacheService.GetFromCache<Models.DB_ManufacturerCMS.Operator>($"Operator_{_username}");
            if (_response == null)
            {
                //若無快取，則重新撈取資料
                _response = await _manufacturercmscontext.Operators.Where(x => x.Username == _username).FirstOrDefaultAsync();

                //新增Redis快取
                await _cacheService.SetCache<Models.DB_ManufacturerCMS.Operator>($"Operator_{_username}", _response, _rediscachetime);
            }
            #endregion

            if (_response == null)
            {
                _defaultresponse.code = 9997;
                _defaultresponse.status = "Operator mapping data not exist";
                _defaultresponse.result = null;
            }

            if (_defaultresponse.code == 0)
            {
                _defaultresponse.result = _response;
            }
            else
            {
                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                _model_pubsub.type = _defaultresponse.type + " GetVendorData.GetOperator";
                _model_pubsub.responsedata = _defaultresponse;
                await _pubsubService.PublishMessagesAsync(_model_pubsub);
            }

            return _defaultresponse;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="_defaultresponse"></param>
        /// <param name="_model_pubsub"></param>
        /// <param name="_id"></param>
        /// <returns></returns>
        public async Task<Model.DefaultResponse> GetOperator(Model.DefaultResponse _defaultresponse, Model.PubSubRequest _model_pubsub, int _id)
        {
            #region 取得Redis快取
            //取得Redis快取
            var _response = await _cacheService.GetFromCache<Models.DB_ManufacturerCMS.Operator>($"Operator_{_id.ToString()}");
            if (_response == null)
            {
                //若無快取，則重新撈取資料
                _response = await _manufacturercmscontext.Operators.Where(x => x.Id == _id).FirstOrDefaultAsync();

                //新增Redis快取
                await _cacheService.SetCache<Models.DB_ManufacturerCMS.Operator>($"Operator_{_id.ToString()}", _response, _rediscachetime);
            }
            #endregion

            if (_response == null)
            {
                _defaultresponse.code = 9997;
                _defaultresponse.status = "Operator mapping data not exist";
                _defaultresponse.result = null;
            }

            if (_defaultresponse.code == 0)
            {
                _defaultresponse.result = _response;
            }
            else
            {
                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                _model_pubsub.type = _defaultresponse.type + " GetVendorData.GetOperator";
                _model_pubsub.responsedata = _defaultresponse;
                await _pubsubService.PublishMessagesAsync(_model_pubsub);
            }

            return _defaultresponse;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="_defaultresponse"></param>
        /// <param name="_model_pubsub"></param>
        /// <param name="_operatorid"></param>
        /// <returns></returns>
        public async Task<Model.DefaultResponse> GetOperatorImplementInfo(Model.DefaultResponse _defaultresponse, Model.PubSubRequest _model_pubsub, int _operatorid)
        {
            #region 取得Redis快取
            //取得Redis快取
            var _response = await _cacheService.GetFromCache<Models.DB_ManufacturerCMS.OperatorImplementInfo>($"OperatorImplementInfo_{_operatorid.ToString()}");
            if (_response == null)
            {
                //若無快取，則重新撈取資料
                _response = await _manufacturercmscontext.OperatorImplementInfos.Where(x => x.IdOperator == _operatorid).FirstOrDefaultAsync();

                //新增Redis快取
                await _cacheService.SetCache<Models.DB_ManufacturerCMS.OperatorImplementInfo>($"OperatorImplementInfo_{_operatorid.ToString()}", _response, _rediscachetime);
            }
            #endregion

            if (_response == null)
            {
                _defaultresponse.code = 9997;
                _defaultresponse.status = "OperatorImplementInfo mapping data not exist";
                _defaultresponse.result = null;
            }

            if (_defaultresponse.code == 0)
            {
                _defaultresponse.result = _response;
            }
            else
            {
                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                _model_pubsub.type = _defaultresponse.type + " GetVendorData.GetOperatorImplementInfo";
                _model_pubsub.responsedata = _defaultresponse;
                await _pubsubService.PublishMessagesAsync(_model_pubsub);
            }

            return _defaultresponse;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="_defaultresponse"></param>
        /// <param name="_model_pubsub"></param>
        /// <param name="_merchantid"></param>
        /// <returns></returns>
        public async Task<Model.DefaultResponse> GetOperatorImplementInfo(Model.DefaultResponse _defaultresponse, Model.PubSubRequest _model_pubsub, string _merchantid)
        {
            #region 取得Redis快取
            //取得Redis快取
            var _response = await _cacheService.GetFromCache<Models.DB_ManufacturerCMS.OperatorImplementInfo>($"OperatorImplementInfo_{_merchantid}");
            if (_response == null)
            {
                //若無快取，則重新撈取資料
                _response = await _manufacturercmscontext.OperatorImplementInfos.Where(x => x.MerchantId == _merchantid).FirstOrDefaultAsync();

                //新增Redis快取
                await _cacheService.SetCache<Models.DB_ManufacturerCMS.OperatorImplementInfo>($"OperatorImplementInfo_{_merchantid}", _response, _rediscachetime);
            }
            #endregion

            if (_response == null)
            {
                _defaultresponse.code = 9997;
                _defaultresponse.status = "OperatorImplementInfo mapping data not exist";
                _defaultresponse.result = null;
            }

            if (_defaultresponse.code == 0)
            {
                _defaultresponse.result = _response;
            }
            else
            {
                //記錄LOG:API 呼叫記錄寫入 Pub/Sub
                _model_pubsub.type = _defaultresponse.type + " GetVendorData.GetOperatorImplementInfo";
                _model_pubsub.responsedata = _defaultresponse;
                await _pubsubService.PublishMessagesAsync(_model_pubsub);
            }

            return _defaultresponse;
        }
    }
}
