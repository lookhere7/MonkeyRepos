﻿using Seamless.Core.API.Interfaces;
using System.Collections.Generic;
using System.Linq;

namespace Seamless.Core.API.Services
{
    /// <summary>
    /// 
    /// </summary>
    public class GameService : IGameService
    {
        /// <summary>
        /// 
        /// </summary>
        private readonly Models.DB_ManufacturerCMS.ManufacturerCMSContext _context = new();

        /// <summary>
        /// 
        /// </summary>
        /// <param name="context"></param>
        //public GameService(Models.ManufacturerCMSContext context)
        //{
        //    this._context = context;      
        //}

        /// <summary>
        /// 
        /// </summary>
        /// <param name="_id"></param>
        /// <returns></returns>
        public Models.DB_ManufacturerCMS.Game Get(int _id)
        {
            var _response = _context.Games.Where(x => x.Id == _id).FirstOrDefault();
            return _response;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="_code"></param>
        /// <returns></returns>
        public Models.DB_ManufacturerCMS.Game Get(string _code)
        {
            var _response = _context.Games.Where(x => x.Code == _code).FirstOrDefault();
            return _response;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="_vendorid"></param>
        /// <returns></returns>
        public List<Models.DB_ManufacturerCMS.Game> GetByVendor(int _vendorid)
        {
            var _response = _context.Games.Where(x => x.IdVendor == _vendorid).ToList();
            return _response;
        }
    }
}
