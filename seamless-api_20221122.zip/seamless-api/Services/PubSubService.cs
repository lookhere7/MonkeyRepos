﻿using Google.Cloud.PubSub.V1;
using Microsoft.Extensions.Configuration;
using Seamless.Core.API.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace Seamless.Core.API.Services
{
    public class PubSubService : IPubSubService
    {
        /// <summary>
        /// 定義參數
        /// </summary>
        private string projectId;
        private string topicId;
        private string subscriptionId;

        /// <summary>
        /// 建構參數
        /// </summary>
        /// <param name="config"></param>
        public PubSubService(IConfiguration config)
        {
            projectId = config["BigQuery:projectid"];
            topicId = config["PubSub:topic"];
            subscriptionId = config["PubSub:subscription"];
        }

        /// <summary>
        /// [測試]Pub/Sub測試發送接收訊息
        /// </summary>
        /// <typeparam name="string"></typeparam>
        public async Task<string> SeamlessRequestLog<T>(T _model) where T : class
        {
            string _json = JsonSerializer.Serialize(_model);

            // var builder = new ConfigurationBuilder()
            //       .SetBasePath(Directory.GetCurrentDirectory())
            //       .AddJsonFile("appsettings.json");
            // var config = builder.Build();

            // var projectid = config["BigQuery:projectid"];
            // var topicid = config["PubSub:topic"];
            // var subscriptionid = config["PubSub:subscription"];

            //projectid = "audere-cms-stage";
            //topicid = "SeamlessRequestLog-sub";

            #region 記錄LOG:API 呼叫記錄寫入 Pub/Sub
            // First create a topic.
            PublisherServiceApiClient publisherService = await PublisherServiceApiClient.CreateAsync();
            TopicName topicName = new TopicName(projectId, topicId);
            publisherService.CreateTopic(topicName);

            // Subscribe to the topic.
            SubscriberServiceApiClient subscriberService = await SubscriberServiceApiClient.CreateAsync();
            SubscriptionName subscriptionName = new SubscriptionName(projectId, subscriptionId);
            subscriberService.CreateSubscription(subscriptionName, topicName, pushConfig: null, ackDeadlineSeconds: 60);

            // Publish a message to the topic using PublisherClient.
            PublisherClient publisher = await PublisherClient.CreateAsync(topicName);
            // PublishAsync() has various overloads. Here we're using the string overload.
            string messageId = await publisher.PublishAsync(_json);
            // PublisherClient instance should be shutdown after use.
            // The TimeSpan specifies for how long to attempt to publish locally queued messages.
            await publisher.ShutdownAsync(TimeSpan.FromSeconds(15));

            // Pull messages from the subscription using SubscriberClient.
            SubscriberClient subscriber = await SubscriberClient.CreateAsync(subscriptionName);
            List<PubsubMessage> receivedMessages = new List<PubsubMessage>();
            // Start the subscriber listening for messages.
            await subscriber.StartAsync((msg, cancellationToken) =>
            {
                receivedMessages.Add(msg);
                Console.WriteLine($"Received message {msg.MessageId} published at {msg.PublishTime.ToDateTime()}");
                Console.WriteLine($"Text: '{msg.Data.ToStringUtf8()}'");
                // Stop this subscriber after one message is received.
                // This is non-blocking, and the returned Task may be awaited.
                subscriber.StopAsync(TimeSpan.FromSeconds(15));
                // Return Reply.Ack to indicate this message has been handled.
                return Task.FromResult(SubscriberClient.Reply.Ack);
            });

            // Tidy up by deleting the subscription and the topic.
            //subscriberService.DeleteSubscription(subscriptionName);
            //publisherService.DeleteTopic(topicName);
            #endregion

            return messageId;
        }

        /// <summary>
        /// Pub/Sub發送訊息
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public async Task<int> PublishMessagesAsync(Model.PubSubRequest model)
        {
            string _json = JsonSerializer.Serialize(model);

            TopicName topicName = TopicName.FromProjectTopic(projectId, topicId);
            PublisherClient publisher = await PublisherClient.CreateAsync(topicName);

            int publishedMessageCount = 0;
            try
            {
                var message = await publisher.PublishAsync(_json);
                Console.WriteLine($"Published message {message}");
                Interlocked.Increment(ref publishedMessageCount);
            }
            catch (Exception exception)
            {
                Console.WriteLine($"An error ocurred when publishing message : {exception.Message}");
            }
            return publishedMessageCount;
        }

        /// <summary>
        /// Pub/Sub發送訊息
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public async Task<int> PublishMessagesAsync(dynamic model)
        {
            string _json = JsonSerializer.Serialize(model);

            TopicName topicName = TopicName.FromProjectTopic(projectId, topicId);
            PublisherClient publisher = await PublisherClient.CreateAsync(topicName);

            int publishedMessageCount = 0;
            try
            {
                var message = await publisher.PublishAsync(_json);
                Console.WriteLine($"Published message {message}");
                Interlocked.Increment(ref publishedMessageCount);
            }
            catch (Exception exception)
            {
                Console.WriteLine($"An error ocurred when publishing message : {exception.Message}");
            }
            return publishedMessageCount;
        }

        /// <summary>
        /// Pub/Sub發送訊息
        /// </summary>
        /// <param name="projectId"></param>
        /// <param name="topicId"></param>
        /// <param name="messageTexts">字串陣列</param>
        /// <returns></returns>
        public async Task<int> PublishMessagesAsync(string projectId, string topicId, IEnumerable<string> messageTexts)
        {
            TopicName topicName = TopicName.FromProjectTopic(projectId, topicId);
            PublisherClient publisher = await PublisherClient.CreateAsync(topicName);

            int publishedMessageCount = 0;
            var publishTasks = messageTexts.Select(async text =>
            {
                try
                {
                    string message = await publisher.PublishAsync(text);
                    Console.WriteLine($"Published message {message}");
                    Interlocked.Increment(ref publishedMessageCount);
                }
                catch (Exception exception)
                {
                    Console.WriteLine($"An error ocurred when publishing message {text}: {exception.Message}");
                }
            });
            await Task.WhenAll(publishTasks);
            return publishedMessageCount;
        }

        /// <summary>
        /// Pub/Sub接收訊息
        /// </summary>
        /// <param name="acknowledge"></param>
        /// <returns></returns>
        public async Task<int> PullMessagesAsync(bool acknowledge)
        {
            SubscriptionName subscriptionName = SubscriptionName.FromProjectSubscription(projectId, subscriptionId);
            SubscriberClient subscriber = await SubscriberClient.CreateAsync(subscriptionName);
            // SubscriberClient runs your message handle function on multiple
            // threads to maximize throughput.
            int messageCount = 0;
            Task startTask = subscriber.StartAsync((PubsubMessage message, CancellationToken cancel) =>
            {
                string text = System.Text.Encoding.UTF8.GetString(message.Data.ToArray());
                Console.WriteLine($"Message {message.MessageId}: {text}");
                Interlocked.Increment(ref messageCount);
                return Task.FromResult(acknowledge ? SubscriberClient.Reply.Ack : SubscriberClient.Reply.Nack);
            });
            // Run for 5 seconds.
            await Task.Delay(5000);
            await subscriber.StopAsync(CancellationToken.None);
            // Lets make sure that the start task finished successfully after the call to stop.
            await startTask;
            return messageCount;
        }
    }
}