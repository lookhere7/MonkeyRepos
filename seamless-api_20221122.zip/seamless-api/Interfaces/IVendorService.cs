﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace Seamless.Core.API.Interfaces
{
    public interface IVendorService
    {
        public Task<Model.DefaultResponse> GetVendor(Model.DefaultResponse _defaultresponse, Model.PubSubRequest _model_pubsub, int _id);

        public Task<Model.DefaultResponse> GetVendor(Model.DefaultResponse _defaultresponse, Model.PubSubRequest _model_pubsub, string _implementvcode);

        public Task<Model.DefaultResponse> GetVendorImplementInfo(Model.DefaultResponse _defaultresponse, Model.PubSubRequest _model_pubsub,int _vendorid);

        public Task<Model.DefaultResponse> GetVendorImplementInfo(Model.DefaultResponse _defaultresponse, Model.PubSubRequest _model_pubsub, string _vendorid);

        public Task<Model.DefaultResponse> GetVendorOperatorAccountMapping(Model.DefaultResponse _defaultresponse, Model.PubSubRequest _model_pubsub, int _vendorid, int _operatorid, int _gameid);

        public Task<Model.DefaultResponse> GetVendorOperatorAccountMapping(Model.DefaultResponse _defaultresponse, Model.PubSubRequest _model_pubsub, int _vendorid, int _operatorid, int _gameid, int _route);

        public Task<Model.DefaultResponse> GetVendorOperatorAccountMapping(Model.DefaultResponse _defaultresponse, Model.PubSubRequest _model_pubsub, int _vendorid, int _operatorid, string _implementid);

        public Task<Model.DefaultResponse> GetVendorOperatorAccountMapping(Model.DefaultResponse _defaultresponse, Model.PubSubRequest _model_pubsub, int _vendorid, int _operatorid, string _implementid, int _route);

        public Task<Model.DefaultResponse> GetVendorOperatorAccountMapping(Model.DefaultResponse _defaultresponse, Model.PubSubRequest _model_pubsub, int _vendorid, string _implementvcode, int _route);

        public Task<Model.DefaultResponse> GetVendorVariable(Model.DefaultResponse _defaultresponse, Model.PubSubRequest _model_pubsub, int _vendorid, int _operatorid, string _parametername);

        public Task<Model.DefaultResponse> GetVendorBundleMapping(Model.DefaultResponse _defaultresponse, Model.PubSubRequest _model_pubsub, int _vendorid, int _operatorid, int _gameid);

        public Task<Model.DefaultResponse> GetMaintenance(Model.DefaultResponse _defaultresponse, Model.PubSubRequest _model_pubsub, int _vendorid);

        public Task<Model.Vendor.VendorDataResponse> GetVendorData<T1, T2>(T1 _model, T2 _model_data, string _verifyfields, Model.DefaultResponse _response, Model.PubSubRequest _pubsubrequest);
    }
}
