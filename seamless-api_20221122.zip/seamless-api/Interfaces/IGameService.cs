﻿using System.Collections.Generic;

namespace Seamless.Core.API.Interfaces
{
    public interface IGameService
    {
        public Models.DB_ManufacturerCMS.Game Get(int _id);

        public Models.DB_ManufacturerCMS.Game Get(string _code);

        public List<Models.DB_ManufacturerCMS.Game> GetByVendor(int _vendorid);
    }
}
