﻿using Microsoft.Extensions.Caching.Distributed;
using System.Threading.Tasks;

namespace Seamless.Core.API.Interfaces
{
    public interface ICacheService
    {
        public Task<T> GetFromCache<T>(string key) where T : class;

        public Task SetCache<T>(string key, T value, DistributedCacheEntryOptions options) where T : class;

        public Task SetCache<T>(string key, T value, int cachetime) where T : class;

        public Task ClearCache(string key);
    }
}
