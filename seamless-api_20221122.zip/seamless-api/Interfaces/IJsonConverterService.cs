﻿namespace Seamless.Core.API.Interfaces
{
    public interface IJsonConverterService
    {

    }
}
