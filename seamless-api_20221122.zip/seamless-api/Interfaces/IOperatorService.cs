﻿using System.Threading.Tasks;

namespace Seamless.Core.API.Interfaces
{
    public interface IOperatorService
    {
        public Task<Model.DefaultResponse> GetOperator(Model.DefaultResponse _defaultresponse, Model.PubSubRequest _model_pubsub, string _username);

        public Task<Model.DefaultResponse> GetOperator(Model.DefaultResponse _defaultresponse, Model.PubSubRequest _model_pubsub,int _id);

        public Task<Model.DefaultResponse> GetOperatorImplementInfo(Model.DefaultResponse _defaultresponse, Model.PubSubRequest _model_pubsub, int _operatorid);

        public Task<Model.DefaultResponse> GetOperatorImplementInfo(Model.DefaultResponse _defaultresponse, Model.PubSubRequest _model_pubsub, string _merchantid);
    }
}
